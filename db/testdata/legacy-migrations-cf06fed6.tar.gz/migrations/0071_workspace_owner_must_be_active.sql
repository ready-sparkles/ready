ALTER TABLE workspace_memberships
  ADD CONSTRAINT workspace_memberships_owner_must_be_active_chk
  CHECK (role <> 'owner' OR status = 'active');
