-- Preserve one completed or active preview per meeting; failed attempts remain history.
WITH ranked AS (
  SELECT id, row_number() OVER (
    PARTITION BY meeting_id ORDER BY (status = 'completed') DESC, created_at DESC, id
  ) AS position
  FROM ai_workflow_executions
  WHERE type = 'resolve_meeting_title' AND scope_key = 'guest-preview-v1'
    AND status IN ('running', 'queued', 'completed')
)
UPDATE ai_workflow_executions SET status = 'cancelled', completed_at = now(),
  error = 'Superseded duplicate preview at migration'
WHERE id IN (SELECT id FROM ranked WHERE position > 1);
ALTER TABLE ai_workflow_executions ADD COLUMN preview_key text GENERATED ALWAYS AS (
  CASE WHEN type = 'resolve_meeting_title' AND scope_key = 'guest-preview-v1'
    AND status IN ('running', 'queued', 'completed') THEN meeting_id::text END
) STORED;
CREATE UNIQUE INDEX ai_workflow_executions_preview_key_uidx ON ai_workflow_executions(preview_key);
