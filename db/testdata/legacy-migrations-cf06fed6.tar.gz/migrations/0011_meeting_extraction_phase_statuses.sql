ALTER TABLE meeting_extractions
  ADD COLUMN IF NOT EXISTS content_status extraction_status NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS signals_status extraction_status NOT NULL DEFAULT 'pending';

UPDATE meeting_extractions
SET
  content_status = status,
  signals_status = status
WHERE content_status = 'pending'
  AND signals_status = 'pending'
  AND status <> 'pending';

CREATE INDEX IF NOT EXISTS meeting_extractions_content_status_idx
  ON meeting_extractions(content_status);

CREATE INDEX IF NOT EXISTS meeting_extractions_signals_status_idx
  ON meeting_extractions(signals_status);
