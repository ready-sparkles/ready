-- One in-flight voice search per meeting, user, and query.
-- Completed and terminal rows stay so a later search can start after the first finishes.
-- Block new claims until the unique index exists, so a live API cannot insert a duplicate.
SET LOCAL lock_timeout = '3min';
SET LOCAL statement_timeout = 0;
LOCK TABLE voice_web_research_runs IN SHARE ROW EXCLUSIVE MODE;

DELETE FROM voice_web_research_runs AS older
WHERE older.status NOT IN ('failed', 'cancelled', 'expired', 'completed')
  AND EXISTS (
    SELECT 1
    FROM voice_web_research_runs AS newer
    WHERE newer.meeting_id = older.meeting_id
      AND newer.user_id = older.user_id
      AND newer.query_key = older.query_key
      AND newer.status NOT IN ('failed', 'cancelled', 'expired', 'completed')
      AND (newer.created_at, newer.id) > (older.created_at, older.id)
  );

CREATE UNIQUE INDEX voice_web_research_runs_active_query_uidx
  ON voice_web_research_runs (meeting_id, user_id, query_key)
  WHERE status NOT IN ('failed', 'cancelled', 'expired', 'completed');
