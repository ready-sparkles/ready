ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'detect_live_meeting_tasks';

ALTER TABLE meeting_tasks
  ADD COLUMN IF NOT EXISTS origin varchar(16) NOT NULL DEFAULT 'final',
  ADD COLUMN IF NOT EXISTS status_source varchar(16) NOT NULL DEFAULT 'model',
  ADD COLUMN IF NOT EXISTS status_actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS status_changed_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS action_confirmable_at timestamptz,
  ADD COLUMN IF NOT EXISTS detected_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_rendered_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_rendered_reported_at timestamptz,
  ADD COLUMN IF NOT EXISTS realtime_received_at timestamptz,
  ADD COLUMN IF NOT EXISTS refetch_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS refetch_completed_at timestamptz;

DO $$ BEGIN
  ALTER TABLE meeting_tasks
    ADD CONSTRAINT meeting_tasks_origin_check CHECK (origin IN ('live', 'final'));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE meeting_tasks
    ADD CONSTRAINT meeting_tasks_status_source_check CHECK (status_source IN ('model', 'user'));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS meeting_live_task_candidates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  linked_task_id uuid REFERENCES meeting_tasks(id) ON DELETE SET NULL,
  state varchar(24) NOT NULL DEFAULT 'deferred'
    CHECK (state IN ('deferred', 'confirmed', 'rejected', 'retracted')),
  title varchar(160) NOT NULL,
  description text,
  type meeting_task_type NOT NULL,
  work_kind meeting_task_work_kind NOT NULL DEFAULT 'general',
  owner_name varchar(120),
  owner_email varchar(255),
  owner_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  owner_confidence extraction_confidence,
  due_date_value varchar(120),
  due_date_confidence extraction_confidence,
  confidence extraction_confidence NOT NULL,
  completion jsonb NOT NULL,
  source_quotes jsonb NOT NULL DEFAULT '[]'::jsonb,
  source_reason text NOT NULL,
  unresolved_questions jsonb NOT NULL DEFAULT '[]'::jsonb,
  first_evidence_at timestamptz NOT NULL,
  action_confirmable_at timestamptz,
  last_evidence_at timestamptz NOT NULL,
  model varchar(160),
  prompt_version varchar(32),
  revision integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS meeting_live_task_candidates_meeting_state_idx
  ON meeting_live_task_candidates (meeting_id, state, updated_at);
CREATE INDEX IF NOT EXISTS meeting_live_task_candidates_linked_task_idx
  ON meeting_live_task_candidates (linked_task_id);

CREATE TABLE IF NOT EXISTS meeting_live_task_candidate_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL REFERENCES meeting_live_task_candidates(id) ON DELETE CASCADE,
  roles jsonb NOT NULL DEFAULT '[]'::jsonb,
  transcript_segment_id uuid REFERENCES transcript_segments(id) ON DELETE SET NULL,
  source_segment_id text,
  full_segment_text text NOT NULL,
  quote text NOT NULL,
  quote_start integer NOT NULL CHECK (quote_start >= 0),
  quote_end integer NOT NULL CHECK (quote_end > quote_start),
  content_hash varchar(128) NOT NULL,
  speaker_identity text,
  speaker_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  speaker_name varchar(160) NOT NULL,
  started_at timestamptz NOT NULL,
  ended_at timestamptz NOT NULL,
  sequence integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS meeting_live_task_candidate_evidence_candidate_idx
  ON meeting_live_task_candidate_evidence (candidate_id, sequence);

CREATE TABLE IF NOT EXISTS meeting_live_task_cursors (
  meeting_id uuid PRIMARY KEY REFERENCES meetings(id) ON DELETE CASCADE,
  last_processed_segment_id uuid REFERENCES transcript_segments(id) ON DELETE SET NULL,
  processed_through timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
