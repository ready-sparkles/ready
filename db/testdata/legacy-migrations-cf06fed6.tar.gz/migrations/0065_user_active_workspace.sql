-- Which workspace the user is currently looking at. Falls back to the first
-- membership when unset or when the membership is no longer active.
ALTER TABLE users
  ADD COLUMN active_workspace_id uuid REFERENCES workspaces(id) ON DELETE SET NULL;
