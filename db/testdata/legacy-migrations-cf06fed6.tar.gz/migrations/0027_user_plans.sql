CREATE TYPE user_plan AS ENUM ('free', 'business', 'enterprise');

ALTER TABLE users
  ADD COLUMN plan user_plan NOT NULL DEFAULT 'free';

CREATE INDEX users_plan_idx ON users (plan);
