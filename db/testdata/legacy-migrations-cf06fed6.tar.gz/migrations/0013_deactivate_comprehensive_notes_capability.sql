UPDATE capability_catalog
SET is_active = false, updated_at = now()
WHERE key = 'generate_comprehensive_notes';
