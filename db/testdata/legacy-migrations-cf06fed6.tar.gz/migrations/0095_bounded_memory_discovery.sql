-- Durable, meeting-local notifications. No account/history scans run in finalization.
CREATE TABLE memory_discovery_requests (
 meeting_id uuid PRIMARY KEY REFERENCES meetings(id) ON DELETE CASCADE,
 version bigint NOT NULL DEFAULT 1, completed_version bigint NOT NULL DEFAULT 0,
 cursor_user_id uuid, cursor_workspace_id uuid,
 run_after timestamptz NOT NULL DEFAULT now(), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX memory_discovery_ready ON memory_discovery_requests(run_after,meeting_id)
 WHERE version>completed_version;
CREATE TABLE memory_backfills (
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
 cursor_meeting_id uuid, cycle_started_at timestamptz NOT NULL DEFAULT now(),
 revision integer NOT NULL DEFAULT 1, run_after timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(user_id,workspace_id)
);
CREATE INDEX memory_backfills_ready ON memory_backfills(run_after,user_id,workspace_id);
CREATE TABLE memory_discovery_cursors (
 name text PRIMARY KEY, user_id uuid, workspace_id uuid
);
INSERT INTO memory_discovery_cursors(name) VALUES('scopes');
CREATE INDEX memory_membership_discovery ON workspace_memberships(user_id,workspace_id) WHERE status='active';
CREATE INDEX memory_participant_history ON meeting_participants(user_id,meeting_id);

CREATE FUNCTION queue_meeting_memory_discovery(mid uuid) RETURNS void LANGUAGE sql AS $$
 INSERT INTO memory_discovery_requests(meeting_id)
 SELECT m.id FROM meetings m WHERE m.id=mid AND m.status='ended' AND m.kind='standard'
 AND EXISTS(SELECT 1 FROM transcripts t WHERE t.meeting_id=m.id AND
  (t.source IN('livekit-python-postcall','livekit-postcall') OR t.metadata->>'refinedAt' IS NOT NULL
   OR t.metadata->>'finalizedAt' IS NOT NULL OR t.metadata->>'mode' IN('postcall-refined','agent-live-finalized')))
 ON CONFLICT(meeting_id) DO UPDATE SET version=memory_discovery_requests.version+1,run_after=now()
$$;
CREATE FUNCTION notify_finalized_memory_transcript() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM queue_meeting_memory_discovery(NEW.meeting_id);
 RETURN NULL;
END $$;
CREATE TRIGGER memory_finalized_transcript AFTER INSERT OR UPDATE OF source,metadata ON transcripts
 FOR EACH ROW EXECUTE FUNCTION notify_finalized_memory_transcript();
CREATE FUNCTION notify_ended_memory_meeting() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.status='ended' THEN PERFORM queue_meeting_memory_discovery(NEW.id); END IF;
 RETURN NULL;
END $$;
CREATE TRIGGER memory_ended_meeting AFTER INSERT OR UPDATE OF status ON meetings
 FOR EACH ROW EXECUTE FUNCTION notify_ended_memory_meeting();

-- Late transcript edits invalidate existing evidence and wake only that meeting.
CREATE OR REPLACE FUNCTION invalidate_meeting_memories() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE tid uuid; mid uuid;
BEGIN
 IF TG_OP='DELETE' THEN tid=OLD.transcript_id; ELSE tid=NEW.transcript_id; END IF;
 SELECT meeting_id INTO mid FROM transcripts WHERE id=tid;
 UPDATE memory_sources SET is_current=false WHERE meeting_id=mid;
 IF mid IS NOT NULL THEN PERFORM queue_meeting_memory_discovery(mid); END IF;
 RETURN NULL;
END $$;
