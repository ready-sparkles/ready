-- Consolidate existing evidence-backed text without another model generation.
-- Invalid revisions and entries with missing/forgotten evidence are excluded.
CREATE FUNCTION consolidate_memory_projections(winner uuid,loser uuid) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
 WITH valid AS MATERIALIZED (
  SELECT p.* FROM memory_person_projections p
  WHERE p.person_id IN(winner,loser) AND p.source_revisions IS NOT NULL
   AND NOT EXISTS(
    SELECT 1 FROM jsonb_each_text(p.source_revisions) evidence
    WHERE NOT EXISTS(SELECT 1 FROM memory_sources s JOIN memory_people person ON person.id=winner
     WHERE s.id::text=evidence.key AND s.user_id=person.user_id AND s.workspace_id=person.workspace_id
      AND s.is_current AND s.revision=evidence.value AND memory_meeting_revision(s.meeting_id)=evidence.value))
 ), entries AS (
  SELECT DISTINCT section,entry FROM valid p
  CROSS JOIN unnest(ARRAY['summary','standing']) section
  CROSS JOIN LATERAL jsonb_array_elements(coalesce(p.content->section,'[]'::jsonb)) entry
  WHERE jsonb_array_length(coalesce(entry->'memoryIds','[]'::jsonb))>0
   AND NOT EXISTS(
    SELECT 1 FROM jsonb_array_elements_text(entry->'memoryIds') ref
    WHERE NOT EXISTS(SELECT 1 FROM relationship_memories m
     WHERE m.id::text=ref AND winner=ANY(m.person_ids) AND p.source_revisions ? m.source_id::text))
 ), revisions AS (
  SELECT coalesce(jsonb_object_agg(key,value),'{}'::jsonb) value
  FROM (SELECT DISTINCT key,value FROM valid CROSS JOIN LATERAL jsonb_each(source_revisions)) r
 )
 INSERT INTO memory_person_projections(person_id,input_hash,content,prompt_version,source_revisions)
 SELECT winner,'consolidated:'||gen_random_uuid()::text,
  jsonb_build_object(
   'summary',coalesce((SELECT jsonb_agg(entry ORDER BY entry::text) FROM entries WHERE section='summary'),'[]'::jsonb),
   'standing',coalesce((SELECT jsonb_agg(entry ORDER BY entry::text) FROM entries WHERE section='standing'),'[]'::jsonb)),
  (SELECT prompt_version FROM valid ORDER BY updated_at DESC LIMIT 1),revisions.value
 FROM revisions WHERE EXISTS(SELECT 1 FROM valid)
 ON CONFLICT(person_id) DO UPDATE SET input_hash=excluded.input_hash,content=excluded.content,
  prompt_version=excluded.prompt_version,source_revisions=excluded.source_revisions,updated_at=now();
 DELETE FROM memory_person_projections WHERE person_id=loser;
END $$;

CREATE OR REPLACE FUNCTION link_guest_memory_account(guest_id uuid,account_id uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE browser_id uuid; account_name text; account_email text; scope record; winner uuid; loser record;
BEGIN
 PERFORM pg_advisory_xact_lock(hashtextextended('guest-memory-account-link',0));
 SELECT display_name,lower(trim(email)) INTO account_name,account_email FROM users WHERE id=account_id AND source IN('auth','dev_login') AND deleted_at IS NULL;
 IF account_name IS NULL OR NOT EXISTS(SELECT 1 FROM users WHERE id=guest_id AND source='guest') THEN
  RAISE EXCEPTION 'Invalid guest account link';
 END IF;
 SELECT b.browser_id INTO browser_id FROM guest_browser_users b WHERE b.guest_user_id=guest_id;
 IF EXISTS(SELECT 1 FROM guest_memory_account_links WHERE guest_user_id=guest_id AND account_user_id<>account_id)
 OR EXISTS(SELECT 1 FROM guest_browser_identities WHERE id=browser_id AND linked_account_user_id IS NOT NULL AND linked_account_user_id<>account_id) THEN
  RAISE EXCEPTION 'Guest recognition is already linked to another account' USING ERRCODE='23505';
 END IF;
 INSERT INTO guest_memory_account_links VALUES(guest_id,account_id) ON CONFLICT DO NOTHING;
 UPDATE guest_browser_identities SET linked_account_user_id=account_id WHERE id=browser_id;
 FOR scope IN
  SELECT DISTINCT i.user_id,i.workspace_id FROM memory_person_identities i
  WHERE ((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email))
   OR (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id))
  ORDER BY i.user_id,i.workspace_id
 LOOP
  PERFORM pg_advisory_xact_lock(hashtextextended('memory-people:'||scope.user_id||':'||scope.workspace_id,0));
  -- Keep the guest/browser person already shown to this owner whenever possible.
  SELECT i.person_id INTO winner FROM memory_person_identities i
  WHERE i.user_id=scope.user_id AND i.workspace_id=scope.workspace_id AND
   (((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email)) OR
    (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id)))
  ORDER BY CASE WHEN i.kind='guest_browser' AND i.identity=browser_id::text THEN 0
    WHEN i.kind='user_id' AND i.identity=guest_id::text THEN 1 ELSE 2 END,i.person_id LIMIT 1;
  -- Preserve an observed guest spelling even for guests who never opted into browser recognition.
  INSERT INTO memory_person_names(person_id,source_id,participant_user_id,name,normalized_name,word_count,observed_at)
   SELECT winner,mi.source_id,guest_id,u.display_name,lower(trim(u.display_name)),
    CASE WHEN lower(trim(u.display_name))='guest' THEN 0 ELSE cardinality(regexp_split_to_array(trim(u.display_name),'\s+')) END,mi.occurred_at
   FROM memory_interactions mi JOIN memory_person_identities gi ON gi.person_id=mi.person_id
   JOIN users u ON u.id=guest_id
   WHERE gi.user_id=scope.user_id AND gi.workspace_id=scope.workspace_id AND gi.kind='user_id' AND gi.identity=guest_id::text
   ON CONFLICT DO NOTHING;
  FOR loser IN
   SELECT DISTINCT i.person_id FROM memory_person_identities i
   WHERE i.user_id=scope.user_id AND i.workspace_id=scope.workspace_id AND i.person_id<>winner AND
    (((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email)) OR
     (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id)))
  LOOP
   INSERT INTO memory_interactions SELECT source_id,winner,occurred_at FROM memory_interactions WHERE person_id=loser.person_id ON CONFLICT DO NOTHING;
   DELETE FROM memory_interactions WHERE person_id=loser.person_id;
   INSERT INTO memory_person_names SELECT winner,source_id,participant_user_id,name,normalized_name,word_count,observed_at FROM memory_person_names WHERE person_id=loser.person_id ON CONFLICT DO NOTHING;
   DELETE FROM memory_person_names WHERE person_id=loser.person_id;
   UPDATE memory_person_identities SET person_id=winner WHERE person_id=loser.person_id;
   UPDATE memory_person_redirects SET target_person_id=winner WHERE target_person_id=loser.person_id;
   INSERT INTO memory_person_redirects VALUES(loser.person_id,winner) ON CONFLICT(person_id) DO UPDATE SET target_person_id=excluded.target_person_id;
   UPDATE relationship_memories SET person_ids=array_replace(person_ids,loser.person_id,winner),
    candidate_subject_id=CASE WHEN candidate_subject_id=loser.person_id THEN winner ELSE candidate_subject_id END
    WHERE loser.person_id=ANY(person_ids) OR candidate_subject_id=loser.person_id;
   PERFORM consolidate_memory_projections(winner,loser.person_id);
  END LOOP;
  INSERT INTO memory_person_identities VALUES(winner,scope.user_id,scope.workspace_id,'user_id',account_id::text) ON CONFLICT DO NOTHING;
  UPDATE memory_people SET name=account_name WHERE id=winner;
 END LOOP;
END $$;
