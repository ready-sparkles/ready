CREATE TABLE meeting_attendance_intervals (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, joined_at timestamptz NOT NULL, left_at timestamptz,
 CHECK (left_at IS NULL OR left_at >= joined_at)
);
CREATE UNIQUE INDEX attendance_one_open ON meeting_attendance_intervals(meeting_id,user_id) WHERE left_at IS NULL;
CREATE INDEX attendance_meeting_user ON meeting_attendance_intervals(meeting_id,user_id);
-- Preserve the best historical interval; placeholder and after-end records are not attendance.
INSERT INTO meeting_attendance_intervals(meeting_id,user_id,joined_at,left_at)
SELECT p.meeting_id,p.user_id,p.joined_at,coalesce(p.left_at,m.ended_at)
FROM meeting_participants p JOIN meetings m ON m.id=p.meeting_id
WHERE p.role IN ('host','guest') AND p.joined_at>'2000-01-01' AND
 (m.ended_at IS NULL OR p.joined_at<m.ended_at) AND
 (coalesce(p.left_at,m.ended_at) IS NULL OR coalesce(p.left_at,m.ended_at)>p.joined_at);
CREATE FUNCTION record_memory_attendance() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.role NOT IN ('host','guest') OR NEW.joined_at<'2000-01-01' THEN RETURN NEW; END IF;
 IF NEW.left_at IS NULL AND EXISTS(SELECT 1 FROM meetings WHERE id=NEW.meeting_id AND status<>'ended') THEN
  IF TG_OP='UPDATE' AND NEW.joined_at IS DISTINCT FROM OLD.joined_at THEN
   UPDATE meeting_attendance_intervals SET left_at=greatest(joined_at,NEW.joined_at) WHERE meeting_id=NEW.meeting_id AND user_id=NEW.user_id AND left_at IS NULL;
  END IF;
  INSERT INTO meeting_attendance_intervals(meeting_id,user_id,joined_at) VALUES(NEW.meeting_id,NEW.user_id,NEW.joined_at) ON CONFLICT DO NOTHING;
 ELSIF NEW.left_at IS NOT NULL THEN
  UPDATE meeting_attendance_intervals SET left_at=greatest(joined_at,NEW.left_at) WHERE meeting_id=NEW.meeting_id AND user_id=NEW.user_id AND left_at IS NULL;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER memory_attendance AFTER INSERT OR UPDATE ON meeting_participants FOR EACH ROW EXECUTE FUNCTION record_memory_attendance();

CREATE TABLE memory_preferences (
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
 enabled boolean NOT NULL DEFAULT false, include_sensitive boolean NOT NULL DEFAULT false,
 recruiting_months integer NOT NULL DEFAULT 24 CHECK(recruiting_months IN(0,1,3,6,12,24)), language text NOT NULL DEFAULT 'English',
 revision integer NOT NULL DEFAULT 1, PRIMARY KEY(user_id,workspace_id)
);
CREATE TABLE memory_people (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE, name text NOT NULL,
 UNIQUE(id,user_id,workspace_id)
);
CREATE TABLE memory_person_identities (
 person_id uuid NOT NULL REFERENCES memory_people(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
 kind text NOT NULL CHECK(kind IN('user_id','verified_email')), identity text NOT NULL,
 PRIMARY KEY(user_id,workspace_id,kind,identity),
 FOREIGN KEY(person_id,user_id,workspace_id) REFERENCES memory_people(id,user_id,workspace_id) ON DELETE CASCADE
);
CREATE TABLE memory_sources (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE, kind text NOT NULL,
 external_id text NOT NULL, meeting_id uuid REFERENCES meetings(id) ON DELETE CASCADE,
 occurred_at timestamptz NOT NULL, revision text NOT NULL, is_current boolean NOT NULL DEFAULT false,
 UNIQUE(user_id,workspace_id,kind,external_id), UNIQUE(id,user_id,workspace_id)
);
CREATE TABLE memory_interactions (
 source_id uuid NOT NULL REFERENCES memory_sources(id) ON DELETE CASCADE, person_id uuid NOT NULL REFERENCES memory_people(id) ON DELETE CASCADE,
 occurred_at timestamptz NOT NULL, PRIMARY KEY(source_id,person_id)
);
CREATE TABLE relationship_memories (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), source_id uuid NOT NULL REFERENCES memory_sources(id) ON DELETE CASCADE,
 fingerprint text NOT NULL, title text NOT NULL, description text NOT NULL, category text NOT NULL,
 person_ids uuid[] NOT NULL, candidate_subject_id uuid REFERENCES memory_people(id) ON DELETE SET NULL,
 candidate_subject_key text, sensitive boolean NOT NULL, confidence text NOT NULL,
 state text NOT NULL DEFAULT 'active' CHECK(state IN('active','pinned','faded')), fades_at timestamptz,
 restored_at timestamptz, occurred_at timestamptz NOT NULL, UNIQUE(source_id,fingerprint)
);
CREATE INDEX memory_full_text ON relationship_memories USING gin(to_tsvector('simple', title || ' ' || description));
CREATE INDEX memory_chronology ON relationship_memories(occurred_at DESC,id);
CREATE INDEX memory_people_lookup ON relationship_memories USING gin(person_ids);
CREATE TABLE memory_evidence (
 memory_id uuid NOT NULL REFERENCES relationship_memories(id) ON DELETE CASCADE,
 segment_id uuid NOT NULL REFERENCES transcript_segments(id) ON DELETE CASCADE, quote text NOT NULL,
 PRIMARY KEY(memory_id,segment_id)
);
CREATE TABLE memory_suppressions (
 source_id uuid NOT NULL REFERENCES memory_sources(id) ON DELETE CASCADE,
 segment_id uuid NOT NULL, PRIMARY KEY(source_id,segment_id)
);
CREATE TABLE memory_person_projections (
 person_id uuid PRIMARY KEY REFERENCES memory_people(id) ON DELETE CASCADE,
 input_hash text NOT NULL, content jsonb NOT NULL, prompt_version text NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE memory_jobs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
 source_id uuid REFERENCES memory_sources(id) ON DELETE CASCADE,
 kind text NOT NULL CHECK(kind IN('extract','project')), dedupe_key text NOT NULL UNIQUE,
 source_revision text, preferences_revision integer NOT NULL, prompt_version text NOT NULL, model text,
 status text NOT NULL DEFAULT 'queued' CHECK(status IN('queued','running','completed','failed','cancelled')),
 attempts integer NOT NULL DEFAULT 0, run_after timestamptz NOT NULL DEFAULT now(),
 lease_token uuid, locked_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(), completed_at timestamptz, extracted_at timestamptz, error text
);
CREATE INDEX memory_jobs_ready ON memory_jobs(status,run_after,created_at);
CREATE INDEX memory_jobs_scope ON memory_jobs(user_id,workspace_id,status);

-- Invalidate immediately: edited/deleted evidence must never support an old projection.
CREATE FUNCTION invalidate_meeting_memories() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE tid uuid;
BEGIN
 IF TG_OP='DELETE' THEN tid=OLD.transcript_id; ELSE tid=NEW.transcript_id; END IF;
 UPDATE memory_sources SET is_current=false WHERE meeting_id IN(SELECT meeting_id FROM transcripts WHERE id=tid);
 RETURN NULL;
END $$;
CREATE TRIGGER memory_transcript_revision AFTER INSERT OR UPDATE OR DELETE ON transcript_segments FOR EACH ROW EXECUTE FUNCTION invalidate_meeting_memories();
CREATE FUNCTION memory_meeting_revision(mid uuid) RETURNS text LANGUAGE sql STABLE AS $$
 SELECT md5(coalesce(string_agg(jsonb_build_array(s.id,s.speaker_user_id,s.speaker_name,s.speaker_role,s.content,s.started_at)::text,'' ORDER BY s.started_at,s.id),''))
 FROM transcripts t JOIN transcript_segments s ON s.transcript_id=t.id WHERE t.meeting_id=mid
$$;

-- Cascade deletion can remove transcript rows before segment triggers can find them.
CREATE FUNCTION invalidate_memory_transcript_parent() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 UPDATE memory_sources SET is_current=false WHERE meeting_id=OLD.meeting_id;
 RETURN OLD;
END $$;
CREATE TRIGGER memory_transcript_parent BEFORE DELETE ON transcripts FOR EACH ROW EXECUTE FUNCTION invalidate_memory_transcript_parent();
