UPDATE ai_credit_pricing_config
SET
  action_minimum_credits = '{"meeting_prep": 1}'::jsonb || action_minimum_credits,
  updated_at = now()
WHERE NOT (action_minimum_credits ? 'meeting_prep');
