ALTER TABLE billing_checkout_attempts DROP CONSTRAINT billing_checkout_attempts_status_check;
ALTER TABLE billing_checkout_attempts ADD CONSTRAINT billing_checkout_attempts_status_check
  CHECK (status IN ('pending', 'processing', 'completed', 'expired', 'failed'));
DROP INDEX billing_checkout_attempts_pending_uidx;
CREATE UNIQUE INDEX billing_checkout_attempts_pending_uidx
  ON billing_checkout_attempts(subject_type, subject_id, checkout_kind)
  WHERE status IN ('pending', 'processing');
