CREATE TABLE IF NOT EXISTS meeting_capability_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  extraction_id uuid NOT NULL REFERENCES meeting_extractions(id) ON DELETE CASCADE,
  capability_key varchar(160) NOT NULL REFERENCES capability_catalog(key),
  rank integer NOT NULL,
  raw_score integer NOT NULL,
  final_score integer NOT NULL,
  signals_matched jsonb NOT NULL DEFAULT '[]'::jsonb,
  signals_missing jsonb NOT NULL DEFAULT '[]'::jsonb,
  exclusion_signals_checked jsonb NOT NULL DEFAULT '[]'::jsonb,
  reasoning text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  confidence extraction_confidence NOT NULL,
  selection_prompt_version varchar(32) NOT NULL,
  selection_model varchar(160) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS meeting_capability_recommendations_meeting_idx
  ON meeting_capability_recommendations(meeting_id);

CREATE INDEX IF NOT EXISTS meeting_capability_recommendations_extraction_idx
  ON meeting_capability_recommendations(extraction_id);

CREATE INDEX IF NOT EXISTS meeting_capability_recommendations_capability_key_idx
  ON meeting_capability_recommendations(capability_key);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_capability_recommendations_extraction_capability_prompt_uidx
  ON meeting_capability_recommendations(extraction_id, capability_key, selection_prompt_version);
