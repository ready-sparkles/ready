ALTER TABLE meetings
  ADD COLUMN hidden_from_history_at timestamptz,
  ADD COLUMN hidden_from_history_reason text;

CREATE INDEX meetings_hidden_from_history_idx
  ON meetings (hidden_from_history_at)
  WHERE hidden_from_history_at IS NOT NULL;
