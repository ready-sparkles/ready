-- Bounded voice-context reads ordered by persistence time, including late speech.
CREATE INDEX IF NOT EXISTS transcript_segments_created_cursor_idx
  ON transcript_segments (transcript_id, created_at, id);
