-- A compact, private completion cutoff for each user's workspace task feed.
-- Source tasks remain intact for past meeting pages and other viewers.
CREATE TABLE personal_task_clearances (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  completed_before timestamptz NOT NULL,
  PRIMARY KEY (user_id, workspace_id)
);
