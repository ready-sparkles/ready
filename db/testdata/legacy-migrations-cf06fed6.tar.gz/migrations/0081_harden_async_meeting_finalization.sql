UPDATE ai_workflow_jobs
SET
  max_attempts = GREATEST(max_attempts, 4),
  updated_at = now()
WHERE type = 'finalize_meeting'
  AND status IN ('queued', 'running');
