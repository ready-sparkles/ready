-- Collect nearby finalized fragments without postponing an already queued check.
CREATE OR REPLACE FUNCTION enqueue_meeting_tracker_segment() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.source = 'livekit-python-live' AND NEW.speaker_role = 'human' THEN
    INSERT INTO ai_workflow_jobs (meeting_id, type, scope_key, status, phase, payload, max_attempts, run_after)
    SELECT meeting_id, 'track_meeting', 'default', 'queued', 'queued', '{}', 3, now() + interval '3 seconds'
    FROM transcripts WHERE id = NEW.transcript_id
    ON CONFLICT (meeting_id, type, scope_key) WHERE status IN ('queued', 'running')
    DO UPDATE SET payload = ai_workflow_jobs.payload || '{"retryAfterCompletion":true}'::jsonb,
      updated_at = now();
  END IF;
  RETURN NEW;
END;
$$;
