-- Chronology stays primary. Stored semantic importance orders simultaneous developments.
ALTER TABLE relationship_memories ADD COLUMN importance smallint NOT NULL DEFAULT 1
  CHECK (importance BETWEEN 1 AND 4);
CREATE INDEX memory_chronology_importance ON relationship_memories(occurred_at DESC,importance DESC,id DESC);
