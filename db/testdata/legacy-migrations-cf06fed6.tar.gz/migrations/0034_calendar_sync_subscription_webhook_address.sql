ALTER TABLE calendar_sync_subscriptions
  ADD COLUMN IF NOT EXISTS webhook_address text;

DROP INDEX IF EXISTS calendar_sync_subscriptions_connector_calendar_uidx;

CREATE UNIQUE INDEX IF NOT EXISTS calendar_sync_subscriptions_active_connector_calendar_uidx
  ON calendar_sync_subscriptions(agent_connector_id, calendar_id)
  WHERE status = 'active';
