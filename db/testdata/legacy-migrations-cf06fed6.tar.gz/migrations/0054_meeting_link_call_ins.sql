CREATE TABLE IF NOT EXISTS meeting_link_call_ins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_link_id uuid NOT NULL REFERENCES meeting_links(id) ON DELETE CASCADE,
  phone_number varchar(32) NOT NULL,
  pin varchar(16) NOT NULL,
  sip_dispatch_rule_id varchar(255),
  last_synced_meeting_id uuid REFERENCES meetings(id) ON DELETE SET NULL,
  status varchar(32) NOT NULL DEFAULT 'active',
  last_sync_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_link_call_ins_meeting_link_uidx
  ON meeting_link_call_ins(meeting_link_id);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_link_call_ins_phone_pin_uidx
  ON meeting_link_call_ins(phone_number, pin);

CREATE INDEX IF NOT EXISTS meeting_link_call_ins_sip_rule_idx
  ON meeting_link_call_ins(sip_dispatch_rule_id);

CREATE INDEX IF NOT EXISTS meeting_link_call_ins_last_meeting_idx
  ON meeting_link_call_ins(last_synced_meeting_id);
