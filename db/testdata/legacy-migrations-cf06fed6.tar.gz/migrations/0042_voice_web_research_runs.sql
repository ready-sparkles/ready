CREATE TABLE IF NOT EXISTS voice_web_research_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_profile_id uuid NOT NULL REFERENCES agent_profiles(id) ON DELETE CASCADE,
  utterance_id varchar(160) NOT NULL,
  query text NOT NULL,
  query_key varchar(260) NOT NULL,
  status varchar(32) NOT NULL DEFAULT 'queued',
  research_mode varchar(48) NOT NULL DEFAULT 'fast_grounded',
  session_id varchar(1000),
  search_id varchar(180),
  findall_id varchar(180),
  taskgroup_id varchar(180),
  run_refs jsonb NOT NULL DEFAULT '{}'::jsonb,
  progress jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  error jsonb,
  cancelled_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS voice_web_research_runs_meeting_user_status_idx
  ON voice_web_research_runs(meeting_id, user_id, status, created_at);

CREATE INDEX IF NOT EXISTS voice_web_research_runs_query_dedupe_idx
  ON voice_web_research_runs(meeting_id, user_id, query_key, created_at);

CREATE INDEX IF NOT EXISTS voice_web_research_runs_taskgroup_idx
  ON voice_web_research_runs(taskgroup_id);
