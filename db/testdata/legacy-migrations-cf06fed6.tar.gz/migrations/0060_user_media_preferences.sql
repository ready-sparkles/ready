create table if not exists user_media_preferences (
  user_id uuid primary key references users(id) on delete cascade,
  background_blur_enabled boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
