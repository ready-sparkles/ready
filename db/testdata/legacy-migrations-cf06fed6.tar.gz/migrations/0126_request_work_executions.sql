-- Deploy with the old API stopped and after resolving outstanding work. Nothing
-- in this migration schedules or resumes a request after process failure.
SET LOCAL lock_timeout = '3min';
SET LOCAL statement_timeout = 0;

-- Do not discard Stripe events that have not been applied yet.
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM stripe_webhook_events WHERE status <> 'processed') THEN
    RAISE EXCEPTION 'Replay outstanding Stripe events successfully before removing the webhook queue';
  END IF;
END $$;

ALTER TABLE meeting_trackers ADD COLUMN status text NOT NULL DEFAULT 'idle';

CREATE TABLE ai_workflow_executions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  extraction_id uuid REFERENCES meeting_extractions(id) ON DELETE SET NULL,
  type text NOT NULL,
  scope_key varchar(160) NOT NULL DEFAULT 'default',
  status text NOT NULL DEFAULT 'running',
  phase varchar(64) NOT NULL DEFAULT 'running',
  payload jsonb NOT NULL DEFAULT '{}',
  result jsonb NOT NULL DEFAULT '{}',
  error text,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ai_workflow_executions_meeting_idx ON ai_workflow_executions(meeting_id, created_at);
INSERT INTO ai_workflow_executions
  (id, meeting_id, extraction_id, type, scope_key, status, phase, payload, result, error,
   started_at, completed_at, created_at, updated_at)
SELECT id, meeting_id, extraction_id, type, scope_key,
  CASE WHEN status IN ('queued', 'running') THEN 'failed' ELSE status END,
  CASE WHEN status IN ('queued', 'running') THEN 'interrupted_at_cutover' ELSE phase END,
  payload, result,
  CASE WHEN status IN ('queued', 'running') THEN 'Request must be retried after queue removal' ELSE error END,
  COALESCE(started_at, created_at),
  CASE WHEN status IN ('queued', 'running') THEN now() ELSE completed_at END,
  created_at, updated_at
FROM ai_workflow_jobs;

-- Preserve usage and billing history and their execution identifiers.
ALTER TABLE usage_events DROP CONSTRAINT usage_events_job_id_fkey;
ALTER TABLE usage_events ADD CONSTRAINT usage_events_job_id_fkey
  FOREIGN KEY (job_id) REFERENCES ai_workflow_executions(id) ON DELETE SET NULL;
ALTER TABLE ai_credit_usage_events DROP CONSTRAINT ai_credit_usage_events_job_id_fkey;
ALTER TABLE ai_credit_usage_events ADD CONSTRAINT ai_credit_usage_events_job_id_fkey
  FOREIGN KEY (job_id) REFERENCES ai_workflow_executions(id) ON DELETE SET NULL;

CREATE TABLE stripe_webhook_receipts (
  stripe_event_id text PRIMARY KEY,
  event_type text NOT NULL,
  processed_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO stripe_webhook_receipts(stripe_event_id, event_type, processed_at)
SELECT stripe_event_id, event_type, COALESCE(processed_at, updated_at)
FROM stripe_webhook_events WHERE status = 'processed';

-- Keep delivery-independent generation limits, not work rows or leases.
ALTER TABLE memory_generation_ledger
  ADD COLUMN source_id uuid REFERENCES memory_sources(id) ON DELETE SET NULL,
  ADD COLUMN source_revision text,
  ADD COLUMN preferences_revision integer,
  ADD COLUMN request_token uuid,
  ADD COLUMN completed_at timestamptz,
  ADD COLUMN error text;
UPDATE memory_generation_ledger l SET source_id = j.source_id,
  source_revision = j.source_revision, preferences_revision = j.preferences_revision,
  completed_at = CASE WHEN j.status IN ('completed', 'failed', 'cancelled') THEN COALESCE(j.completed_at, now()) ELSE now() END,
  error = CASE WHEN j.status = 'completed' THEN NULL ELSE 'Generation interrupted before queue removal' END
FROM memory_jobs j WHERE j.id = l.job_id;

-- Remove database producers before their target queues disappear.
DROP TRIGGER IF EXISTS meeting_tracker_segment ON transcript_segments;
DROP FUNCTION IF EXISTS enqueue_meeting_tracker_segment();
DROP TRIGGER IF EXISTS memory_ended_meeting ON meetings;
DROP TRIGGER IF EXISTS memory_finalized_transcript ON transcripts;
DROP TRIGGER IF EXISTS memory_late_attendance ON meeting_attendance_intervals;
DROP TRIGGER IF EXISTS memory_late_workspace ON meeting_attendee_workspaces;
DROP TRIGGER IF EXISTS memory_late_participant ON meeting_participants;
DROP FUNCTION IF EXISTS notify_ended_memory_meeting();
DROP FUNCTION IF EXISTS notify_finalized_memory_transcript();
DROP FUNCTION IF EXISTS notify_late_memory_attendee();

ALTER TABLE mail_webhook_events DROP CONSTRAINT IF EXISTS mail_webhook_events_enqueue_job_id_fkey;
DROP TABLE ai_workflow_jobs;
DROP TABLE realtime_outbox;
DROP TABLE memory_jobs;
DROP TABLE mail_jobs;
DROP TABLE mail_pipeline_heartbeats;
-- Outstanding storage deletions stay in this table. Dropping them would forget
-- the object keys. An empty queue is removed with the other workers.
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pending_attachment_deletions) THEN
    DROP INDEX IF EXISTS pending_attachment_deletions_due_idx;
  ELSE
    DROP TABLE pending_attachment_deletions;
  END IF;
END $$;
DROP TABLE billing_seat_sync_outbox;
DROP TABLE calendar_description_updates;
DROP TABLE stripe_webhook_events;
DROP FUNCTION IF EXISTS wake_future_memory_attendees(uuid);
DROP FUNCTION IF EXISTS queue_future_memory_event(uuid);
DROP TABLE memory_meeting_events;

-- AFTER INSERT prevents idempotent replays from debiting twice. Row locks and
-- debit writes live in the INSERT's transaction, including insufficient funds.
ALTER TABLE ai_credit_usage_events ADD COLUMN require_available_credits boolean NOT NULL DEFAULT false;
CREATE FUNCTION debit_ai_usage_credits() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  account users%ROWTYPE;
  subscription billing_subscriptions%ROWTYPE;
  grant_row credit_grants%ROWTYPE;
  remaining integer := GREATEST(NEW.credits_charged, 0);
  debit integer;
  pool_balance bigint;
  used_before bigint;
  allowance integer := 0;
  active_member boolean;
  use_workspace boolean := false;
  anchor timestamp;
  window_start timestamptz;
  window_end timestamptz;
  window_index integer := 0;
BEGIN
  IF remaining = 0 THEN RETURN NEW; END IF;
  -- User first, then workspace: a consistent lock order also covers legacy grants.
  SELECT * INTO account FROM users WHERE id = NEW.user_id FOR NO KEY UPDATE;
  IF account.plan <> 'free' AND account.private_beta_pro_enabled_at IS NOT NULL
    AND NOT EXISTS (
      SELECT 1 FROM billing_subscriptions WHERE user_id = NEW.user_id AND workspace_id IS NULL
      AND (status IN ('active', 'trialing') OR (status = 'past_due' AND status_changed_at > now() - interval '7 days'))
      AND (current_period_end IS NULL OR current_period_end > now())
    ) THEN RETURN NEW;
  END IF;
  IF NEW.workspace_id IS NOT NULL THEN
    PERFORM id FROM workspaces WHERE id = NEW.workspace_id FOR NO KEY UPDATE;
    SELECT EXISTS(SELECT 1 FROM workspace_memberships WHERE user_id = NEW.user_id
      AND workspace_id = NEW.workspace_id AND status = 'active') INTO active_member;
    SELECT * INTO subscription FROM billing_subscriptions WHERE workspace_id = NEW.workspace_id
      AND (status IN ('active', 'trialing') OR (status = 'past_due' AND status_changed_at > now() - interval '7 days'))
      AND (current_period_end IS NULL OR current_period_end > now())
      ORDER BY updated_at DESC LIMIT 1;
    IF FOUND THEN
      use_workspace := true;
      IF active_member AND subscription.current_period_start IS NOT NULL THEN
        anchor := subscription.current_period_start AT TIME ZONE 'UTC';
        window_start := subscription.current_period_start;
        window_end := (anchor + interval '1 month') AT TIME ZONE 'UTC';
        WHILE now() >= window_end AND window_index < 12 LOOP
          window_index := window_index + 1;
          window_start := (anchor + make_interval(months => window_index)) AT TIME ZONE 'UTC';
          window_end := (anchor + make_interval(months => window_index + 1)) AT TIME ZONE 'UTC';
        END LOOP;
        window_end := LEAST(window_end, COALESCE(subscription.current_period_end, window_end));
        IF now() >= window_start AND now() < window_end THEN
          SELECT COALESCE(sum(credits_charged), 0) INTO used_before FROM ai_credit_usage_events
            WHERE workspace_id = NEW.workspace_id AND user_id = NEW.user_id AND id <> NEW.id
            AND created_at >= window_start AND created_at < window_end;
          allowance := LEAST(remaining, GREATEST(0, subscription.included_credits_per_period - used_before));
          remaining := remaining - allowance;
        END IF;
      END IF;
    ELSE
      SELECT COALESCE(sum(credits_remaining), 0) INTO pool_balance FROM credit_grants
        WHERE workspace_id = NEW.workspace_id AND credits_remaining > 0
        AND (expires_at IS NULL OR expires_at > now());
      use_workspace := active_member AND pool_balance >= remaining;
    END IF;
  END IF;
  FOR grant_row IN SELECT * FROM credit_grants
    WHERE credits_remaining > 0 AND (expires_at IS NULL OR expires_at > now())
      AND ((use_workspace AND workspace_id = NEW.workspace_id) OR (NOT use_workspace AND user_id = NEW.user_id))
    ORDER BY expires_at ASC NULLS LAST, created_at ASC, id ASC FOR UPDATE
  LOOP
    EXIT WHEN remaining <= 0;
    debit := LEAST(remaining, grant_row.credits_remaining);
    UPDATE credit_grants SET credits_remaining = credits_remaining - debit, updated_at = now() WHERE id = grant_row.id;
    remaining := remaining - debit;
  END LOOP;
  IF NEW.require_available_credits AND remaining > 0 THEN
    RAISE EXCEPTION 'Insufficient AI credits';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER debit_ai_usage_credits AFTER INSERT ON ai_credit_usage_events
  FOR EACH ROW EXECUTE FUNCTION debit_ai_usage_credits();
