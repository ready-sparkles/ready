ALTER TABLE calendar_sync_subscriptions
  ALTER COLUMN last_message_number TYPE text;
