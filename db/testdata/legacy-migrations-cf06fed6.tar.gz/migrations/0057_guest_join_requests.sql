ALTER TYPE user_source ADD VALUE IF NOT EXISTS 'guest';

DO $$
BEGIN
  CREATE TYPE meeting_join_request_status AS ENUM ('waiting', 'admitted', 'denied', 'expired', 'revoked');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS meeting_join_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_link_id uuid NOT NULL REFERENCES meeting_links(id) ON DELETE CASCADE,
  meeting_id uuid REFERENCES meetings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  display_name_snapshot varchar(120) NOT NULL,
  status meeting_join_request_status NOT NULL DEFAULT 'waiting',
  requested_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  decided_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_join_requests_active_user_uidx
  ON meeting_join_requests(meeting_link_id, user_id)
  WHERE status IN ('waiting'::meeting_join_request_status, 'admitted'::meeting_join_request_status);

CREATE INDEX IF NOT EXISTS meeting_join_requests_meeting_status_idx
  ON meeting_join_requests(meeting_id, status, requested_at);

CREATE INDEX IF NOT EXISTS meeting_join_requests_link_status_idx
  ON meeting_join_requests(meeting_link_id, status, requested_at);

CREATE INDEX IF NOT EXISTS meeting_join_requests_user_idx
  ON meeting_join_requests(user_id, requested_at);

CREATE TABLE IF NOT EXISTS guest_auth_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  meeting_link_id uuid NOT NULL REFERENCES meeting_links(id) ON DELETE CASCADE,
  meeting_id uuid REFERENCES meetings(id) ON DELETE CASCADE,
  join_request_id uuid NOT NULL REFERENCES meeting_join_requests(id) ON DELETE CASCADE,
  secret_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  linked_to_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS guest_auth_sessions_user_idx
  ON guest_auth_sessions(user_id, expires_at);

CREATE INDEX IF NOT EXISTS guest_auth_sessions_request_idx
  ON guest_auth_sessions(join_request_id);

CREATE INDEX IF NOT EXISTS guest_auth_sessions_expiry_idx
  ON guest_auth_sessions(expires_at, revoked_at);
