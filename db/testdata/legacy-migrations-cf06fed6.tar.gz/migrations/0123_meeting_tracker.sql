CREATE TABLE meeting_trackers (
  meeting_id uuid PRIMARY KEY REFERENCES meetings(id) ON DELETE CASCADE,
  revision integer NOT NULL DEFAULT 0,
  items jsonb NOT NULL DEFAULT '[]',
  processed_segment_ids jsonb NOT NULL DEFAULT '[]',
  updated_at timestamptz
);

-- Persist the wakeup in the same transaction as finalized speech. No timer or browser owner.
CREATE FUNCTION enqueue_meeting_tracker_segment() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.source = 'livekit-python-live' AND NEW.speaker_role = 'human' THEN
    INSERT INTO ai_workflow_jobs (meeting_id, type, scope_key, status, phase, payload, max_attempts, run_after)
    SELECT meeting_id, 'track_meeting', 'default', 'queued', 'queued', '{}', 3, now()
    FROM transcripts WHERE id = NEW.transcript_id
    ON CONFLICT (meeting_id, type, scope_key) WHERE status IN ('queued', 'running')
    DO UPDATE SET payload = ai_workflow_jobs.payload || '{"retryAfterCompletion":true}'::jsonb,
      updated_at = now();
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER meeting_tracker_segment AFTER INSERT ON transcript_segments
FOR EACH ROW EXECUTE FUNCTION enqueue_meeting_tracker_segment();
