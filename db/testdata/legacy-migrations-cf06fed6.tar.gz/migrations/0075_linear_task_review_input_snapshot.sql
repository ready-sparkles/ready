ALTER TABLE linear_task_review_runs
  ADD COLUMN IF NOT EXISTS input_snapshot jsonb NOT NULL DEFAULT '[]'::jsonb;
