-- Run after 0126 with the old API stopped. Only lookup indexes and uniqueness
-- rules already enforced by 0125 generated keys are removed.
SET LOCAL lock_timeout = '3min';
SET LOCAL statement_timeout = 0;

-- Retain the provider-message audit row, not its pointer to the removed queue.
ALTER TABLE mail_webhook_events DROP COLUMN enqueue_job_id;

-- Verified from pg_index after replaying 0125 and 0126: none is unique.
DROP INDEX IF EXISTS acquisition_payments_user_idx;
DROP INDEX IF EXISTS action_items_meeting_idx;
DROP INDEX IF EXISTS admin_user_plan_changes_target_idx;
DROP INDEX IF EXISTS agent_connector_secrets_connector_idx;
DROP INDEX IF EXISTS agent_connectors_profile_idx;
DROP INDEX IF EXISTS agent_memories_profile_idx;
DROP INDEX IF EXISTS agent_memories_user_idx;
DROP INDEX IF EXISTS agent_profiles_user_idx;
DROP INDEX IF EXISTS agent_tool_invocations_meeting_idx;
DROP INDEX IF EXISTS agent_tool_invocations_user_idx;
DROP INDEX IF EXISTS ai_credit_usage_events_action_type_idx;
DROP INDEX IF EXISTS ai_credit_usage_events_meeting_idx;
DROP INDEX IF EXISTS ai_credit_usage_events_user_created_idx;
DROP INDEX IF EXISTS ai_credit_usage_events_workspace_user_idx;
DROP INDEX IF EXISTS ai_workflow_executions_meeting_idx;
DROP INDEX IF EXISTS analytics_outbox_pending_idx;
-- Analytics delivery was retired in PR #371; acquisition and payment facts stay.
DROP TABLE analytics_outbox;
DROP INDEX IF EXISTS assigned_task_placements_scope_idx;
DROP INDEX IF EXISTS attendance_meeting_user;
DROP INDEX IF EXISTS billing_checkout_attempts_session_idx;
DROP INDEX IF EXISTS billing_subscriptions_user_idx;
DROP INDEX IF EXISTS billing_subscriptions_workspace_idx;
DROP INDEX IF EXISTS calendar_event_preps_account_idx;
DROP INDEX IF EXISTS calendar_event_preps_taskgroup_idx;
DROP INDEX IF EXISTS calendar_event_preps_user_updated_idx;
DROP INDEX IF EXISTS calendar_ready_links_calendar_account_idx;
DROP INDEX IF EXISTS calendar_ready_links_meeting_link_idx;
DROP INDEX IF EXISTS calendar_sync_subscriptions_channel_idx;
DROP INDEX IF EXISTS calendar_sync_subscriptions_user_idx;
DROP INDEX IF EXISTS capability_catalog_active_idx;
DROP INDEX IF EXISTS capability_catalog_category_idx;
DROP INDEX IF EXISTS capability_workflow_messages_run_idx;
DROP INDEX IF EXISTS capability_workflow_runs_meeting_idx;
DROP INDEX IF EXISTS capability_workflow_runs_recommendation_idx;
DROP INDEX IF EXISTS credit_grants_user_active_idx;
DROP INDEX IF EXISTS credit_grants_workspace_active_idx;
DROP INDEX IF EXISTS data_deletion_requests_target_idx;
DROP INDEX IF EXISTS data_deletion_requests_user_idx;
DROP INDEX IF EXISTS google_addon_conferences_meeting_link_idx;
DROP INDEX IF EXISTS guest_auth_sessions_expiry_idx;
DROP INDEX IF EXISTS guest_auth_sessions_request_idx;
DROP INDEX IF EXISTS guest_auth_sessions_user_idx;
DROP INDEX IF EXISTS guest_browser_users_browser;
DROP INDEX IF EXISTS linear_task_review_items_run_idx;
DROP INDEX IF EXISTS linear_task_review_runs_meeting_created_idx;
DROP INDEX IF EXISTS linear_task_review_runs_status_updated_idx;
DROP INDEX IF EXISTS mail_accounts_user_status_idx;
DROP INDEX IF EXISTS mail_addresses_user_domain_idx;
DROP INDEX IF EXISTS mail_attachments_account_idx;
DROP INDEX IF EXISTS mail_attachments_message_idx;
DROP INDEX IF EXISTS mail_change_log_account_seq_idx;
DROP INDEX IF EXISTS mail_change_log_thread_idx;
DROP INDEX IF EXISTS mail_change_log_user_seq_idx;
DROP INDEX IF EXISTS mail_classifier_cache_user_surface_idx;
DROP INDEX IF EXISTS mail_message_recipients_address_idx;
DROP INDEX IF EXISTS mail_messages_account_sent_idx;
DROP INDEX IF EXISTS mail_messages_thread_sent_idx;
DROP INDEX IF EXISTS mail_provider_messages_account_created_idx;
DROP INDEX IF EXISTS mail_sync_subscriptions_account_idx;
DROP INDEX IF EXISTS mail_sync_subscriptions_provider_subscription_idx;
DROP INDEX IF EXISTS mail_threads_account_surface_last_idx;
DROP INDEX IF EXISTS mail_threads_surface_classifier_key_idx;
DROP INDEX IF EXISTS mail_threads_user_surface_last_idx;
DROP INDEX IF EXISTS mail_view_waitlist_entries_requested_at_idx;
DROP INDEX IF EXISTS mail_webhook_events_account_created_idx;
DROP INDEX IF EXISTS mail_webhook_events_provider_created_idx;
DROP INDEX IF EXISTS mail_webhook_events_pubsub_message_idx;
DROP INDEX IF EXISTS meeting_ambient_context_items_recency_idx;
DROP INDEX IF EXISTS meeting_ambient_context_items_status_idx;
DROP INDEX IF EXISTS meeting_assets_meeting_captured_idx;
DROP INDEX IF EXISTS meeting_attendee_workspaces_scope;
DROP INDEX IF EXISTS meeting_capability_recommendations_capability_key_idx;
DROP INDEX IF EXISTS meeting_capability_recommendations_extraction_idx;
DROP INDEX IF EXISTS meeting_capability_recommendations_meeting_idx;
DROP INDEX IF EXISTS meeting_extractions_completed_at_idx;
DROP INDEX IF EXISTS meeting_extractions_content_status_idx;
DROP INDEX IF EXISTS meeting_extractions_signals_status_idx;
DROP INDEX IF EXISTS meeting_extractions_status_idx;
DROP INDEX IF EXISTS meeting_join_requests_link_status_idx;
DROP INDEX IF EXISTS meeting_join_requests_meeting_status_idx;
DROP INDEX IF EXISTS meeting_join_requests_user_idx;
DROP INDEX IF EXISTS meeting_link_call_ins_last_meeting_idx;
DROP INDEX IF EXISTS meeting_link_call_ins_sip_rule_idx;
DROP INDEX IF EXISTS meeting_links_creator_idx;
DROP INDEX IF EXISTS meeting_links_workspace_idx;
DROP INDEX IF EXISTS meeting_live_task_candidate_evidence_candidate_idx;
DROP INDEX IF EXISTS meeting_live_task_candidates_linked_task_idx;
DROP INDEX IF EXISTS meeting_live_task_candidates_meeting_state_idx;
DROP INDEX IF EXISTS meeting_participants_meeting_idx;
DROP INDEX IF EXISTS meeting_participants_user_idx;
DROP INDEX IF EXISTS meeting_research_runs_meeting_created_idx;
DROP INDEX IF EXISTS meeting_research_runs_recommendation_idx;
DROP INDEX IF EXISTS meeting_research_runs_status_updated_idx;
DROP INDEX IF EXISTS meeting_suggested_action_runs_meeting_idx;
DROP INDEX IF EXISTS meeting_task_latency_observations_meeting_kind_idx;
DROP INDEX IF EXISTS meeting_task_lists_meeting_idx;
DROP INDEX IF EXISTS meeting_task_lists_status_idx;
DROP INDEX IF EXISTS meeting_tasks_list_idx;
DROP INDEX IF EXISTS meeting_tasks_meeting_idx;
DROP INDEX IF EXISTS meeting_tasks_owner_status_completed_at_idx;
DROP INDEX IF EXISTS meeting_tasks_owner_user_idx;
DROP INDEX IF EXISTS meeting_tasks_status_idx;
DROP INDEX IF EXISTS meeting_tasks_work_kind_idx;
DROP INDEX IF EXISTS meeting_turns_meeting_idx;
DROP INDEX IF EXISTS meeting_turns_owner_idx;
DROP INDEX IF EXISTS meetings_creator_kind_idx;
DROP INDEX IF EXISTS meetings_hidden_from_history_idx;
DROP INDEX IF EXISTS meetings_meeting_link_idx;
DROP INDEX IF EXISTS meetings_room_name_idx;
DROP INDEX IF EXISTS meetings_workspace_idx;
DROP INDEX IF EXISTS memory_chronology;
DROP INDEX IF EXISTS memory_chronology_importance;
DROP INDEX IF EXISTS memory_fact_lookup;
DROP INDEX IF EXISTS memory_full_text;
DROP INDEX IF EXISTS memory_membership_discovery;
DROP INDEX IF EXISTS memory_participant_history;
DROP INDEX IF EXISTS memory_people_lookup;
DROP INDEX IF EXISTS memory_sync_changes_cursor;
DROP INDEX IF EXISTS private_beta_waitlist_entries_requested_at_idx;
DROP INDEX IF EXISTS slack_meeting_deliveries_user_idx;
DROP INDEX IF EXISTS summaries_meeting_idx;
DROP INDEX IF EXISTS transcript_segments_agent_owner_idx;
DROP INDEX IF EXISTS transcript_segments_created_cursor_idx;
DROP INDEX IF EXISTS transcript_segments_source_idx;
DROP INDEX IF EXISTS transcript_segments_transcript_idx;
DROP INDEX IF EXISTS transcript_segments_turn_idx;
DROP INDEX IF EXISTS transcripts_meeting_idx;
DROP INDEX IF EXISTS usage_events_category_idx;
DROP INDEX IF EXISTS usage_events_meeting_idx;
DROP INDEX IF EXISTS usage_events_user_occurred_idx;
DROP INDEX IF EXISTS user_auth_accounts_user_idx;
DROP INDEX IF EXISTS user_capability_preferences_capability_idx;
DROP INDEX IF EXISTS user_capability_preferences_user_idx;
DROP INDEX IF EXISTS users_has_completed_first_meeting_idx;
DROP INDEX IF EXISTS users_plan_idx;
DROP INDEX IF EXISTS voice_web_research_runs_meeting_user_status_idx;
DROP INDEX IF EXISTS voice_web_research_runs_query_dedupe_idx;
DROP INDEX IF EXISTS voice_web_research_runs_taskgroup_idx;
DROP INDEX IF EXISTS workspace_audit_events_subject_idx;
DROP INDEX IF EXISTS workspace_audit_events_workspace_idx;
DROP INDEX IF EXISTS workspace_invitations_workspace_idx;
DROP INDEX IF EXISTS workspace_memberships_user_idx;
DROP INDEX IF EXISTS workspace_task_sections_workspace_idx;
DROP INDEX IF EXISTS workspace_tasks_workspace_assignee_idx;
DROP INDEX IF EXISTS workspaces_created_by_user_idx;

-- The generated-key unique indexes remain. IF EXISTS also covers the predicates
-- that 0125 must remove before converting enum columns to text.
DROP INDEX IF EXISTS user_auth_accounts_user_provider_null_account_uidx;
DROP INDEX IF EXISTS workspace_memberships_active_owner_uidx;
DROP INDEX IF EXISTS workspace_invitations_active_email_uidx;
DROP INDEX IF EXISTS meetings_agent_intro_creator_uidx;
DROP INDEX IF EXISTS meetings_one_current_per_link_uidx;
DROP INDEX IF EXISTS meeting_join_requests_active_user_uidx;
DROP INDEX IF EXISTS agent_profiles_default_user_uidx;
DROP INDEX IF EXISTS meeting_turns_active_meeting_uidx;
DROP INDEX IF EXISTS agent_connectors_user_provider_null_account_active_uidx;
DROP INDEX IF EXISTS agent_connectors_user_provider_account_active_uidx;
DROP INDEX IF EXISTS calendar_sync_subscriptions_active_connector_calendar_uidx;
DROP INDEX IF EXISTS calendar_event_preps_user_event_fingerprint_legacy_uidx;
DROP INDEX IF EXISTS mail_accounts_user_provider_account_uidx;
DROP INDEX IF EXISTS mail_accounts_user_provider_email_uidx;
DROP INDEX IF EXISTS mail_sync_subscriptions_active_account_kind_uidx;
DROP INDEX IF EXISTS mail_threads_account_fallback_participants_subject_uidx;
DROP INDEX IF EXISTS meeting_research_runs_active_recommendation_uidx;
DROP INDEX IF EXISTS billing_checkout_attempts_pending_uidx;

-- Keep the live product-write functions, including 0119's projection merge.
-- Their keys and foreign keys remain; concurrent trial allocations may need retry.
CREATE OR REPLACE FUNCTION public.canonicalize_memory_people_write()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
 NEW.person_ids=ARRAY(SELECT DISTINCT canonical_memory_person(id) FROM unnest(NEW.person_ids) id);
 NEW.candidate_subject_id=canonical_memory_person(NEW.candidate_subject_id);
 RETURN NEW;
END $function$;

CREATE OR REPLACE FUNCTION public.prevent_redirected_memory_projection()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
 IF EXISTS(SELECT 1 FROM memory_person_redirects WHERE person_id=NEW.person_id) THEN RETURN NULL; END IF;
 RETURN NEW;
END $function$;

CREATE OR REPLACE FUNCTION public.allocate_completed_meeting_trial_slot()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE m meetings%ROWTYPE; next_slot smallint; notes_workspace_id uuid;
BEGIN
 SELECT * INTO m FROM meetings WHERE id=NEW.meeting_id;
 IF m.kind<>'standard' OR m.status<>'ended' OR m.hidden_from_history_reason IS NOT NULL
   OR m.started_at IS NULL OR m.ended_at<m.started_at+interval '10 seconds'
   OR NEW.model IN ('short-meeting-v1','fallback-summary-v1') THEN RETURN NEW; END IF;
 SELECT coalesce((SELECT a.workspace_id FROM meeting_attendee_workspaces a
   WHERE a.meeting_id=m.id AND a.user_id=m.created_by_user_id),m.workspace_id) INTO notes_workspace_id;
 IF EXISTS(SELECT 1 FROM meeting_trial_slots WHERE user_id=m.created_by_user_id AND meeting_id=m.id) THEN RETURN NEW; END IF;
 SELECT candidate INTO next_slot FROM generate_series(1,3) candidate
   WHERE NOT EXISTS(SELECT 1 FROM meeting_trial_slots t WHERE t.user_id=m.created_by_user_id
     AND t.workspace_id=notes_workspace_id AND t.slot=candidate) ORDER BY candidate LIMIT 1;
 IF next_slot IS NOT NULL THEN
   INSERT INTO meeting_trial_slots(user_id,workspace_id,meeting_id,slot)
     VALUES(m.created_by_user_id,notes_workspace_id,m.id,next_slot);
 END IF;
 RETURN NEW;
END $function$;

CREATE OR REPLACE FUNCTION public.link_guest_memory_account(guest_id uuid, account_id uuid)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE browser_id uuid; account_name text; account_email text; scope record; winner uuid; loser record;
BEGIN
 SELECT display_name,lower(trim(email)) INTO account_name,account_email FROM users WHERE id=account_id AND source IN('auth','dev_login') AND deleted_at IS NULL;
 IF account_name IS NULL OR NOT EXISTS(SELECT 1 FROM users WHERE id=guest_id AND source='guest') THEN
  RAISE EXCEPTION 'Invalid guest account link';
 END IF;
 SELECT b.browser_id INTO browser_id FROM guest_browser_users b WHERE b.guest_user_id=guest_id;
 IF EXISTS(SELECT 1 FROM guest_memory_account_links WHERE guest_user_id=guest_id AND account_user_id<>account_id)
 OR EXISTS(SELECT 1 FROM guest_browser_identities WHERE id=browser_id AND linked_account_user_id IS NOT NULL AND linked_account_user_id<>account_id) THEN
  RAISE EXCEPTION 'Guest recognition is already linked to another account' USING ERRCODE='23505';
 END IF;
 INSERT INTO guest_memory_account_links VALUES(guest_id,account_id) ON CONFLICT DO NOTHING;
 UPDATE guest_browser_identities SET linked_account_user_id=account_id WHERE id=browser_id;
 FOR scope IN
  SELECT DISTINCT i.user_id,i.workspace_id FROM memory_person_identities i
  WHERE ((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email))
   OR (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id))
  ORDER BY i.user_id,i.workspace_id
 LOOP
  -- Keep the guest/browser person already shown to this owner whenever possible.
  SELECT i.person_id INTO winner FROM memory_person_identities i
  WHERE i.user_id=scope.user_id AND i.workspace_id=scope.workspace_id AND
   (((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email)) OR
    (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id)))
  ORDER BY CASE WHEN i.kind='guest_browser' AND i.identity=browser_id::text THEN 0
    WHEN i.kind='user_id' AND i.identity=guest_id::text THEN 1 ELSE 2 END,i.person_id LIMIT 1;
  -- Preserve an observed guest spelling even for guests who never opted into browser recognition.
  INSERT INTO memory_person_names(person_id,source_id,participant_user_id,name,normalized_name,word_count,observed_at)
   SELECT winner,mi.source_id,guest_id,u.display_name,lower(trim(u.display_name)),
    CASE WHEN lower(trim(u.display_name))='guest' THEN 0 ELSE cardinality(regexp_split_to_array(trim(u.display_name),'\s+')) END,mi.occurred_at
   FROM memory_interactions mi JOIN memory_person_identities gi ON gi.person_id=mi.person_id
   JOIN users u ON u.id=guest_id
   WHERE gi.user_id=scope.user_id AND gi.workspace_id=scope.workspace_id AND gi.kind='user_id' AND gi.identity=guest_id::text
   ON CONFLICT DO NOTHING;
  FOR loser IN
   SELECT DISTINCT i.person_id FROM memory_person_identities i
   WHERE i.user_id=scope.user_id AND i.workspace_id=scope.workspace_id AND i.person_id<>winner AND
    (((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email)) OR
     (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id)))
  LOOP
   INSERT INTO memory_interactions SELECT source_id,winner,occurred_at FROM memory_interactions WHERE person_id=loser.person_id ON CONFLICT DO NOTHING;
   DELETE FROM memory_interactions WHERE person_id=loser.person_id;
   INSERT INTO memory_person_names SELECT winner,source_id,participant_user_id,name,normalized_name,word_count,observed_at FROM memory_person_names WHERE person_id=loser.person_id ON CONFLICT DO NOTHING;
   DELETE FROM memory_person_names WHERE person_id=loser.person_id;
   UPDATE memory_person_identities SET person_id=winner WHERE person_id=loser.person_id;
   UPDATE memory_person_redirects SET target_person_id=winner WHERE target_person_id=loser.person_id;
   INSERT INTO memory_person_redirects VALUES(loser.person_id,winner) ON CONFLICT(person_id) DO UPDATE SET target_person_id=excluded.target_person_id;
   UPDATE relationship_memories SET person_ids=array_replace(person_ids,loser.person_id,winner),
    candidate_subject_id=CASE WHEN candidate_subject_id=loser.person_id THEN winner ELSE candidate_subject_id END
    WHERE loser.person_id=ANY(person_ids) OR candidate_subject_id=loser.person_id;
   PERFORM consolidate_memory_projections(winner,loser.person_id);
  END LOOP;
  INSERT INTO memory_person_identities VALUES(winner,scope.user_id,scope.workspace_id,'user_id',account_id::text) ON CONFLICT DO NOTHING;
  UPDATE memory_people SET name=account_name WHERE id=winner;
 END LOOP;
END $function$;
