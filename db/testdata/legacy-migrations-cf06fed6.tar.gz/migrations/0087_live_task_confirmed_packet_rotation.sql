ALTER TABLE meeting_live_task_cursors
  ADD COLUMN IF NOT EXISTS confirmed_task_offset integer NOT NULL DEFAULT 0;
