-- Workspace-subject billing plumbing (dark launch). Additive only: the
-- user-keyed billing tables keep working untouched until the phase-3 cutover.

-- Workspaces gain their own plan, written by subscription webhooks. The
-- existing user_plan enum is reused; users.plan survives as the manual /
-- admin entitlement knob.
ALTER TABLE workspaces
  ADD COLUMN IF NOT EXISTS plan user_plan NOT NULL DEFAULT 'free';

-- Separate table (rather than widening billing_customers) because that
-- table's primary key is user_id.
CREATE TABLE IF NOT EXISTS workspace_billing_customers (
  workspace_id uuid PRIMARY KEY REFERENCES workspaces(id) ON DELETE CASCADE,
  stripe_customer_id varchar(255) NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Workspace subscriptions live in the same table as legacy user
-- subscriptions; workspace_id NULL means a legacy user-keyed row. Phase 3
-- migrates every row and sets workspace_id NOT NULL.
ALTER TABLE billing_subscriptions
  ADD COLUMN IF NOT EXISTS workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE;
ALTER TABLE billing_subscriptions
  ADD COLUMN IF NOT EXISTS seat_quantity integer NOT NULL DEFAULT 1;
CREATE INDEX IF NOT EXISTS billing_subscriptions_workspace_idx
  ON billing_subscriptions(workspace_id, updated_at)
  WHERE workspace_id IS NOT NULL;

-- Credit grants become subject-polymorphic: user grants (legacy + trial-era)
-- keep user_id; workspace pool grants (purchased top-ups shared by the
-- workspace) set workspace_id. Exactly one subject per row.
ALTER TABLE credit_grants
  ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE credit_grants
  ADD COLUMN IF NOT EXISTS workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE;
DO $$
BEGIN
  ALTER TABLE credit_grants
    ADD CONSTRAINT credit_grants_subject_check
    CHECK ((user_id IS NULL) <> (workspace_id IS NULL));
EXCEPTION WHEN duplicate_object THEN null;
END $$;
CREATE INDEX IF NOT EXISTS credit_grants_workspace_active_idx
  ON credit_grants(workspace_id, expires_at, created_at)
  WHERE workspace_id IS NOT NULL;

-- Usage events carry the owning workspace so per-member allowance math and
-- the per-(user, workspace) trial gate can be computed with one SUM.
ALTER TABLE ai_credit_usage_events
  ADD COLUMN IF NOT EXISTS workspace_id uuid REFERENCES workspaces(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS ai_credit_usage_events_workspace_user_idx
  ON ai_credit_usage_events(workspace_id, user_id, created_at)
  WHERE workspace_id IS NOT NULL;

-- Coalescing outbox for Stripe seat-quantity syncs (realtime_outbox
-- precedent): membership mutations enqueue inside their own transaction, the
-- seat-sync worker drains with retry/backoff, and the partial unique index
-- collapses any number of membership changes into one pending row per
-- workspace.
CREATE TABLE IF NOT EXISTS billing_seat_sync_outbox (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  status varchar(16) NOT NULL DEFAULT 'pending',
  reason text NOT NULL DEFAULT 'membership_change',
  attempt_count integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  locked_by varchar(160),
  locked_at timestamptz,
  last_error text,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS billing_seat_sync_outbox_pending_uidx
  ON billing_seat_sync_outbox(workspace_id)
  WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS billing_seat_sync_outbox_due_idx
  ON billing_seat_sync_outbox(status, next_attempt_at);
