-- The trial is consumed by delivered notes, never by scheduling a meeting.
-- A deleted meeting retains its consumed slot; account/workspace deletion does not.
-- The migration runner holds one transaction for this entire file. Block summary
-- writes before reading history and until the allocation trigger is committed,
-- so every delivery is handled by either the backfill or the live trigger.
LOCK TABLE summaries IN SHARE ROW EXCLUSIVE MODE;

CREATE TABLE meeting_trial_slots (
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
 meeting_id uuid REFERENCES meetings(id) ON DELETE SET NULL,
 slot smallint NOT NULL CHECK(slot BETWEEN 1 AND 3),
 allocated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(user_id,workspace_id,slot),
 UNIQUE(user_id,meeting_id)
);

-- Historical policy: seed the earliest three eligible completed meetings by
-- ended_at, then id. Historical summaries do not retain an immutable first
-- successful delivery timestamp, so this does not reconstruct delivery order.
INSERT INTO meeting_trial_slots(user_id,workspace_id,meeting_id,slot)
 SELECT created_by_user_id,workspace_id,id,position FROM (
   SELECT m.id,m.created_by_user_id,coalesce(a.workspace_id,m.workspace_id) AS workspace_id,
     row_number() OVER(PARTITION BY m.created_by_user_id,coalesce(a.workspace_id,m.workspace_id) ORDER BY m.ended_at,m.id) AS position
   FROM meetings m JOIN summaries s ON s.meeting_id=m.id
   LEFT JOIN meeting_attendee_workspaces a ON a.meeting_id=m.id AND a.user_id=m.created_by_user_id
   WHERE m.kind='standard' AND m.status='ended' AND m.hidden_from_history_reason IS NULL
     AND m.ended_at>=m.started_at+interval '10 seconds' AND s.model NOT IN ('short-meeting-v1','fallback-summary-v1')
 ) eligible WHERE position<=3;

-- Live policy: the first successful deliveries to acquire the scope lock claim
-- the remaining slots. Delayed summaries never displace an allocated meeting.
CREATE FUNCTION allocate_completed_meeting_trial_slot() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE m meetings%ROWTYPE; next_slot smallint; notes_workspace_id uuid;
BEGIN
 SELECT * INTO m FROM meetings WHERE id=NEW.meeting_id;
 IF m.kind<>'standard' OR m.status<>'ended' OR m.hidden_from_history_reason IS NOT NULL
   OR m.started_at IS NULL OR m.ended_at<m.started_at+interval '10 seconds'
   OR NEW.model IN ('short-meeting-v1','fallback-summary-v1') THEN RETURN NEW; END IF;
 SELECT coalesce((SELECT a.workspace_id FROM meeting_attendee_workspaces a
   WHERE a.meeting_id=m.id AND a.user_id=m.created_by_user_id),m.workspace_id) INTO notes_workspace_id;
 PERFORM pg_advisory_xact_lock(hashtext('meeting-trial:'||m.created_by_user_id::text||':'||notes_workspace_id::text));
 IF EXISTS(SELECT 1 FROM meeting_trial_slots WHERE user_id=m.created_by_user_id AND meeting_id=m.id) THEN RETURN NEW; END IF;
 SELECT candidate INTO next_slot FROM generate_series(1,3) candidate
   WHERE NOT EXISTS(SELECT 1 FROM meeting_trial_slots t WHERE t.user_id=m.created_by_user_id
     AND t.workspace_id=notes_workspace_id AND t.slot=candidate) ORDER BY candidate LIMIT 1;
 IF next_slot IS NOT NULL THEN
   INSERT INTO meeting_trial_slots(user_id,workspace_id,meeting_id,slot)
     VALUES(m.created_by_user_id,notes_workspace_id,m.id,next_slot);
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER allocate_completed_meeting_trial_slot AFTER INSERT OR UPDATE ON summaries
 FOR EACH ROW EXECUTE FUNCTION allocate_completed_meeting_trial_slot();
