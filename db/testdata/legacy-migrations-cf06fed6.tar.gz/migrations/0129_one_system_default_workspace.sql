-- One automatic signup workspace per user. Concurrent first sign-in reuses it.
SET LOCAL lock_timeout = '3min';
SET LOCAL statement_timeout = 0;

UPDATE workspaces AS older
SET created_via = 'system_replacement'
WHERE older.created_via = 'system_default'
  AND older.created_by_user_id IS NOT NULL
  AND EXISTS (
    SELECT 1
    FROM workspaces AS newer
    WHERE newer.created_by_user_id = older.created_by_user_id
      AND newer.created_via = 'system_default'
      AND (newer.created_at, newer.id) < (older.created_at, older.id)
  );

CREATE UNIQUE INDEX workspaces_one_system_default_per_creator_uidx
  ON workspaces (created_by_user_id)
  WHERE created_via = 'system_default';
