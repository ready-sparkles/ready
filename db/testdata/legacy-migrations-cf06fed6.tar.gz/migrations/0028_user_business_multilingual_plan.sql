ALTER TYPE user_plan ADD VALUE IF NOT EXISTS 'business_multilingual' AFTER 'business';
