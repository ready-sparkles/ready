ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'deliver_meeting_to_slack';

CREATE TABLE IF NOT EXISTS slack_delivery_configs (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  routes jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS slack_meeting_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  meeting_id uuid NOT NULL UNIQUE REFERENCES meetings(id) ON DELETE CASCADE,
  status varchar(32) NOT NULL,
  category varchar(64),
  channel_id text,
  channel_name text,
  skip_reason text,
  message_ts text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS slack_meeting_deliveries_user_idx
  ON slack_meeting_deliveries (user_id, created_at);
