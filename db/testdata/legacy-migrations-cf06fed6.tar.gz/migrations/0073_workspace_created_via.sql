-- Distinguish system-created workspaces (auto-created at signup, or as a
-- replacement when a user's last workspace is deleted) from workspaces a user
-- created deliberately. Invitation acceptance only cleans up system-created
-- signup artifacts; deliberate workspaces must never be auto-deleted.
--
-- Existing rows default to 'user': pre-migration signup workspaces cannot be
-- told apart from deliberate ones, so they are conservatively kept.
ALTER TABLE workspaces
  ADD COLUMN created_via varchar(24) NOT NULL DEFAULT 'user';
