ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'track_meeting';
