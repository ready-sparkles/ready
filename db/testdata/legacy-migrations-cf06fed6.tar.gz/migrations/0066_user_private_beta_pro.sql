ALTER TABLE users
  ADD COLUMN private_beta_pro_enabled_at timestamp with time zone;

-- Billing customers can exist for one-off top-ups, so customer history is not
-- evidence of an active Stripe plan. Backfill explicit private-beta Pro for
-- existing non-free users unless their latest subscription row is still in an
-- unlocked Stripe status; that excludes current subscribers and stale
-- subscribers whose downgrade webhook has not landed yet, while preserving
-- admin-assigned users with only top-up history or old canceled/expired rows.
WITH latest_billing_subscription AS (
  SELECT DISTINCT ON (user_id)
    user_id,
    status
  FROM billing_subscriptions
  ORDER BY user_id, updated_at DESC, created_at DESC
)
UPDATE users u
SET private_beta_pro_enabled_at = now()
WHERE u.plan <> 'free'
  AND NOT EXISTS (
    SELECT 1
    FROM latest_billing_subscription lbs
    WHERE lbs.user_id = u.id
      AND lbs.status IN ('active', 'trialing', 'past_due')
  );
