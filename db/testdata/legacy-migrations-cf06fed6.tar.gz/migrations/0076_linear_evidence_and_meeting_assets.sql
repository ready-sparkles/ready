alter table meeting_tasks
  add column if not exists asset_ids jsonb not null default '[]'::jsonb;

create table if not exists meeting_assets (
  id uuid primary key default gen_random_uuid(),
  meeting_id uuid not null references meetings(id) on delete cascade,
  kind varchar(32) not null default 'screen_capture',
  storage_key text not null unique,
  content_hash varchar(64) not null,
  mime_type varchar(64) not null,
  byte_size integer not null,
  width integer,
  height integer,
  captured_at timestamptz not null,
  participant_identity text,
  track_sid text,
  trigger varchar(64) not null,
  transcript_segment_ids jsonb not null default '[]'::jsonb,
  transcript_excerpt text,
  speaker_name varchar(120),
  include_in_linear boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists meeting_assets_meeting_captured_idx
  on meeting_assets(meeting_id, captured_at);

create unique index if not exists meeting_assets_meeting_hash_uidx
  on meeting_assets(meeting_id, content_hash);

alter table linear_task_review_items
  add column if not exists issue_draft jsonb,
  add column if not exists duplicate_issues jsonb not null default '[]'::jsonb,
  add column if not exists target_action varchar(32) not null default 'create',
  add column if not exists target_issue jsonb,
  add column if not exists relation_id text;
