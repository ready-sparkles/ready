CREATE TABLE IF NOT EXISTS google_addon_conferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  idempotency_key varchar(64) NOT NULL,
  meeting_link_id uuid NOT NULL REFERENCES meeting_links(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS google_addon_conferences_user_key_uidx
  ON google_addon_conferences(user_id, idempotency_key);

CREATE INDEX IF NOT EXISTS google_addon_conferences_meeting_link_idx
  ON google_addon_conferences(meeting_link_id);
