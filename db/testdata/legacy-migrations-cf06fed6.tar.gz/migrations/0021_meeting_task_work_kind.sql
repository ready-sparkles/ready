CREATE TYPE meeting_task_work_kind AS ENUM (
  'bug_or_issue',
  'implementation',
  'design',
  'research',
  'customer_follow_up',
  'sales_or_crm',
  'scheduling',
  'documentation',
  'general'
);

ALTER TABLE meeting_tasks
  ADD COLUMN work_kind meeting_task_work_kind NOT NULL DEFAULT 'general';

CREATE INDEX meeting_tasks_work_kind_idx ON meeting_tasks(work_kind);
