-- New meetings are participant-only by default. Existing rows retain their
-- current confidentiality value; eligible non-1:1 meetings can be unlocked.
ALTER TABLE meetings
  ALTER COLUMN is_confidential SET DEFAULT true;
