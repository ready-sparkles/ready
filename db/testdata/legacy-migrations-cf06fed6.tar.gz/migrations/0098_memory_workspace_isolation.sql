-- Remove only derived data attached to the wrong workspace. Keep the meetings,
-- transcripts, valid extractions and historical discovery cursors unchanged.
-- Stop old writers until cleanup and the boundary constraint commit together.
LOCK TABLE memory_jobs, memory_sources IN ACCESS EXCLUSIVE MODE;
CREATE TEMP TABLE memory_misplaced_sources ON COMMIT DROP AS
 SELECT s.id,s.user_id,s.workspace_id FROM memory_sources s JOIN meetings m ON m.id=s.meeting_id
 WHERE s.workspace_id IS DISTINCT FROM m.workspace_id;
CREATE TEMP TABLE memory_affected_people ON COMMIT DROP AS
 SELECT person_id AS id FROM memory_interactions WHERE source_id IN(SELECT id FROM memory_misplaced_sources)
 UNION SELECT unnest(person_ids) FROM relationship_memories WHERE source_id IN(SELECT id FROM memory_misplaced_sources)
 UNION SELECT candidate_subject_id FROM relationship_memories WHERE source_id IN(SELECT id FROM memory_misplaced_sources) AND candidate_subject_id IS NOT NULL;

DELETE FROM memory_person_projections WHERE person_id IN(SELECT id FROM memory_affected_people);
-- Cascades to memories, evidence, interactions, suppression records, extraction
-- jobs and their checkpoints. A removed job's old lease cannot publish again.
DELETE FROM memory_sources WHERE id IN(SELECT id FROM memory_misplaced_sources);
DELETE FROM memory_people p WHERE p.id IN(SELECT id FROM memory_affected_people)
 AND NOT EXISTS(SELECT 1 FROM memory_interactions i WHERE i.person_id=p.id)
 AND NOT EXISTS(SELECT 1 FROM relationship_memories r WHERE p.id=ANY(r.person_ids) OR r.candidate_subject_id=p.id);

-- Rebuild only summaries whose support changed and still has local interactions.
-- This never requeues a valid completed meeting extraction.
INSERT INTO memory_jobs(user_id,workspace_id,kind,dedupe_key,preferences_revision,prompt_version,priority)
 SELECT DISTINCT p.user_id,p.workspace_id,'project',
   'workspace-isolation-v1:'||p.user_id::text||':'||p.workspace_id::text||':'||prefs.revision::text,
   prefs.revision,'1.2.0',1
 FROM memory_people p JOIN memory_preferences prefs USING(user_id,workspace_id)
 WHERE p.id IN(SELECT id FROM memory_affected_people)
 ON CONFLICT(dedupe_key) DO NOTHING;

-- Enforce the boundary even for older workers during a rolling deployment.
ALTER TABLE meetings ADD CONSTRAINT meetings_id_workspace_unique UNIQUE(id,workspace_id);
ALTER TABLE memory_sources ADD CONSTRAINT memory_source_meeting_workspace_fk
 FOREIGN KEY(meeting_id,workspace_id) REFERENCES meetings(id,workspace_id) ON DELETE CASCADE;
