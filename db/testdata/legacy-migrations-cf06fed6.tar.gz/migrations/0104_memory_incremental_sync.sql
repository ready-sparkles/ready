-- A per-owner counter is transactional (unlike a sequence): a later committed
-- cursor can never skip an earlier transaction that has not committed yet.
CREATE TABLE memory_sync_heads (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  version bigint NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, workspace_id)
);
-- Keep the latest change, including tombstones, rather than an unbounded event log.
CREATE TABLE memory_sync_changes (
  user_id uuid NOT NULL,
  workspace_id uuid NOT NULL,
  memory_id uuid NOT NULL,
  source_id uuid NOT NULL,
  version bigint NOT NULL,
  PRIMARY KEY(user_id, workspace_id, memory_id),
  FOREIGN KEY(user_id, workspace_id) REFERENCES memory_sync_heads ON DELETE CASCADE
);
CREATE INDEX memory_sync_changes_cursor ON memory_sync_changes(user_id, workspace_id, version);

INSERT INTO memory_sync_heads(user_id, workspace_id)
SELECT DISTINCT user_id, workspace_id FROM memory_sources;
INSERT INTO memory_sync_changes(user_id, workspace_id, memory_id, source_id, version)
SELECT s.user_id, s.workspace_id, r.id, r.source_id, 0
FROM relationship_memories r JOIN memory_sources s ON s.id=r.source_id;

CREATE FUNCTION mark_memory_sync_change(p_memory_id uuid, p_source_id uuid) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE owner_id uuid; owner_workspace uuid; next_version bigint;
BEGIN
  SELECT s.user_id, s.workspace_id INTO owner_id, owner_workspace
  FROM memory_sources s JOIN users u ON u.id=s.user_id JOIN workspaces w ON w.id=s.workspace_id
  WHERE s.id=p_source_id;
  IF NOT FOUND THEN RETURN; END IF;
  INSERT INTO memory_sync_heads(user_id, workspace_id, version) VALUES(owner_id, owner_workspace, 1)
  ON CONFLICT(user_id, workspace_id) DO UPDATE SET version=memory_sync_heads.version+1
  RETURNING version INTO next_version;
  INSERT INTO memory_sync_changes(user_id, workspace_id, memory_id, source_id, version)
  VALUES(owner_id, owner_workspace, p_memory_id, p_source_id, next_version)
  ON CONFLICT(user_id, workspace_id, memory_id) DO UPDATE
  SET source_id=excluded.source_id, version=excluded.version;
END $$;
CREATE FUNCTION track_memory_sync_row() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP='DELETE' THEN
    PERFORM mark_memory_sync_change(OLD.id, OLD.source_id);
    RETURN OLD;
  END IF;
  PERFORM mark_memory_sync_change(NEW.id, NEW.source_id);
  RETURN NEW;
END $$;
CREATE TRIGGER memory_sync_row AFTER INSERT OR UPDATE OR DELETE ON relationship_memories
FOR EACH ROW EXECUTE FUNCTION track_memory_sync_row();
CREATE FUNCTION track_memory_sync_evidence() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE target_id uuid; source uuid;
BEGIN
  target_id := CASE WHEN TG_OP='DELETE' THEN OLD.memory_id ELSE NEW.memory_id END;
  SELECT source_id INTO source FROM relationship_memories WHERE id=target_id;
  IF FOUND THEN PERFORM mark_memory_sync_change(target_id, source); END IF;
  IF TG_OP='UPDATE' AND OLD.memory_id<>NEW.memory_id THEN
    SELECT source_id INTO source FROM relationship_memories WHERE id=OLD.memory_id;
    IF FOUND THEN PERFORM mark_memory_sync_change(OLD.memory_id, source); END IF;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER memory_sync_evidence AFTER INSERT OR UPDATE OR DELETE ON memory_evidence
FOR EACH ROW EXECUTE FUNCTION track_memory_sync_evidence();
CREATE FUNCTION track_memory_sync_source() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE memory_id uuid;
BEGIN
  IF OLD.is_current IS DISTINCT FROM NEW.is_current OR OLD.include_sensitive IS DISTINCT FROM NEW.include_sensitive THEN
    FOR memory_id IN SELECT id FROM relationship_memories WHERE source_id=NEW.id ORDER BY id LOOP
      PERFORM mark_memory_sync_change(memory_id, NEW.id);
    END LOOP;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER memory_sync_source AFTER UPDATE OF is_current, include_sensitive ON memory_sources
FOR EACH ROW EXECUTE FUNCTION track_memory_sync_source();
