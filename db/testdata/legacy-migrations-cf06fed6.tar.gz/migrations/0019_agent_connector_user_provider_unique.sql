WITH ranked_connectors AS (
  SELECT
    id,
    user_id,
    provider,
    row_number() OVER (
      PARTITION BY user_id, provider
      ORDER BY updated_at DESC, created_at DESC, id DESC
    ) AS rank
  FROM agent_connectors
),
connector_keepers AS (
  SELECT id, user_id, provider
  FROM ranked_connectors
  WHERE rank = 1
),
duplicate_connectors AS (
  SELECT id, user_id, provider
  FROM ranked_connectors
  WHERE rank > 1
)
UPDATE agent_connector_secrets
SET agent_connector_id = connector_keepers.id
FROM duplicate_connectors
JOIN connector_keepers
  ON connector_keepers.user_id = duplicate_connectors.user_id
  AND connector_keepers.provider = duplicate_connectors.provider
WHERE agent_connector_secrets.agent_connector_id = duplicate_connectors.id;

WITH ranked_connectors AS (
  SELECT
    id,
    row_number() OVER (
      PARTITION BY user_id, provider
      ORDER BY updated_at DESC, created_at DESC, id DESC
    ) AS rank
  FROM agent_connectors
)
DELETE FROM agent_connectors
WHERE id IN (
  SELECT id
  FROM ranked_connectors
  WHERE rank > 1
);

DROP INDEX IF EXISTS agent_connectors_user_idx;

CREATE UNIQUE INDEX IF NOT EXISTS agent_connectors_user_provider_uidx
  ON agent_connectors(user_id, provider);
