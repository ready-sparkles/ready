ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'review_linear_tasks';

CREATE TABLE IF NOT EXISTS linear_task_review_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  task_list_id uuid NOT NULL REFERENCES meeting_task_lists(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  connector_id uuid REFERENCES agent_connectors(id) ON DELETE SET NULL,
  status varchar(32) NOT NULL DEFAULT 'queued',
  phase varchar(64) NOT NULL DEFAULT 'queued',
  input_hash varchar(64) NOT NULL,
  model varchar(160),
  prompt_version varchar(160),
  error text,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS linear_task_review_runs_meeting_created_idx
  ON linear_task_review_runs(meeting_id, created_at);
CREATE INDEX IF NOT EXISTS linear_task_review_runs_status_updated_idx
  ON linear_task_review_runs(status, updated_at);
CREATE UNIQUE INDEX IF NOT EXISTS linear_task_review_runs_meeting_input_uidx
  ON linear_task_review_runs(meeting_id, input_hash);

CREATE TABLE IF NOT EXISTS linear_task_review_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id uuid NOT NULL REFERENCES linear_task_review_runs(id) ON DELETE CASCADE,
  position integer NOT NULL,
  source_task_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  decision varchar(24) NOT NULL,
  confidence integer NOT NULL,
  reasoning text NOT NULL,
  title varchar(160) NOT NULL,
  description text,
  team_id text,
  team_name text,
  included boolean NOT NULL DEFAULT true,
  sync_status varchar(24) NOT NULL DEFAULT 'pending',
  sync_error text,
  external_issue_id text,
  external_issue_identifier text,
  external_issue_title text,
  external_issue_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT linear_task_review_items_confidence_check CHECK (confidence BETWEEN 0 AND 100)
);

CREATE UNIQUE INDEX IF NOT EXISTS linear_task_review_items_run_position_uidx
  ON linear_task_review_items(run_id, position);
CREATE INDEX IF NOT EXISTS linear_task_review_items_run_idx
  ON linear_task_review_items(run_id);
