ALTER TABLE workspace_invitations
  ADD CONSTRAINT workspace_invitations_no_owner_role_chk
  CHECK (role <> 'owner');

-- Make the rollout self-reconciling: the existing worker will compare every
-- running workspace subscription with the newly backfilled active roster and
-- correct Stripe quantities using its normal durable retry path.
INSERT INTO billing_seat_sync_outbox (workspace_id, reason)
SELECT DISTINCT workspace_id, 'owner_role_rollout'
FROM billing_subscriptions
WHERE workspace_id IS NOT NULL
  AND status IN ('active', 'trialing', 'past_due')
ON CONFLICT (workspace_id) WHERE status = 'pending' DO UPDATE
SET reason = EXCLUDED.reason,
    next_attempt_at = now(),
    last_error = NULL,
    updated_at = now();
