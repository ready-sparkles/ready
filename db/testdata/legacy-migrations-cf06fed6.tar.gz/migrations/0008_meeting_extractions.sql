DO $$
BEGIN
  CREATE TYPE meeting_type AS ENUM (
    'team_sync',
    'one_on_one',
    'sales_call',
    'customer_success',
    'product_review',
    'standup',
    'hiring_debrief',
    'exec_review',
    'planning',
    'brainstorm',
    'interview',
    'retrospective',
    'postmortem',
    'manager_check_in',
    'other'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE extraction_status AS ENUM (
    'pending',
    'running',
    'completed',
    'partial',
    'failed'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE extraction_confidence AS ENUM (
    'low',
    'medium',
    'high'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS meeting_extractions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  status extraction_status NOT NULL DEFAULT 'pending',
  meeting_type meeting_type,
  meeting_type_confidence extraction_confidence,
  meeting_type_reasoning text,
  participants jsonb NOT NULL DEFAULT '[]'::jsonb,
  summary_short text,
  summary_bullets jsonb NOT NULL DEFAULT '[]'::jsonb,
  decisions jsonb NOT NULL DEFAULT '[]'::jsonb,
  action_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  open_questions jsonb NOT NULL DEFAULT '[]'::jsonb,
  risks jsonb NOT NULL DEFAULT '[]'::jsonb,
  key_topics jsonb NOT NULL DEFAULT '[]'::jsonb,
  signals jsonb NOT NULL DEFAULT '[]'::jsonb,
  failed_tool_calls jsonb NOT NULL DEFAULT '[]'::jsonb,
  extraction_model varchar(160) NOT NULL,
  extraction_prompt_version varchar(32) NOT NULL,
  transcript_hash varchar(128) NOT NULL,
  duration_ms integer,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_extractions_meeting_uidx
  ON meeting_extractions(meeting_id);

CREATE INDEX IF NOT EXISTS meeting_extractions_status_idx
  ON meeting_extractions(status);

CREATE INDEX IF NOT EXISTS meeting_extractions_completed_at_idx
  ON meeting_extractions(completed_at);
