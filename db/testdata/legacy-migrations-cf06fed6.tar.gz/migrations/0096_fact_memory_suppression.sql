-- Fact identity is separate from display wording and supporting evidence.
ALTER TABLE relationship_memories ADD COLUMN fact_fingerprint text;
ALTER TABLE relationship_memories ADD COLUMN fact_identity jsonb;
UPDATE relationship_memories SET fact_fingerprint='legacy:'||fingerprint,
 fact_identity=jsonb_build_object('subject',array_to_string(person_ids,','),
   'predicate','legacy development','object',description,'context',title);
ALTER TABLE relationship_memories ALTER COLUMN fact_fingerprint SET NOT NULL;
ALTER TABLE relationship_memories ALTER COLUMN fact_identity SET NOT NULL;
CREATE INDEX memory_fact_lookup ON relationship_memories(source_id,fact_fingerprint);

-- Deleted facts cannot be recovered from the old segment-only tombstones.
-- Retain these as a regeneration guard, never as a candidate segment filter.
ALTER TABLE memory_suppressions RENAME TO memory_legacy_suppressions;
CREATE TABLE memory_suppressions (
 source_id uuid NOT NULL REFERENCES memory_sources(id) ON DELETE CASCADE,
 fact_fingerprint text NOT NULL, fact_identity jsonb NOT NULL,
 PRIMARY KEY(source_id,fact_fingerprint)
);
