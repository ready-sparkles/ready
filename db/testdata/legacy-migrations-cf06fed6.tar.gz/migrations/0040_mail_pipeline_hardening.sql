ALTER TYPE mail_job_type ADD VALUE IF NOT EXISTS 'initial_backfill_scan';
ALTER TYPE mail_job_type ADD VALUE IF NOT EXISTS 'initial_backfill_ingest_batch';
ALTER TYPE mail_job_type ADD VALUE IF NOT EXISTS 'bounded_resync_scan';
ALTER TYPE mail_job_type ADD VALUE IF NOT EXISTS 'bounded_resync_ingest_batch';

WITH duplicate_classifier_jobs AS (
  SELECT
    id,
    row_number() OVER (
      PARTITION BY thread_id, coalesce(payload->>'classifierVersion', '')
      ORDER BY created_at ASC, id ASC
    ) AS rank
  FROM mail_jobs
  WHERE job_type = 'classify_surface'
    AND status IN ('queued', 'running')
    AND thread_id IS NOT NULL
)
UPDATE mail_jobs
SET
  status = 'cancelled',
  result = jsonb_build_object('cancelledByMigration', '0040_mail_pipeline_hardening'),
  updated_at = now(),
  locked_by = NULL,
  locked_at = NULL
WHERE id IN (
  SELECT id
  FROM duplicate_classifier_jobs
  WHERE rank > 1
);

WITH duplicate_summary_jobs AS (
  SELECT
    id,
    row_number() OVER (
      PARTITION BY thread_id, coalesce(payload->>'summaryPromptVersion', '')
      ORDER BY created_at ASC, id ASC
    ) AS rank
  FROM mail_jobs
  WHERE job_type = 'generate_summary'
    AND status IN ('queued', 'running')
    AND thread_id IS NOT NULL
)
UPDATE mail_jobs
SET
  status = 'cancelled',
  result = jsonb_build_object('cancelledByMigration', '0040_mail_pipeline_hardening'),
  updated_at = now(),
  locked_by = NULL,
  locked_at = NULL
WHERE id IN (
  SELECT id
  FROM duplicate_summary_jobs
  WHERE rank > 1
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_jobs_active_classifier_thread_version_uidx
  ON mail_jobs(thread_id, (coalesce(payload->>'classifierVersion', '')))
  WHERE job_type = 'classify_surface'
    AND status IN ('queued', 'running')
    AND thread_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS mail_jobs_active_summary_thread_version_uidx
  ON mail_jobs(thread_id, (coalesce(payload->>'summaryPromptVersion', '')))
  WHERE job_type = 'generate_summary'
    AND status IN ('queued', 'running')
    AND thread_id IS NOT NULL;
