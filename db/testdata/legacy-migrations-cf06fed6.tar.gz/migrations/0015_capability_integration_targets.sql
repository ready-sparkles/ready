UPDATE capability_catalog
SET
  description = CASE key
    WHEN 'create_task_list' THEN 'Create project tasks from non-bug commitments, owners, and due-date hints.'
    WHEN 'file_issue_or_bug' THEN 'File engineering issues from surfaced defects with impact, severity, and reproduction context.'
    ELSE description
  END,
  example_triggers = CASE key
    WHEN 'create_task_list' THEN '[]'::jsonb
    ELSE example_triggers
  END,
  metadata = jsonb_set(
    coalesce(metadata, '{}'::jsonb),
    '{integrationTargets}',
    CASE key
      WHEN 'draft_internal_recap' THEN '["Slack", "Microsoft Teams", "Notion", "Google Docs"]'::jsonb
      WHEN 'draft_external_follow_up' THEN '["Gmail", "Outlook", "HubSpot", "Salesforce"]'::jsonb
      WHEN 'draft_decision_brief' THEN '["Notion", "Google Docs", "Confluence", "Microsoft Loop"]'::jsonb
      WHEN 'draft_spec_outline' THEN '["Notion", "Confluence", "Linear Docs", "Microsoft Loop"]'::jsonb
      WHEN 'create_task_list' THEN '["Asana", "Notion", "Microsoft Planner", "Microsoft To Do", "Linear Projects"]'::jsonb
      WHEN 'file_issue_or_bug' THEN '["Linear", "GitHub Issues", "Jira", "Azure DevOps"]'::jsonb
      WHEN 'update_crm' THEN '["Salesforce", "HubSpot", "Dynamics 365"]'::jsonb
      WHEN 'schedule_follow_up' THEN '["Google Calendar", "Outlook Calendar", "Calendly"]'::jsonb
      WHEN 'research_open_question' THEN '["Perplexity", "Notion", "Google Docs", "Microsoft Loop"]'::jsonb
      WHEN 'prepare_briefing_for_next_meeting' THEN '["Google Calendar", "Outlook Calendar", "Notion", "Microsoft Teams"]'::jsonb
      ELSE '[]'::jsonb
    END,
    true
  ),
  updated_at = now()
WHERE key IN (
  'draft_internal_recap',
  'draft_external_follow_up',
  'draft_decision_brief',
  'draft_spec_outline',
  'create_task_list',
  'file_issue_or_bug',
  'update_crm',
  'schedule_follow_up',
  'research_open_question',
  'prepare_briefing_for_next_meeting'
);
