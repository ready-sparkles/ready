ALTER TABLE meeting_tasks
  ADD COLUMN IF NOT EXISTS completed_at timestamptz;

UPDATE meeting_tasks
SET completed_at = updated_at
WHERE status = 'completed'
  AND completed_at IS NULL;

UPDATE meeting_tasks
SET completed_at = NULL
WHERE status <> 'completed'
  AND completed_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS meeting_tasks_owner_status_completed_at_idx
  ON meeting_tasks(owner_user_id, status, completed_at DESC);
