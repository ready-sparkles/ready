alter table linear_task_review_items
  add column if not exists meeting_context_synced_at timestamptz;
