CREATE TABLE slack_meeting_reviews (
  id uuid PRIMARY KEY,
  meeting_id uuid NOT NULL UNIQUE REFERENCES meetings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  version integer NOT NULL DEFAULT 1,
  status text NOT NULL,
  review jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE slack_review_deliveries (
  review_id uuid NOT NULL REFERENCES slack_meeting_reviews(id) ON DELETE CASCADE,
  destination text NOT NULL,
  status text NOT NULL,
  message_ts text,
  PRIMARY KEY (review_id, destination)
);
