CREATE TABLE IF NOT EXISTS agent_memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_profile_id uuid NOT NULL REFERENCES agent_profiles(id) ON DELETE CASCADE,
  memory_type varchar(64) NOT NULL,
  content text NOT NULL,
  source varchar(64) NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS agent_memories_user_idx
  ON agent_memories(user_id, created_at);

CREATE INDEX IF NOT EXISTS agent_memories_profile_idx
  ON agent_memories(agent_profile_id, created_at);

CREATE TABLE IF NOT EXISTS agent_connectors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_profile_id uuid NOT NULL REFERENCES agent_profiles(id) ON DELETE CASCADE,
  provider varchar(64) NOT NULL,
  status varchar(32) NOT NULL DEFAULT 'disconnected',
  scope varchar(32) NOT NULL DEFAULT 'private',
  external_account_email varchar(255),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS agent_connectors_user_idx
  ON agent_connectors(user_id, provider);

CREATE INDEX IF NOT EXISTS agent_connectors_profile_idx
  ON agent_connectors(agent_profile_id, provider);

CREATE UNIQUE INDEX IF NOT EXISTS agent_connectors_user_provider_uidx
  ON agent_connectors(user_id, agent_profile_id, provider);

CREATE TABLE IF NOT EXISTS agent_connector_secrets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_connector_id uuid NOT NULL REFERENCES agent_connectors(id) ON DELETE CASCADE,
  secret_ref text NOT NULL,
  encryption_version varchar(32) NOT NULL DEFAULT 'v1',
  created_at timestamptz NOT NULL DEFAULT now(),
  rotated_at timestamptz
);

CREATE INDEX IF NOT EXISTS agent_connector_secrets_connector_idx
  ON agent_connector_secrets(agent_connector_id, created_at DESC);

CREATE TABLE IF NOT EXISTS agent_tool_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_profile_id uuid NOT NULL REFERENCES agent_profiles(id) ON DELETE CASCADE,
  tool_name varchar(120) NOT NULL,
  mode varchar(32) NOT NULL DEFAULT 'private',
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS agent_tool_policies_profile_tool_uidx
  ON agent_tool_policies(agent_profile_id, tool_name);
