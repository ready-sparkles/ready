UPDATE capability_catalog
SET
  is_active = false,
  updated_at = now()
WHERE key = 'draft_internal_recap';
