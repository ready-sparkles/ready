ALTER TABLE mail_threads
  ADD COLUMN IF NOT EXISTS provider_thread_id text;

WITH thread_provider_counts AS (
  SELECT
    m.thread_id,
    r.account_id,
    r.provider_thread_id,
    count(*)::int AS message_count,
    min(m.sent_at) AS first_message_at
  FROM mail_messages m
  INNER JOIN mail_raw_messages r ON r.id = m.raw_message_id
  WHERE r.provider_thread_id IS NOT NULL
  GROUP BY m.thread_id, r.account_id, r.provider_thread_id
),
ranked_threads AS (
  SELECT
    thread_id,
    account_id,
    provider_thread_id,
    first_value(thread_id) OVER (
      PARTITION BY account_id, provider_thread_id
      ORDER BY message_count DESC, first_message_at ASC NULLS LAST, thread_id ASC
    ) AS canonical_thread_id
  FROM thread_provider_counts
)
UPDATE mail_messages m
SET
  thread_id = ranked_threads.canonical_thread_id,
  version = version + 1,
  updated_at = now()
FROM mail_raw_messages r
INNER JOIN ranked_threads
  ON ranked_threads.account_id = r.account_id
  AND ranked_threads.provider_thread_id = r.provider_thread_id
WHERE r.id = m.raw_message_id
  AND ranked_threads.thread_id = m.thread_id
  AND ranked_threads.thread_id <> ranked_threads.canonical_thread_id;

WITH thread_provider_counts AS (
  SELECT
    m.thread_id,
    r.account_id,
    r.provider_thread_id,
    count(*)::int AS message_count,
    min(m.sent_at) AS first_message_at
  FROM mail_messages m
  INNER JOIN mail_raw_messages r ON r.id = m.raw_message_id
  WHERE r.provider_thread_id IS NOT NULL
  GROUP BY m.thread_id, r.account_id, r.provider_thread_id
),
canonical_threads AS (
  SELECT DISTINCT
    account_id,
    provider_thread_id,
    first_value(thread_id) OVER (
      PARTITION BY account_id, provider_thread_id
      ORDER BY message_count DESC, first_message_at ASC NULLS LAST, thread_id ASC
    ) AS canonical_thread_id
  FROM thread_provider_counts
)
UPDATE mail_threads t
SET
  provider_thread_id = canonical_threads.provider_thread_id,
  provider_thread_ids = jsonb_set(
    coalesce(t.provider_thread_ids, '{}'::jsonb),
    array[mail_accounts.provider::text],
    to_jsonb(array[canonical_threads.provider_thread_id]),
    true
  ),
  updated_at = now()
FROM canonical_threads
INNER JOIN mail_accounts ON mail_accounts.id = canonical_threads.account_id
WHERE t.id = canonical_threads.canonical_thread_id;

WITH stats AS (
  SELECT
    m.thread_id,
    count(*)::int AS message_count,
    min(m.sent_at) AS first_message_at,
    max(m.sent_at) AS last_message_at,
    (
      SELECT latest.snippet
      FROM mail_messages latest
      WHERE latest.thread_id = m.thread_id
      ORDER BY latest.sent_at DESC, latest.created_at DESC
      LIMIT 1
    ) AS last_message_snippet
  FROM mail_messages m
  GROUP BY m.thread_id
)
UPDATE mail_threads t
SET
  message_count = stats.message_count,
  first_message_at = stats.first_message_at,
  last_message_at = stats.last_message_at,
  last_message_snippet = stats.last_message_snippet,
  version = version + 1,
  updated_at = now()
FROM stats
WHERE t.id = stats.thread_id;

DELETE FROM mail_threads t
WHERE NOT EXISTS (
  SELECT 1
  FROM mail_messages m
  WHERE m.thread_id = t.id
);

DROP INDEX IF EXISTS mail_threads_account_participants_subject_uidx;

CREATE UNIQUE INDEX IF NOT EXISTS mail_threads_account_provider_thread_uidx
  ON mail_threads(account_id, provider_thread_id)
  WHERE provider_thread_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS mail_threads_account_fallback_participants_subject_uidx
  ON mail_threads(account_id, participant_set_hash, subject_root)
  WHERE provider_thread_id IS NULL;
