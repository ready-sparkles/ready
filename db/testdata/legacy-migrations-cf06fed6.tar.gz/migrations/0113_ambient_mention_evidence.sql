-- NULL preserves unknown provenance for existing rows and older API writers.
-- Never suppress an entity unless every recorded mention is voice-owned.
ALTER TABLE meeting_ambient_context_items
  ADD COLUMN IF NOT EXISTS mention_segment_ids jsonb;
