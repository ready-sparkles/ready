ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'execute_capability_workflow';

CREATE TABLE capability_workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  recommendation_id uuid NOT NULL REFERENCES meeting_capability_recommendations(id) ON DELETE CASCADE,
  capability_key varchar(160) NOT NULL REFERENCES capability_catalog(key),
  status varchar(32) NOT NULL DEFAULT 'pending',
  phase varchar(64) NOT NULL DEFAULT 'gathering_context',
  context jsonb NOT NULL DEFAULT '{}'::jsonb,
  plan jsonb NOT NULL DEFAULT '{}'::jsonb,
  draft jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

CREATE INDEX capability_workflow_runs_meeting_idx
  ON capability_workflow_runs(meeting_id, created_at);

CREATE INDEX capability_workflow_runs_recommendation_idx
  ON capability_workflow_runs(recommendation_id);

CREATE UNIQUE INDEX capability_workflow_runs_recommendation_uidx
  ON capability_workflow_runs(recommendation_id);

CREATE TABLE capability_workflow_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_run_id uuid NOT NULL REFERENCES capability_workflow_runs(id) ON DELETE CASCADE,
  role varchar(32) NOT NULL,
  content text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX capability_workflow_messages_run_idx
  ON capability_workflow_messages(workflow_run_id, created_at);
