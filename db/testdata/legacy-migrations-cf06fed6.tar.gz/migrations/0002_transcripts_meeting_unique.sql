WITH ranked_transcripts AS (
  SELECT
    id,
    meeting_id,
    first_value(id) OVER (PARTITION BY meeting_id ORDER BY created_at DESC, id DESC) AS canonical_id,
    row_number() OVER (PARTITION BY meeting_id ORDER BY created_at DESC, id DESC) AS transcript_rank
  FROM transcripts
),
repointed_segments AS (
  UPDATE transcript_segments AS segment
  SET transcript_id = ranked_transcripts.canonical_id
  FROM ranked_transcripts
  WHERE segment.transcript_id = ranked_transcripts.id
    AND ranked_transcripts.transcript_rank > 1
  RETURNING segment.id
)
DELETE FROM transcripts AS transcript
USING ranked_transcripts
WHERE transcript.id = ranked_transcripts.id
  AND ranked_transcripts.transcript_rank > 1;

CREATE UNIQUE INDEX IF NOT EXISTS transcripts_meeting_unique_idx ON transcripts(meeting_id);
