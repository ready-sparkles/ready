UPDATE capability_catalog
SET
  is_active = false,
  updated_at = now()
WHERE key IN (
  'create_task_list',
  'draft_decision_brief',
  'draft_spec_outline',
  'prepare_briefing_for_next_meeting'
);
