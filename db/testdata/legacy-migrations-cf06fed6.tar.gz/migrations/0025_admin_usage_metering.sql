CREATE TABLE IF NOT EXISTS user_auth_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider varchar(64) NOT NULL,
  provider_account_id varchar(255),
  first_authenticated_at timestamptz NOT NULL DEFAULT now(),
  last_authenticated_at timestamptz NOT NULL DEFAULT now(),
  auth_count integer NOT NULL DEFAULT 1,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS user_auth_accounts_provider_account_uidx
  ON user_auth_accounts(provider, provider_account_id)
  WHERE provider_account_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS user_auth_accounts_user_provider_null_account_uidx
  ON user_auth_accounts(user_id, provider)
  WHERE provider_account_id IS NULL;

CREATE INDEX IF NOT EXISTS user_auth_accounts_user_idx
  ON user_auth_accounts(user_id, last_authenticated_at DESC);

CREATE TABLE IF NOT EXISTS usage_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  meeting_id uuid REFERENCES meetings(id) ON DELETE SET NULL,
  job_id uuid REFERENCES ai_workflow_jobs(id) ON DELETE SET NULL,
  workflow_run_id uuid REFERENCES capability_workflow_runs(id) ON DELETE SET NULL,
  provider varchar(64) NOT NULL,
  category varchar(64) NOT NULL,
  model varchar(160),
  sku varchar(160),
  unit_count integer NOT NULL DEFAULT 0,
  unit_type varchar(64) NOT NULL,
  unit_price_micro_usd integer,
  cost_micro_usd integer NOT NULL DEFAULT 0,
  source varchar(120) NOT NULL,
  idempotency_key varchar(255),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS usage_events_idempotency_key_uidx
  ON usage_events(idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS usage_events_user_occurred_idx
  ON usage_events(user_id, occurred_at DESC);

CREATE INDEX IF NOT EXISTS usage_events_meeting_idx
  ON usage_events(meeting_id, occurred_at DESC);

CREATE INDEX IF NOT EXISTS usage_events_category_idx
  ON usage_events(category, occurred_at DESC);
