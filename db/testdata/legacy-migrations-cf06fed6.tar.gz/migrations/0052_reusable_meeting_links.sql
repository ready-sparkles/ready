CREATE TABLE IF NOT EXISTS meeting_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code varchar(255) NOT NULL UNIQUE,
  workspace_id uuid NOT NULL REFERENCES workspaces(id),
  created_by_user_id uuid NOT NULL REFERENCES users(id),
  title varchar(255) NOT NULL,
  status varchar(32) NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS meeting_links_workspace_idx
  ON meeting_links(workspace_id, created_at);

CREATE INDEX IF NOT EXISTS meeting_links_creator_idx
  ON meeting_links(created_by_user_id);

ALTER TABLE meetings
  ADD COLUMN IF NOT EXISTS meeting_link_id uuid REFERENCES meeting_links(id),
  ADD COLUMN IF NOT EXISTS instance_number integer NOT NULL DEFAULT 1;

INSERT INTO meeting_links (
  code,
  workspace_id,
  created_by_user_id,
  title,
  created_at,
  updated_at
)
SELECT
  meetings.room_name,
  meetings.workspace_id,
  meetings.created_by_user_id,
  meetings.title,
  meetings.created_at,
  now()
FROM meetings
WHERE meetings.meeting_link_id IS NULL
ON CONFLICT (code) DO NOTHING;

UPDATE meetings
SET meeting_link_id = meeting_links.id,
    instance_number = 1
FROM meeting_links
WHERE meetings.meeting_link_id IS NULL
  AND meeting_links.code = meetings.room_name;

CREATE INDEX IF NOT EXISTS meetings_meeting_link_idx
  ON meetings(meeting_link_id, created_at);

CREATE UNIQUE INDEX IF NOT EXISTS meetings_one_current_per_link_uidx
  ON meetings(meeting_link_id)
  WHERE meeting_link_id IS NOT NULL
    AND status IN ('scheduled'::meeting_status, 'active'::meeting_status);

CREATE TABLE IF NOT EXISTS calendar_ready_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  calendar_account_id uuid NOT NULL REFERENCES agent_connectors(id) ON DELETE CASCADE,
  provider varchar(64) NOT NULL,
  calendar_id text NOT NULL,
  provider_event_id text NOT NULL,
  meeting_link_id uuid NOT NULL REFERENCES meeting_links(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, calendar_account_id, provider, calendar_id, provider_event_id)
);

CREATE INDEX IF NOT EXISTS calendar_ready_links_meeting_link_idx
  ON calendar_ready_links(meeting_link_id);

CREATE INDEX IF NOT EXISTS calendar_ready_links_calendar_account_idx
  ON calendar_ready_links(calendar_account_id);
