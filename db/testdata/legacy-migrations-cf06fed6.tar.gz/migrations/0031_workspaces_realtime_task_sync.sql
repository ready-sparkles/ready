CREATE TABLE workspaces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(255) NOT NULL,
  created_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX workspaces_created_by_user_idx ON workspaces(created_by_user_id);

CREATE TYPE workspace_membership_role AS ENUM ('admin', 'member');

CREATE TABLE workspace_memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role workspace_membership_role NOT NULL DEFAULT 'member',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX workspace_memberships_workspace_user_uidx
  ON workspace_memberships(workspace_id, user_id);
CREATE INDEX workspace_memberships_user_idx ON workspace_memberships(user_id);

WITH created_workspaces AS (
  INSERT INTO workspaces (name, created_by_user_id)
  SELECT
    CASE
      WHEN position('@' in email) > 0 THEN split_part(email, '@', 2) || ' workspace'
      ELSE display_name || ' workspace'
    END,
    id
  FROM users
  RETURNING id, created_by_user_id
)
INSERT INTO workspace_memberships (workspace_id, user_id, role)
SELECT id, created_by_user_id, 'admin'::workspace_membership_role
FROM created_workspaces
WHERE created_by_user_id IS NOT NULL
ON CONFLICT (workspace_id, user_id) DO NOTHING;

ALTER TABLE meetings
  ADD COLUMN workspace_id uuid REFERENCES workspaces(id);

UPDATE meetings
SET workspace_id = selected_workspace.id
FROM (
  SELECT DISTINCT ON (created_by_user_id)
    id,
    created_by_user_id
  FROM workspaces
  WHERE created_by_user_id IS NOT NULL
  ORDER BY created_by_user_id, created_at ASC
) AS selected_workspace
WHERE meetings.created_by_user_id = selected_workspace.created_by_user_id;

INSERT INTO workspace_memberships (workspace_id, user_id, role)
SELECT DISTINCT meetings.workspace_id, meeting_participants.user_id, 'member'::workspace_membership_role
FROM meetings
INNER JOIN meeting_participants ON meeting_participants.meeting_id = meetings.id
WHERE meetings.workspace_id IS NOT NULL
ON CONFLICT (workspace_id, user_id) DO NOTHING;

ALTER TABLE meetings
  ALTER COLUMN workspace_id SET NOT NULL;

CREATE INDEX meetings_workspace_idx ON meetings(workspace_id, created_at);

ALTER TABLE meeting_task_lists
  ADD COLUMN task_list_version integer NOT NULL DEFAULT 1;

ALTER TABLE meeting_tasks
  ADD COLUMN revision integer NOT NULL DEFAULT 1;

CREATE TYPE realtime_outbox_status AS ENUM ('pending', 'publishing', 'published', 'failed');

CREATE TABLE realtime_outbox (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel text NOT NULL,
  event_name varchar(120) NOT NULL,
  payload jsonb NOT NULL,
  dedupe_key text NOT NULL,
  status realtime_outbox_status NOT NULL DEFAULT 'pending',
  attempt_count integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  locked_by varchar(160),
  locked_at timestamptz,
  last_error text,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX realtime_outbox_dedupe_key_uidx ON realtime_outbox(dedupe_key);
CREATE INDEX realtime_outbox_pending_idx
  ON realtime_outbox(status, next_attempt_at, created_at)
  WHERE status IN ('pending', 'failed');
