ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'generate_meeting_snapshot';

DROP INDEX IF EXISTS ai_workflow_jobs_active_pipeline_uidx;

CREATE UNIQUE INDEX ai_workflow_jobs_active_pipeline_uidx
  ON ai_workflow_jobs(meeting_id, type)
  WHERE status IN ('queued', 'running');
