CREATE TABLE IF NOT EXISTS ai_credit_pricing_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  price_per_credit_micro_usd integer NOT NULL DEFAULT 100000 CHECK (price_per_credit_micro_usd > 0),
  target_markup_multiplier numeric(8, 4) NOT NULL DEFAULT 5 CHECK (target_markup_multiplier >= 0),
  included_action_types jsonb NOT NULL DEFAULT '[]'::jsonb,
  action_minimum_credits jsonb NOT NULL DEFAULT '{}'::jsonb,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_credit_usage_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  meeting_id uuid REFERENCES meetings(id) ON DELETE SET NULL,
  job_id uuid REFERENCES ai_workflow_jobs(id) ON DELETE SET NULL,
  workflow_run_id uuid REFERENCES capability_workflow_runs(id) ON DELETE SET NULL,
  action_type text NOT NULL,
  action_label text NOT NULL,
  provider text,
  model text,
  input_tokens integer NOT NULL DEFAULT 0,
  output_tokens integer NOT NULL DEFAULT 0,
  cached_input_tokens integer NOT NULL DEFAULT 0,
  tool_call_count integer NOT NULL DEFAULT 0,
  actual_cost_micro_usd integer NOT NULL DEFAULT 0,
  price_per_credit_micro_usd integer NOT NULL DEFAULT 100000 CHECK (price_per_credit_micro_usd > 0),
  markup_multiplier numeric(8, 4) NOT NULL DEFAULT 5 CHECK (markup_multiplier >= 0),
  minimum_credits integer NOT NULL DEFAULT 1,
  included boolean NOT NULL DEFAULT false,
  credits_charged integer NOT NULL DEFAULT 0,
  revenue_micro_usd integer NOT NULL DEFAULT 0,
  profit_micro_usd integer NOT NULL DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  idempotency_key text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ai_credit_usage_events_idempotency_key_uidx
  ON ai_credit_usage_events(idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS ai_credit_usage_events_user_created_idx
  ON ai_credit_usage_events(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS ai_credit_usage_events_meeting_idx
  ON ai_credit_usage_events(meeting_id, created_at DESC);

CREATE INDEX IF NOT EXISTS ai_credit_usage_events_action_type_idx
  ON ai_credit_usage_events(action_type, created_at DESC);

INSERT INTO ai_credit_pricing_config (
  price_per_credit_micro_usd,
  target_markup_multiplier,
  included_action_types,
  action_minimum_credits,
  metadata
)
SELECT
  100000,
  5,
  '["meeting_snapshot"]'::jsonb,
  '{
    "meeting_summary": 3,
    "meeting_action_items": 3,
    "meeting_ask": 1,
    "coaching_feedback": 5,
    "linear_issue_drafting": 8,
    "followup_email_draft": 3,
    "deep_meeting_analysis": 10,
    "mail_surface_classification": 0,
    "mail_thread_summary": 0,
    "meeting_brief": 0,
    "agent_workflow": 10
  }'::jsonb,
  '{"source": "default_seed"}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM ai_credit_pricing_config);
