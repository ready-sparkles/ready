CREATE TABLE user_acquisition (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE SET NULL,
  attribution jsonb NOT NULL,
  analytics_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE acquisition_payments (
  transaction_id text PRIMARY KEY,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE SET NULL,
  amount_minor bigint NOT NULL CHECK (amount_minor > 0),
  currency text NOT NULL,
  paid_at timestamptz NOT NULL
);
CREATE INDEX acquisition_payments_user_idx ON acquisition_payments(user_id, paid_at);

CREATE TABLE analytics_outbox (
  event_id text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_name text NOT NULL CHECK (event_name IN ('sign_up', 'first_meeting_completed', 'purchase')),
  params jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  available_at timestamptz NOT NULL DEFAULT now(),
  claim_token uuid,
  attempts integer NOT NULL DEFAULT 0,
  delivered_at timestamptz,
  last_error text
);
CREATE INDEX analytics_outbox_pending_idx ON analytics_outbox(available_at) WHERE delivered_at IS NULL;
