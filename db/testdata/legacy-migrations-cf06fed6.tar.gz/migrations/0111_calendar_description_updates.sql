CREATE TABLE IF NOT EXISTS calendar_description_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  meeting_link_id uuid NOT NULL REFERENCES meeting_links(id) ON DELETE CASCADE,
  calendar_id text NOT NULL,
  event_id text NOT NULL,
  credential text,
  status text NOT NULL DEFAULT 'pending',
  attempts integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  lease_token uuid,
  expires_at timestamptz NOT NULL DEFAULT now() + interval '45 minutes',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS calendar_description_updates_pending_idx
ON calendar_description_updates(next_attempt_at) WHERE status = 'pending';

CREATE UNIQUE INDEX IF NOT EXISTS calendar_description_updates_event_uidx
ON calendar_description_updates(user_id, calendar_id, event_id, meeting_link_id);
