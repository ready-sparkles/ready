ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'enrich_ambient_context_image';
