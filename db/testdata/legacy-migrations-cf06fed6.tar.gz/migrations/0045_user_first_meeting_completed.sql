ALTER TABLE users
  ADD COLUMN has_completed_first_meeting boolean NOT NULL DEFAULT false;

UPDATE users u
SET has_completed_first_meeting = true
WHERE EXISTS (
  SELECT 1
  FROM meeting_participants mp
  INNER JOIN meetings m ON m.id = mp.meeting_id
  WHERE mp.user_id = u.id
    AND mp.role <> 'assistant'
    AND m.status = 'ended'
);

CREATE INDEX users_has_completed_first_meeting_idx
  ON users (has_completed_first_meeting)
  WHERE has_completed_first_meeting = true;
