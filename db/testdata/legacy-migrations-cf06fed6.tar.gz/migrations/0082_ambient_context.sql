ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'detect_ambient_context';
ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'research_ambient_entity';

CREATE TABLE IF NOT EXISTS meeting_ambient_context_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  entity_kind varchar(24) NOT NULL CHECK (entity_kind IN ('person', 'company')),
  canonical_key varchar(320) NOT NULL,
  display_name varchar(255) NOT NULL,
  qualifier varchar(320),
  image_status varchar(24) NOT NULL DEFAULT 'pending'
    CHECK (image_status IN ('pending', 'ready', 'unavailable')),
  image_storage_key text,
  image_mime_type varchar(96),
  professional_title varchar(255),
  company_name varchar(255),
  headquarters varchar(255),
  official_website text,
  profile_url text,
  summary text,
  facts jsonb NOT NULL DEFAULT '[]'::jsonb,
  citations jsonb NOT NULL DEFAULT '[]'::jsonb,
  facets jsonb NOT NULL DEFAULT '[]'::jsonb,
  status varchar(24) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'researching', 'ready', 'failed')),
  mention_count integer NOT NULL DEFAULT 1 CHECK (mention_count > 0),
  error text,
  first_mentioned_at timestamptz NOT NULL DEFAULT now(),
  last_mentioned_at timestamptz NOT NULL DEFAULT now(),
  research_started_at timestamptz,
  research_completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT meeting_ambient_context_items_identity_uidx UNIQUE (meeting_id, canonical_key)
);

CREATE INDEX IF NOT EXISTS meeting_ambient_context_items_recency_idx
  ON meeting_ambient_context_items (meeting_id, last_mentioned_at DESC);
CREATE INDEX IF NOT EXISTS meeting_ambient_context_items_status_idx
  ON meeting_ambient_context_items (status, updated_at);

CREATE TABLE IF NOT EXISTS meeting_ambient_context_cursors (
  meeting_id uuid PRIMARY KEY REFERENCES meetings(id) ON DELETE CASCADE,
  last_processed_segment_id uuid REFERENCES transcript_segments(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
