CREATE TABLE IF NOT EXISTS agent_tool_invocations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  utterance_id varchar(160) NOT NULL,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_profile_id uuid NOT NULL REFERENCES agent_profiles(id) ON DELETE CASCADE,
  connector_id uuid REFERENCES agent_connectors(id) ON DELETE SET NULL,
  provider varchar(64) NOT NULL,
  tool_name varchar(120) NOT NULL,
  tool_version varchar(32) NOT NULL,
  policy_version varchar(64) NOT NULL,
  side_effect_class varchar(32) NOT NULL,
  status varchar(32) NOT NULL,
  confirmation_status varchar(32) NOT NULL DEFAULT 'not_required',
  confirmation_actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  idempotency_key varchar(180),
  redacted_args jsonb NOT NULL DEFAULT '{}'::jsonb,
  redacted_result_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  error_code varchar(120),
  duration_ms integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  confirmed_at timestamptz,
  executed_at timestamptz
);

CREATE INDEX IF NOT EXISTS agent_tool_invocations_meeting_idx
  ON agent_tool_invocations(meeting_id, created_at);

CREATE INDEX IF NOT EXISTS agent_tool_invocations_user_idx
  ON agent_tool_invocations(user_id, created_at);

CREATE UNIQUE INDEX IF NOT EXISTS agent_tool_invocations_idempotency_uidx
  ON agent_tool_invocations(idempotency_key)
  WHERE idempotency_key IS NOT NULL;
