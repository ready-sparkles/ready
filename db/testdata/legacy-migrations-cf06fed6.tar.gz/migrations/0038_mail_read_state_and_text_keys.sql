ALTER TABLE mail_threads
  ALTER COLUMN participant_set_hash TYPE text,
  ALTER COLUMN agent_summary_prompt_version TYPE text,
  ALTER COLUMN agent_summary_message_set_hash TYPE text,
  ALTER COLUMN surface_classifier_version TYPE text,
  ALTER COLUMN surface_classifier_key TYPE text;

ALTER TABLE mail_classifier_cache
  ALTER COLUMN classifier_key TYPE text,
  ALTER COLUMN classifier_version TYPE text,
  ALTER COLUMN prompt_version TYPE text;

UPDATE mail_jobs
SET
  status = 'queued',
  attempt_count = 0,
  run_after = now(),
  locked_by = null,
  locked_at = null,
  last_error = null,
  updated_at = now()
WHERE job_type = 'generate_summary'
  AND status = 'failed'
  AND last_error ILIKE '%character varying%';
