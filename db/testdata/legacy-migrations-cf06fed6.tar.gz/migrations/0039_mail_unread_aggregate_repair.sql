WITH unread_state AS (
  SELECT
    t.id,
    EXISTS (
      SELECT 1
      FROM mail_messages m
      WHERE m.thread_id = t.id
        AND m.direction = 'inbound'
        AND m.is_read = false
    ) AS unread_real_human
  FROM mail_threads t
)
UPDATE mail_threads t
SET
  unread_real_human = unread_state.unread_real_human,
  version = t.version + 1,
  updated_at = now()
FROM unread_state
WHERE t.id = unread_state.id
  AND t.unread_real_human IS DISTINCT FROM unread_state.unread_real_human;
