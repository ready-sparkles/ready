UPDATE ai_credit_pricing_config
SET
  action_minimum_credits = '{
    "mail_surface_classification": 0,
    "mail_thread_summary": 0,
    "meeting_brief": 0
  }'::jsonb || action_minimum_credits,
  updated_at = now()
WHERE NOT (
  action_minimum_credits ? 'mail_surface_classification'
  AND action_minimum_credits ? 'mail_thread_summary'
  AND action_minimum_credits ? 'meeting_brief'
);
