CREATE TABLE personal_task_item_clearances (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  source_type assigned_task_source_type NOT NULL,
  source_task_id uuid NOT NULL,
  completed_before timestamptz NOT NULL,
  PRIMARY KEY (user_id, workspace_id, source_type, source_task_id)
);
