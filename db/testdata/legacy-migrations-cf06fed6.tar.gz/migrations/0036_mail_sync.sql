DO $$
BEGIN
  CREATE TYPE mail_account_provider AS ENUM ('gmail', 'outlook_mail');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_account_status AS ENUM ('connected', 'disconnected', 'error');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_direction AS ENUM ('inbound', 'outbound');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_recipient_kind AS ENUM ('to', 'cc', 'bcc');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_thread_surface AS ENUM ('threads', 'library', 'tasks');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_surface_source AS ENUM ('deterministic', 'ai', 'user', 'system');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_summary_status AS ENUM ('empty', 'fresh', 'stale', 'updating', 'error');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_job_type AS ENUM (
    'initial_backfill',
    'incremental_sync',
    'bounded_resync',
    'refresh_subscription',
    'classify_surface',
    'generate_summary'
  );
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$
BEGIN
  CREATE TYPE mail_job_status AS ENUM ('queued', 'running', 'completed', 'failed', 'cancelled');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

CREATE TABLE IF NOT EXISTS mail_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider mail_account_provider NOT NULL,
  provider_account_id text,
  email varchar(255) NOT NULL,
  display_name varchar(255),
  status mail_account_status NOT NULL DEFAULT 'connected',
  secret_ref text NOT NULL,
  scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
  history_id text,
  sync_state jsonb NOT NULL DEFAULT '{}'::jsonb,
  initial_backfill_started_at timestamptz,
  initial_backfill_completed_at timestamptz,
  last_synced_at timestamptz,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_accounts_user_provider_account_uidx
  ON mail_accounts(user_id, provider, provider_account_id)
  WHERE provider_account_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS mail_accounts_user_provider_email_uidx
  ON mail_accounts(user_id, provider, email);

CREATE INDEX IF NOT EXISTS mail_accounts_user_status_idx
  ON mail_accounts(user_id, status, updated_at);

CREATE TABLE IF NOT EXISTS mail_sync_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
  provider mail_account_provider NOT NULL,
  subscription_kind varchar(64) NOT NULL,
  provider_subscription_id text,
  resource text,
  webhook_address text,
  expiration_at timestamptz,
  status varchar(32) NOT NULL DEFAULT 'active',
  sync_cursor text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_sync_subscriptions_active_account_kind_uidx
  ON mail_sync_subscriptions(account_id, subscription_kind)
  WHERE status = 'active';

CREATE INDEX IF NOT EXISTS mail_sync_subscriptions_provider_subscription_idx
  ON mail_sync_subscriptions(provider, provider_subscription_id);

CREATE INDEX IF NOT EXISTS mail_sync_subscriptions_account_idx
  ON mail_sync_subscriptions(account_id, status);

CREATE TABLE IF NOT EXISTS mail_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email varchar(255) NOT NULL,
  normalized_email varchar(255) NOT NULL,
  display_name varchar(255),
  domain varchar(255),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_addresses_user_normalized_email_uidx
  ON mail_addresses(user_id, normalized_email);

CREATE INDEX IF NOT EXISTS mail_addresses_user_domain_idx
  ON mail_addresses(user_id, domain);

CREATE TABLE IF NOT EXISTS mail_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
  participant_set_hash varchar(128) NOT NULL,
  subject_root text,
  provider_thread_ids jsonb NOT NULL DEFAULT '{}'::jsonb,
  first_message_at timestamptz,
  last_message_at timestamptz NOT NULL,
  message_count integer NOT NULL DEFAULT 0,
  last_message_snippet text,
  agent_summary text,
  agent_summary_status mail_summary_status NOT NULL DEFAULT 'empty',
  agent_summary_thread_version integer,
  agent_summary_prompt_version varchar(64),
  agent_summary_message_set_hash varchar(128),
  agent_summary_generated_at timestamptz,
  agent_summary_error text,
  surface mail_thread_surface NOT NULL DEFAULT 'threads',
  surface_source mail_surface_source NOT NULL DEFAULT 'deterministic',
  surface_reason text,
  surface_classifier_version varchar(64),
  surface_classifier_key varchar(128),
  surface_override_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  unread_real_human boolean NOT NULL DEFAULT false,
  version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS mail_threads_account_surface_last_idx
  ON mail_threads(account_id, surface, last_message_at);

CREATE INDEX IF NOT EXISTS mail_threads_user_surface_last_idx
  ON mail_threads(user_id, surface, last_message_at);

CREATE INDEX IF NOT EXISTS mail_threads_surface_classifier_key_idx
  ON mail_threads(user_id, surface_classifier_key);

CREATE UNIQUE INDEX IF NOT EXISTS mail_threads_account_participants_subject_uidx
  ON mail_threads(account_id, participant_set_hash, subject_root);

CREATE TABLE IF NOT EXISTS mail_raw_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
  provider_message_id text NOT NULL,
  provider_thread_id text,
  rfc_message_id text,
  storage_key text NOT NULL,
  raw_size_bytes integer,
  headers_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  etag text,
  received_at timestamptz,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_raw_messages_account_provider_message_uidx
  ON mail_raw_messages(account_id, provider_message_id);

CREATE UNIQUE INDEX IF NOT EXISTS mail_raw_messages_account_rfc_message_uidx
  ON mail_raw_messages(account_id, rfc_message_id)
  WHERE rfc_message_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS mail_raw_messages_account_created_idx
  ON mail_raw_messages(account_id, created_at);

CREATE TABLE IF NOT EXISTS mail_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
  raw_message_id uuid REFERENCES mail_raw_messages(id) ON DELETE SET NULL,
  thread_id uuid NOT NULL REFERENCES mail_threads(id) ON DELETE CASCADE,
  provider_message_id text NOT NULL,
  rfc_message_id text,
  from_address_id uuid REFERENCES mail_addresses(id) ON DELETE SET NULL,
  subject text,
  body_clean text,
  body_html_clean text,
  snippet text,
  sent_at timestamptz NOT NULL,
  received_at timestamptz,
  direction mail_direction NOT NULL DEFAULT 'inbound',
  sent_by varchar(32) NOT NULL DEFAULT 'external',
  approved_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  signature_block text,
  quoted_history text,
  has_attachments boolean NOT NULL DEFAULT false,
  is_read boolean NOT NULL DEFAULT false,
  version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_messages_raw_message_uidx
  ON mail_messages(raw_message_id)
  WHERE raw_message_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS mail_messages_account_provider_message_uidx
  ON mail_messages(account_id, provider_message_id);

CREATE INDEX IF NOT EXISTS mail_messages_thread_sent_idx
  ON mail_messages(thread_id, sent_at);

CREATE INDEX IF NOT EXISTS mail_messages_account_sent_idx
  ON mail_messages(account_id, sent_at);

CREATE TABLE IF NOT EXISTS mail_message_recipients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES mail_messages(id) ON DELETE CASCADE,
  address_id uuid NOT NULL REFERENCES mail_addresses(id) ON DELETE CASCADE,
  kind mail_recipient_kind NOT NULL,
  position integer NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_message_recipients_message_kind_position_uidx
  ON mail_message_recipients(message_id, kind, position);

CREATE INDEX IF NOT EXISTS mail_message_recipients_address_idx
  ON mail_message_recipients(address_id);

CREATE TABLE IF NOT EXISTS mail_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
  raw_message_id uuid REFERENCES mail_raw_messages(id) ON DELETE CASCADE,
  message_id uuid NOT NULL REFERENCES mail_messages(id) ON DELETE CASCADE,
  provider_attachment_id text,
  content_id text,
  filename text,
  mime_type varchar(255),
  size_bytes integer,
  storage_key text,
  is_inline boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS mail_attachments_message_idx
  ON mail_attachments(message_id);

CREATE INDEX IF NOT EXISTS mail_attachments_account_idx
  ON mail_attachments(account_id);

CREATE TABLE IF NOT EXISTS mail_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id uuid REFERENCES mail_accounts(id) ON DELETE CASCADE,
  thread_id uuid REFERENCES mail_threads(id) ON DELETE CASCADE,
  job_type mail_job_type NOT NULL,
  status mail_job_status NOT NULL DEFAULT 'queued',
  run_after timestamptz NOT NULL DEFAULT now(),
  attempt_count integer NOT NULL DEFAULT 0,
  max_attempts integer NOT NULL DEFAULT 5,
  locked_by varchar(160),
  locked_at timestamptz,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS mail_jobs_ready_idx
  ON mail_jobs(status, run_after, created_at);

CREATE INDEX IF NOT EXISTS mail_jobs_account_idx
  ON mail_jobs(account_id, status);

CREATE INDEX IF NOT EXISTS mail_jobs_thread_idx
  ON mail_jobs(thread_id, job_type, status);

CREATE TABLE IF NOT EXISTS mail_change_log (
  change_seq bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
  thread_id uuid NOT NULL REFERENCES mail_threads(id) ON DELETE CASCADE,
  message_id uuid REFERENCES mail_messages(id) ON DELETE SET NULL,
  event_name varchar(120) NOT NULL,
  thread_version integer NOT NULL,
  message_version integer,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS mail_change_log_user_seq_idx
  ON mail_change_log(user_id, change_seq);

CREATE INDEX IF NOT EXISTS mail_change_log_account_seq_idx
  ON mail_change_log(account_id, change_seq);

CREATE INDEX IF NOT EXISTS mail_change_log_thread_idx
  ON mail_change_log(thread_id, change_seq);

CREATE TABLE IF NOT EXISTS mail_classifier_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  classifier_key varchar(128) NOT NULL,
  surface mail_thread_surface NOT NULL,
  source mail_surface_source NOT NULL DEFAULT 'ai',
  reason text,
  classifier_version varchar(64) NOT NULL,
  prompt_version varchar(64),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_classifier_cache_user_key_uidx
  ON mail_classifier_cache(user_id, classifier_key);

CREATE INDEX IF NOT EXISTS mail_classifier_cache_user_surface_idx
  ON mail_classifier_cache(user_id, surface);
