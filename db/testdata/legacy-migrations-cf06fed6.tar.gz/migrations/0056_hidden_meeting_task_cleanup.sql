DELETE FROM assigned_task_placements placement
USING meeting_tasks task
INNER JOIN meetings meeting ON meeting.id = task.meeting_id
WHERE placement.source_type = 'meeting'
  AND placement.source_task_id = task.id
  AND placement.workspace_id = meeting.workspace_id
  AND meeting.hidden_from_history_at IS NOT NULL;

DELETE FROM meeting_tasks task
USING meetings meeting
WHERE task.meeting_id = meeting.id
  AND meeting.hidden_from_history_at IS NOT NULL;
