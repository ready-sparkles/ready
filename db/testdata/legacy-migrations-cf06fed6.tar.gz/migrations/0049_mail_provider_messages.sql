CREATE TABLE IF NOT EXISTS mail_provider_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
  provider_message_id text NOT NULL,
  provider_thread_id text,
  rfc_message_id text,
  raw_size_bytes integer,
  header_signals jsonb NOT NULL DEFAULT '{}'::jsonb,
  etag text,
  received_at timestamptz,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS mail_provider_messages_account_provider_message_uidx
  ON mail_provider_messages(account_id, provider_message_id);

CREATE UNIQUE INDEX IF NOT EXISTS mail_provider_messages_account_rfc_message_uidx
  ON mail_provider_messages(account_id, rfc_message_id)
  WHERE rfc_message_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS mail_provider_messages_account_created_idx
  ON mail_provider_messages(account_id, created_at);

DO $$
BEGIN
  IF to_regclass('public.mail_raw_messages') IS NOT NULL THEN
    INSERT INTO mail_provider_messages (
      id,
      user_id,
      account_id,
      provider_message_id,
      provider_thread_id,
      rfc_message_id,
      raw_size_bytes,
      header_signals,
      etag,
      received_at,
      sent_at,
      created_at
    )
    SELECT
      id,
      user_id,
      account_id,
      provider_message_id,
      provider_thread_id,
      rfc_message_id,
      raw_size_bytes,
      jsonb_strip_nulls(jsonb_build_object(
        'list-unsubscribe', headers_json->>'list-unsubscribe',
        'list-id', headers_json->>'list-id',
        'precedence', headers_json->>'precedence',
        'auto-submitted', headers_json->>'auto-submitted',
        'x-ms-exchange-organization-calendar-series-instance-id', headers_json->>'x-ms-exchange-organization-calendar-series-instance-id',
        'x-google-calendar-event-id', headers_json->>'x-google-calendar-event-id',
        'in-reply-to', headers_json->>'in-reply-to',
        'references', headers_json->>'references'
      )),
      etag,
      received_at,
      sent_at,
      created_at
    FROM mail_raw_messages
    ON CONFLICT (account_id, provider_message_id)
    DO UPDATE SET
      provider_thread_id = coalesce(excluded.provider_thread_id, mail_provider_messages.provider_thread_id),
      rfc_message_id = coalesce(excluded.rfc_message_id, mail_provider_messages.rfc_message_id),
      raw_size_bytes = excluded.raw_size_bytes,
      header_signals = excluded.header_signals,
      etag = coalesce(excluded.etag, mail_provider_messages.etag),
      received_at = coalesce(excluded.received_at, mail_provider_messages.received_at),
      sent_at = coalesce(excluded.sent_at, mail_provider_messages.sent_at);
  END IF;
END $$;

ALTER TABLE mail_messages
  ADD COLUMN IF NOT EXISTS provider_record_id uuid;

DO $$
BEGIN
  IF to_regclass('public.mail_raw_messages') IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'mail_messages'
        AND column_name = 'raw_message_id'
    ) THEN
    UPDATE mail_messages
    SET provider_record_id = raw_message_id
    WHERE provider_record_id IS NULL
      AND raw_message_id IS NOT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'mail_messages_provider_record_id_fkey'
      AND conrelid = 'mail_messages'::regclass
  ) THEN
    ALTER TABLE mail_messages
      ADD CONSTRAINT mail_messages_provider_record_id_fkey
      FOREIGN KEY (provider_record_id)
      REFERENCES mail_provider_messages(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS mail_messages_provider_record_uidx
  ON mail_messages(provider_record_id)
  WHERE provider_record_id IS NOT NULL;

DROP INDEX IF EXISTS mail_messages_raw_message_uidx;

ALTER TABLE mail_messages
  DROP CONSTRAINT IF EXISTS mail_messages_raw_message_id_fkey,
  DROP COLUMN IF EXISTS raw_message_id;

ALTER TABLE mail_attachments
  DROP CONSTRAINT IF EXISTS mail_attachments_raw_message_id_fkey,
  DROP COLUMN IF EXISTS raw_message_id;

DROP TABLE IF EXISTS mail_raw_messages;
