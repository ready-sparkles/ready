-- Late attendance/access writes may arrive after the original event was drained.
-- Re-deliver only this explicit future meeting; generation allowances never reset.
ALTER TABLE memory_meeting_events ADD COLUMN version bigint NOT NULL DEFAULT 1;
CREATE FUNCTION wake_future_memory_attendees(mid uuid) RETURNS void LANGUAGE sql AS $$
 INSERT INTO memory_meeting_events(meeting_id)
 SELECT m.id FROM meetings m CROSS JOIN memory_runtime_policy policy
 WHERE m.id=mid AND m.status='ended' AND m.kind='standard' AND m.ended_at>policy.future_only_since
 AND EXISTS(SELECT 1 FROM transcripts t WHERE t.meeting_id=m.id AND
  (t.source IN('livekit-python-postcall','livekit-postcall') OR t.metadata->>'refinedAt' IS NOT NULL
   OR t.metadata->>'finalizedAt' IS NOT NULL OR t.metadata->>'mode' IN('postcall-refined','agent-live-finalized')))
 ON CONFLICT(meeting_id,target_user_id) DO UPDATE SET
  version=memory_meeting_events.version+1,completed=false,cursor_user_id=NULL
$$;
CREATE FUNCTION notify_late_memory_attendee() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='UPDATE' AND NEW IS NOT DISTINCT FROM OLD THEN RETURN NULL; END IF;
 PERFORM wake_future_memory_attendees(NEW.meeting_id);
 RETURN NULL;
END $$;
CREATE TRIGGER memory_late_attendance AFTER INSERT OR UPDATE OF user_id,meeting_id,joined_at,left_at
 ON meeting_attendance_intervals FOR EACH ROW EXECUTE FUNCTION notify_late_memory_attendee();
CREATE TRIGGER memory_late_workspace AFTER INSERT OR UPDATE OF user_id,meeting_id,workspace_id
 ON meeting_attendee_workspaces FOR EACH ROW EXECUTE FUNCTION notify_late_memory_attendee();
CREATE TRIGGER memory_late_participant AFTER INSERT OR UPDATE OF user_id,meeting_id
 ON meeting_participants FOR EACH ROW EXECUTE FUNCTION notify_late_memory_attendee();
