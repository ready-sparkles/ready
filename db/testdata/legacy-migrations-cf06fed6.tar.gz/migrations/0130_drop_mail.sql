-- Drop the inbox. Invite email and calendar data stay.
-- Existing object-storage attachment files are not deleted here.
SET LOCAL lock_timeout = '3min';
SET LOCAL statement_timeout = 0;

DROP TABLE IF EXISTS mail_message_recipients;
DROP TABLE IF EXISTS mail_attachments;
DROP TABLE IF EXISTS mail_change_log;
DROP TABLE IF EXISTS mail_webhook_events;
DROP TABLE IF EXISTS mail_classifier_cache;
DROP TABLE IF EXISTS mail_messages;
DROP TABLE IF EXISTS mail_provider_messages;
DROP TABLE IF EXISTS mail_threads;
DROP TABLE IF EXISTS mail_sync_subscriptions;
DROP TABLE IF EXISTS mail_addresses;
DROP TABLE IF EXISTS mail_accounts;
DROP TABLE IF EXISTS mail_view_waitlist_entries;

ALTER TABLE data_deletion_requests DROP COLUMN IF EXISTS mail_deleted_at;
