CREATE TABLE IF NOT EXISTS user_capability_preferences (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  capability_key varchar(160) NOT NULL REFERENCES capability_catalog(key),
  is_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS user_capability_preferences_user_capability_uidx
  ON user_capability_preferences(user_id, capability_key);

CREATE INDEX IF NOT EXISTS user_capability_preferences_user_idx
  ON user_capability_preferences(user_id);

CREATE INDEX IF NOT EXISTS user_capability_preferences_capability_idx
  ON user_capability_preferences(capability_key);

UPDATE capability_catalog
SET
  name = CASE key
    WHEN 'draft_internal_recap' THEN 'Team Recap'
    WHEN 'draft_external_follow_up' THEN 'Customer Follow-Up'
    WHEN 'draft_decision_brief' THEN 'Decision Brief'
    WHEN 'draft_spec_outline' THEN 'Spec Outline'
    WHEN 'create_task_list' THEN 'Task List'
    WHEN 'file_issue_or_bug' THEN 'Bug Report'
    WHEN 'update_crm' THEN 'CRM Update'
    WHEN 'schedule_follow_up' THEN 'Schedule Follow-Up'
    WHEN 'research_open_question' THEN 'Research Brief'
    WHEN 'prepare_briefing_for_next_meeting' THEN 'Next Meeting Brief'
    ELSE name
  END,
  description = CASE key
    WHEN 'draft_internal_recap' THEN 'Draft a concise recap with the decisions, commitments, and unresolved items the team needs after the meeting.'
    WHEN 'draft_external_follow_up' THEN 'Draft a follow-up message for external participants with promises, asks, and next steps.'
    WHEN 'draft_decision_brief' THEN 'Create a durable brief that explains what was decided, why it matters, and what changes next.'
    WHEN 'draft_spec_outline' THEN 'Turn a product discussion into a lightweight spec with goals, scope notes, requirements, and open questions.'
    WHEN 'create_task_list' THEN 'Convert commitments into a structured task list with owners and due-date hints.'
    WHEN 'file_issue_or_bug' THEN 'Create an issue from a surfaced defect, including impact, reproduction clues, and severity.'
    WHEN 'update_crm' THEN 'Capture account, opportunity, renewal, or customer context for the system of record.'
    WHEN 'schedule_follow_up' THEN 'Prepare the handoff for a next meeting when participants explicitly ask to reconnect.'
    WHEN 'research_open_question' THEN 'Investigate an unresolved question and prepare a focused answer with context.'
    WHEN 'prepare_briefing_for_next_meeting' THEN 'Assemble context, decisions, risks, and questions so the next meeting starts faster.'
    ELSE description
  END,
  updated_at = now()
WHERE key IN (
  'draft_internal_recap',
  'draft_external_follow_up',
  'draft_decision_brief',
  'draft_spec_outline',
  'create_task_list',
  'file_issue_or_bug',
  'update_crm',
  'schedule_follow_up',
  'research_open_question',
  'prepare_briefing_for_next_meeting'
);
