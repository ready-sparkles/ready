CREATE TABLE private_beta_waitlist_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  requested_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE UNIQUE INDEX private_beta_waitlist_entries_user_uidx
  ON private_beta_waitlist_entries (user_id);

CREATE INDEX private_beta_waitlist_entries_requested_at_idx
  ON private_beta_waitlist_entries (requested_at DESC);
