ALTER TABLE ashby_review_actions ADD CONSTRAINT ashby_review_actions_stage_only CHECK (kind = 'stage') NOT VALID;
