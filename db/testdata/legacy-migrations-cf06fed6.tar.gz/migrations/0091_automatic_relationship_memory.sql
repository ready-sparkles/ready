-- Relationship memory is automatic for every eligible workspace member.
-- Existing sensitivity, retention and language preferences remain intact.
ALTER TABLE memory_preferences DROP COLUMN enabled;
