-- Written only by verified guest-session linking, never by a browser cookie alone.
CREATE TABLE guest_memory_account_links (
 guest_user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 account_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
);
ALTER TABLE guest_browser_identities ADD COLUMN linked_account_user_id uuid REFERENCES users(id) ON DELETE SET NULL;
-- Retain redirects for extraction already in flight. Fact keys and evidence are immutable.
CREATE TABLE memory_person_redirects (
 person_id uuid PRIMARY KEY REFERENCES memory_people(id) ON DELETE CASCADE,
 target_person_id uuid NOT NULL REFERENCES memory_people(id) ON DELETE CASCADE,
 CHECK(person_id<>target_person_id)
);
CREATE FUNCTION canonical_memory_person(id uuid) RETURNS uuid LANGUAGE sql STABLE AS $$
 SELECT coalesce((SELECT target_person_id FROM memory_person_redirects WHERE person_id=id),id)
$$;
CREATE FUNCTION canonicalize_memory_people_write() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(hashtextextended('guest-memory-account-link',0));
 NEW.person_ids=ARRAY(SELECT DISTINCT canonical_memory_person(id) FROM unnest(NEW.person_ids) id);
 NEW.candidate_subject_id=canonical_memory_person(NEW.candidate_subject_id);
 RETURN NEW;
END $$;
CREATE TRIGGER canonicalize_memory_people BEFORE INSERT OR UPDATE ON relationship_memories
 FOR EACH ROW EXECUTE FUNCTION canonicalize_memory_people_write();
CREATE FUNCTION prevent_redirected_memory_projection() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(hashtextextended('guest-memory-account-link',0));
 IF EXISTS(SELECT 1 FROM memory_person_redirects WHERE person_id=NEW.person_id) THEN RETURN NULL; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER prevent_redirected_projection BEFORE INSERT OR UPDATE ON memory_person_projections
 FOR EACH ROW EXECUTE FUNCTION prevent_redirected_memory_projection();

CREATE FUNCTION link_guest_memory_account(guest_id uuid,account_id uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE browser_id uuid; account_name text; account_email text; scope record; winner uuid; loser record;
BEGIN
 PERFORM pg_advisory_xact_lock(hashtextextended('guest-memory-account-link',0));
 SELECT display_name,lower(trim(email)) INTO account_name,account_email FROM users WHERE id=account_id AND source IN('auth','dev_login') AND deleted_at IS NULL;
 IF account_name IS NULL OR NOT EXISTS(SELECT 1 FROM users WHERE id=guest_id AND source='guest') THEN
  RAISE EXCEPTION 'Invalid guest account link';
 END IF;
 SELECT b.browser_id INTO browser_id FROM guest_browser_users b WHERE b.guest_user_id=guest_id;
 IF EXISTS(SELECT 1 FROM guest_memory_account_links WHERE guest_user_id=guest_id AND account_user_id<>account_id)
 OR EXISTS(SELECT 1 FROM guest_browser_identities WHERE id=browser_id AND linked_account_user_id IS NOT NULL AND linked_account_user_id<>account_id) THEN
  RAISE EXCEPTION 'Guest recognition is already linked to another account' USING ERRCODE='23505';
 END IF;
 INSERT INTO guest_memory_account_links VALUES(guest_id,account_id) ON CONFLICT DO NOTHING;
 UPDATE guest_browser_identities SET linked_account_user_id=account_id WHERE id=browser_id;
 FOR scope IN
  SELECT DISTINCT i.user_id,i.workspace_id FROM memory_person_identities i
  WHERE ((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email))
   OR (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id))
  ORDER BY i.user_id,i.workspace_id
 LOOP
  PERFORM pg_advisory_xact_lock(hashtextextended('memory-people:'||scope.user_id||':'||scope.workspace_id,0));
  -- Keep the guest/browser person already shown to this owner whenever possible.
  SELECT i.person_id INTO winner FROM memory_person_identities i
  WHERE i.user_id=scope.user_id AND i.workspace_id=scope.workspace_id AND
   (((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email)) OR
    (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id)))
  ORDER BY CASE WHEN i.kind='guest_browser' AND i.identity=browser_id::text THEN 0
    WHEN i.kind='user_id' AND i.identity=guest_id::text THEN 1 ELSE 2 END,i.person_id LIMIT 1;
  -- Preserve an observed guest spelling even for guests who never opted into browser recognition.
  INSERT INTO memory_person_names(person_id,source_id,participant_user_id,name,normalized_name,word_count,observed_at)
   SELECT winner,mi.source_id,guest_id,u.display_name,lower(trim(u.display_name)),
    CASE WHEN lower(trim(u.display_name))='guest' THEN 0 ELSE cardinality(regexp_split_to_array(trim(u.display_name),'\s+')) END,mi.occurred_at
   FROM memory_interactions mi JOIN memory_person_identities gi ON gi.person_id=mi.person_id
   JOIN users u ON u.id=guest_id
   WHERE gi.user_id=scope.user_id AND gi.workspace_id=scope.workspace_id AND gi.kind='user_id' AND gi.identity=guest_id::text
   ON CONFLICT DO NOTHING;
  FOR loser IN
   SELECT DISTINCT i.person_id FROM memory_person_identities i
   WHERE i.user_id=scope.user_id AND i.workspace_id=scope.workspace_id AND i.person_id<>winner AND
    (((i.kind='user_id' AND i.identity IN(guest_id::text,account_id::text)) OR (i.kind='verified_email' AND lower(trim(i.identity))=account_email)) OR
     (i.kind='guest_browser' AND i.identity IN(SELECT id::text FROM guest_browser_identities WHERE linked_account_user_id=account_id)))
  LOOP
   INSERT INTO memory_interactions SELECT source_id,winner,occurred_at FROM memory_interactions WHERE person_id=loser.person_id ON CONFLICT DO NOTHING;
   DELETE FROM memory_interactions WHERE person_id=loser.person_id;
   INSERT INTO memory_person_names SELECT winner,source_id,participant_user_id,name,normalized_name,word_count,observed_at FROM memory_person_names WHERE person_id=loser.person_id ON CONFLICT DO NOTHING;
   DELETE FROM memory_person_names WHERE person_id=loser.person_id;
   UPDATE memory_person_identities SET person_id=winner WHERE person_id=loser.person_id;
   UPDATE memory_person_redirects SET target_person_id=winner WHERE target_person_id=loser.person_id;
   INSERT INTO memory_person_redirects VALUES(loser.person_id,winner) ON CONFLICT(person_id) DO UPDATE SET target_person_id=excluded.target_person_id;
   UPDATE relationship_memories SET person_ids=array_replace(person_ids,loser.person_id,winner),
    candidate_subject_id=CASE WHEN candidate_subject_id=loser.person_id THEN winner ELSE candidate_subject_id END
    WHERE loser.person_id=ANY(person_ids) OR candidate_subject_id=loser.person_id;
   DELETE FROM memory_person_projections WHERE person_id IN(loser.person_id,winner);
  END LOOP;
  INSERT INTO memory_person_identities VALUES(winner,scope.user_id,scope.workspace_id,'user_id',account_id::text) ON CONFLICT DO NOTHING;
  UPDATE memory_people SET name=account_name WHERE id=winner;
 END LOOP;
END $$;
