ALTER TABLE meeting_ambient_context_cursors
  ADD COLUMN IF NOT EXISTS processed_through timestamptz;

UPDATE meeting_ambient_context_cursors AS cursor
SET processed_through = COALESCE(segment.ended_at, segment.started_at)
FROM transcript_segments AS segment
WHERE cursor.last_processed_segment_id = segment.id
  AND cursor.processed_through IS NULL;
