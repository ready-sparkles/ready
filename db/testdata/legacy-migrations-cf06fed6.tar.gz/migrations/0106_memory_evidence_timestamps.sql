-- Display transcript time without changing meeting chronology, importance order,
-- date filters, pagination cursors, or saved summary provenance.
ALTER TABLE relationship_memories ADD COLUMN evidence_occurred_at timestamptz;

-- No generation jobs or AI calls: use only the already-cited transcript evidence.
-- Missing evidence stays NULL so readers fall back to the original meeting time.
WITH evidence_times AS (
  SELECT r.id, max(s.started_at) AS occurred_at
  FROM relationship_memories r
  JOIN memory_sources src ON src.id=r.source_id
  JOIN memory_evidence e ON e.memory_id=r.id
  JOIN transcript_segments s ON s.id=e.segment_id
  JOIN transcripts t ON t.id=s.transcript_id AND t.meeting_id=src.meeting_id
  GROUP BY r.id
)
UPDATE relationship_memories r
SET evidence_occurred_at=e.occurred_at
FROM evidence_times e
WHERE r.id=e.id AND r.evidence_occurred_at IS DISTINCT FROM e.occurred_at;
