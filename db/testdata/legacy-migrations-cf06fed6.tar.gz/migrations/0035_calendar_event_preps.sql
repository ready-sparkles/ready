CREATE TABLE IF NOT EXISTS calendar_event_preps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  calendar_event_id text NOT NULL,
  event_fingerprint text NOT NULL,
  status varchar(32) NOT NULL DEFAULT 'pending',
  taskgroup_id varchar(160),
  run_refs jsonb NOT NULL DEFAULT '{}'::jsonb,
  event_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  error jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS calendar_event_preps_user_event_fingerprint_uidx
  ON calendar_event_preps(user_id, calendar_event_id, event_fingerprint);

CREATE INDEX IF NOT EXISTS calendar_event_preps_user_updated_idx
  ON calendar_event_preps(user_id, updated_at);

CREATE INDEX IF NOT EXISTS calendar_event_preps_taskgroup_idx
  ON calendar_event_preps(taskgroup_id);
