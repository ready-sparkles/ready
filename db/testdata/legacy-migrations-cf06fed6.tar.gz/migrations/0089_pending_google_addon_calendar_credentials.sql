CREATE TABLE IF NOT EXISTS pending_google_addon_calendar_credentials (
  agent_connector_id uuid PRIMARY KEY REFERENCES agent_connectors(id) ON DELETE CASCADE,
  secret_ref text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
