-- Keep every retained memory available, including previously faded or pinned ones.
-- Rebuild affected summaries from their newly eligible evidence.
DELETE FROM memory_person_projections p
WHERE EXISTS (
  SELECT 1 FROM relationship_memories m
  WHERE m.state = 'faded' AND p.person_id = ANY(m.person_ids)
);

ALTER TABLE relationship_memories
  DROP COLUMN state,
  DROP COLUMN fades_at,
  DROP COLUMN restored_at;
ALTER TABLE memory_preferences DROP COLUMN recruiting_months;
-- Forgotten memories and their suppression records remain untouched.
