DO $$
BEGIN
  CREATE TYPE credit_grant_source AS ENUM ('subscription_period', 'credit_topup', 'promotional');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

CREATE TABLE IF NOT EXISTS billing_customers (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  stripe_customer_id varchar(255) NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stripe_subscription_id varchar(255) NOT NULL UNIQUE,
  stripe_price_id varchar(255) NOT NULL,
  status varchar(64) NOT NULL,
  plan_interval varchar(16) NOT NULL,
  included_credits_per_period integer NOT NULL DEFAULT 0,
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS billing_subscriptions_user_idx
  ON billing_subscriptions(user_id, updated_at);

CREATE TABLE IF NOT EXISTS credit_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source credit_grant_source NOT NULL,
  credits integer NOT NULL,
  credits_remaining integer NOT NULL,
  expires_at timestamptz,
  stripe_reference text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS credit_grants_stripe_reference_uidx
  ON credit_grants(stripe_reference)
  WHERE stripe_reference IS NOT NULL;

CREATE INDEX IF NOT EXISTS credit_grants_user_active_idx
  ON credit_grants(user_id, expires_at, created_at);

CREATE TABLE IF NOT EXISTS stripe_webhook_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  stripe_event_id varchar(255) NOT NULL UNIQUE,
  event_type varchar(128) NOT NULL,
  processed_at timestamptz NOT NULL DEFAULT now()
);
