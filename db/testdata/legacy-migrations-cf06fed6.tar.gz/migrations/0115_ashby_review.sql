ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'review_ashby_actions';
-- Shared transcript-only analysis; never stores provider records.
CREATE TABLE ashby_meeting_analyses (
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  input_hash text NOT NULL,
  result jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (meeting_id, input_hash)
);
CREATE TABLE ashby_reviews (
  id uuid PRIMARY KEY,
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  revision integer NOT NULL DEFAULT 0,
  review jsonb NOT NULL,
  command jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (meeting_id, user_id, workspace_id)
);
-- A claim is committed BEFORE a provider write. Abandoned claims may only be
-- reconciled, never resent. One action per target/meeting across all viewers.
CREATE TABLE ashby_review_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind = 'stage'),
  target_id text NOT NULL,
  status text NOT NULL DEFAULT 'unknown' CHECK (status IN ('unknown', 'completed', 'rejected')),
  result jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, meeting_id, kind, target_id)
);
