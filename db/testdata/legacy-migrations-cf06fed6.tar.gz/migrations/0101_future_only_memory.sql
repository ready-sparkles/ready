-- One permanent boundary per database. Existing memories and summaries are retained.
CREATE TABLE memory_runtime_policy (
 id boolean PRIMARY KEY DEFAULT true CHECK(id),
 future_only_since timestamptz NOT NULL DEFAULT clock_timestamp()
);
INSERT INTO memory_runtime_policy(id) VALUES(true);
ALTER TABLE memory_jobs ADD COLUMN future_only boolean NOT NULL DEFAULT false;
UPDATE memory_jobs SET status='cancelled',lease_token=NULL,error='Legacy memory processing retired'
 WHERE status IN('queued','running','failed');

-- Independent of source rows: deleting/forgetting derived data never restores an allowance.
CREATE TABLE memory_generation_ledger (
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
 workspace_id uuid NOT NULL,
 job_id uuid NOT NULL UNIQUE,
 model_started_at timestamptz,
 PRIMARY KEY(user_id,meeting_id)
);
INSERT INTO memory_generation_ledger(user_id,meeting_id,workspace_id,job_id,model_started_at)
 SELECT DISTINCT ON(j.user_id,s.meeting_id) j.user_id,s.meeting_id,j.workspace_id,j.id,coalesce(j.locked_at,j.created_at)
 FROM memory_jobs j JOIN memory_sources s ON s.id=j.source_id WHERE j.kind='extract' AND s.meeting_id IS NOT NULL
 ORDER BY j.user_id,s.meeting_id,j.created_at,j.id;

CREATE TABLE memory_meeting_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
 target_user_id uuid REFERENCES users(id) ON DELETE CASCADE,
 cursor_user_id uuid,
 completed boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE NULLS NOT DISTINCT(meeting_id,target_user_id)
);
CREATE INDEX memory_meeting_events_pending ON memory_meeting_events(created_at,id) WHERE NOT completed;
CREATE FUNCTION queue_future_memory_event(mid uuid) RETURNS void LANGUAGE sql AS $$
 INSERT INTO memory_meeting_events(meeting_id)
 SELECT m.id FROM meetings m CROSS JOIN memory_runtime_policy policy
 WHERE m.id=mid AND m.status='ended' AND m.kind='standard' AND m.ended_at>policy.future_only_since
 AND EXISTS(SELECT 1 FROM transcripts t WHERE t.meeting_id=m.id AND
  (t.source IN('livekit-python-postcall','livekit-postcall') OR t.metadata->>'refinedAt' IS NOT NULL
   OR t.metadata->>'finalizedAt' IS NOT NULL OR t.metadata->>'mode' IN('postcall-refined','agent-live-finalized')))
 ON CONFLICT(meeting_id,target_user_id) DO NOTHING
$$;
CREATE OR REPLACE FUNCTION notify_finalized_memory_transcript() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN PERFORM queue_future_memory_event(NEW.meeting_id); RETURN NULL; END $$;
CREATE OR REPLACE FUNCTION notify_ended_memory_meeting() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN IF NEW.status='ended' THEN PERFORM queue_future_memory_event(NEW.id); END IF; RETURN NULL; END $$;
DROP TRIGGER memory_ended_meeting ON meetings;
CREATE TRIGGER memory_ended_meeting AFTER INSERT OR UPDATE OF status,ended_at ON meetings
 FOR EACH ROW EXECUTE FUNCTION notify_ended_memory_meeting();
DROP FUNCTION queue_meeting_memory_discovery(uuid);
-- Existing finalization/status triggers now emit only future meeting events.
-- Transcript edits invalidate evidence but cannot enqueue regeneration.
CREATE OR REPLACE FUNCTION invalidate_meeting_memories() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE tid uuid; mid uuid;
BEGIN
 IF TG_OP='UPDATE' AND ROW(NEW.id,NEW.transcript_id,NEW.speaker_user_id,NEW.speaker_name,NEW.speaker_role,NEW.content,NEW.started_at)
  IS NOT DISTINCT FROM ROW(OLD.id,OLD.transcript_id,OLD.speaker_user_id,OLD.speaker_name,OLD.speaker_role,OLD.content,OLD.started_at) THEN RETURN NULL; END IF;
 IF TG_OP='DELETE' THEN tid=OLD.transcript_id; ELSE tid=NEW.transcript_id; END IF;
 SELECT meeting_id INTO mid FROM transcripts WHERE id=tid;
 UPDATE memory_sources SET is_current=false WHERE meeting_id=mid;
 IF TG_OP='UPDATE' AND OLD.transcript_id IS DISTINCT FROM NEW.transcript_id THEN
  UPDATE memory_sources SET is_current=false WHERE meeting_id=(SELECT meeting_id FROM transcripts WHERE id=OLD.transcript_id);
 END IF;
 RETURN NULL;
END $$;
DROP TABLE memory_backfills;
DROP TABLE memory_discovery_cursors;
DROP TABLE memory_discovery_requests;
DROP TABLE memory_extraction_checkpoints;

-- Summary provenance survives Forget, but source changes or revoked access hide it.
ALTER TABLE memory_person_projections ADD COLUMN source_revisions jsonb;
UPDATE memory_person_projections p SET source_revisions=(
 SELECT coalesce(jsonb_object_agg(s.id::text,s.revision),'{}'::jsonb)
 FROM memory_sources s WHERE s.id IN (
  SELECT r.source_id FROM relationship_memories r WHERE r.id::text IN (
   SELECT jsonb_array_elements_text(item->'memoryIds')
   FROM jsonb_array_elements(coalesce(p.content->'summary','[]'::jsonb)||coalesce(p.content->'standing','[]'::jsonb)) item
  )
 )
);
-- Unresolvable legacy citations are hidden, never regenerated.
UPDATE memory_person_projections p SET source_revisions=NULL WHERE EXISTS (
 SELECT 1 FROM jsonb_array_elements(coalesce(p.content->'summary','[]'::jsonb)||coalesce(p.content->'standing','[]'::jsonb)) item,
 LATERAL jsonb_array_elements_text(item->'memoryIds') ref
 WHERE NOT EXISTS(SELECT 1 FROM relationship_memories r WHERE r.id::text=ref)
);
