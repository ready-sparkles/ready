ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'finalize_meeting';
ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'resolve_meeting_title';
