-- Billing is an external-state workflow. Keep durable checkout/webhook state,
-- bound past-due access, and record every manual entitlement change.

alter table billing_subscriptions
  add column if not exists status_changed_at timestamptz;

-- `updated_at` is the best historical status timestamp available on legacy
-- rows. Backfilling with the migration time would grant every old past-due
-- subscription a fresh grace window.
update billing_subscriptions
set status_changed_at = coalesce(updated_at, created_at, now())
where status_changed_at is null;

alter table billing_subscriptions
  alter column status_changed_at set default now(),
  alter column status_changed_at set not null;

-- Expired Stripe periods are not current subscriptions even if their last
-- observed Stripe status was active/trialing. Free the partial unique slot so
-- a replacement subscription can be synchronized after Checkout completes.
update billing_subscriptions
set status = 'superseded', status_changed_at = now(), updated_at = now()
where status in ('active', 'trialing')
  and current_period_end is not null
  and current_period_end <= now();

with ranked as (
  select id, row_number() over (
    partition by workspace_id
    order by updated_at desc, created_at desc, id desc
  ) as position
  from billing_subscriptions
  where workspace_id is not null
    and status in ('active', 'trialing')
)
update billing_subscriptions
set status = 'superseded', status_changed_at = now(), updated_at = now()
where id in (select id from ranked where position > 1);

with ranked as (
  select id, row_number() over (
    partition by user_id
    order by updated_at desc, created_at desc, id desc
  ) as position
  from billing_subscriptions
  where workspace_id is null
    and status in ('active', 'trialing')
)
update billing_subscriptions
set status = 'superseded', status_changed_at = now(), updated_at = now()
where id in (select id from ranked where position > 1);

create unique index if not exists billing_subscriptions_running_workspace_uidx
  on billing_subscriptions (workspace_id)
  where workspace_id is not null and status in ('active', 'trialing');

create unique index if not exists billing_subscriptions_running_user_uidx
  on billing_subscriptions (user_id)
  where workspace_id is null and status in ('active', 'trialing');

alter table stripe_webhook_events
  alter column processed_at drop not null,
  alter column processed_at drop default,
  add column if not exists stripe_created_at timestamptz,
  add column if not exists payload jsonb not null default '{}'::jsonb,
  add column if not exists status varchar(16) not null default 'pending',
  add column if not exists attempt_count integer not null default 0,
  add column if not exists next_attempt_at timestamptz not null default now(),
  add column if not exists locked_by varchar(160),
  add column if not exists locked_at timestamptz,
  add column if not exists last_error text,
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

create index if not exists stripe_webhook_events_due_idx
  on stripe_webhook_events (status, next_attempt_at);

update stripe_webhook_events
set status = 'processed'
where processed_at is not null;

create table if not exists billing_checkout_attempts (
  id uuid primary key default gen_random_uuid(),
  subject_type varchar(16) not null,
  subject_id uuid not null,
  checkout_kind varchar(16) not null,
  request_key varchar(255) not null unique,
  request_params jsonb not null default '{}'::jsonb,
  stripe_checkout_session_id varchar(255) unique,
  checkout_url text,
  expires_at timestamptz,
  status varchar(16) not null default 'pending',
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint billing_checkout_attempts_subject_type_check
    check (subject_type in ('user', 'workspace')),
  constraint billing_checkout_attempts_kind_check
    check (checkout_kind in ('subscription', 'topup')),
  constraint billing_checkout_attempts_status_check
    check (status in ('pending', 'completed', 'expired', 'failed'))
);

create unique index if not exists billing_checkout_attempts_pending_uidx
  on billing_checkout_attempts (subject_type, subject_id, checkout_kind)
  where status = 'pending';

create index if not exists billing_checkout_attempts_session_idx
  on billing_checkout_attempts (stripe_checkout_session_id)
  where stripe_checkout_session_id is not null;

create table if not exists admin_user_plan_changes (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references users(id) on delete set null,
  target_user_id uuid not null references users(id) on delete cascade,
  previous_plan user_plan not null,
  next_plan user_plan not null,
  source varchar(32) not null default 'admin_manual',
  created_at timestamptz not null default now()
);

create index if not exists admin_user_plan_changes_target_idx
  on admin_user_plan_changes (target_user_id, created_at desc);
