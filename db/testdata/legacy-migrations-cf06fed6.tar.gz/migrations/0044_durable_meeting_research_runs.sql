ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'run_meeting_research';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_type
    WHERE typname = 'meeting_research_run_status'
  ) THEN
    CREATE TYPE meeting_research_run_status AS ENUM (
      'queued',
      'running',
      'completed',
      'failed',
      'cancelled'
    );
  END IF;
END $$;

ALTER TABLE ai_workflow_jobs
  ADD COLUMN IF NOT EXISTS scope_key varchar(160) NOT NULL DEFAULT 'default';

DROP INDEX IF EXISTS ai_workflow_jobs_active_pipeline_uidx;

CREATE UNIQUE INDEX IF NOT EXISTS ai_workflow_jobs_active_pipeline_uidx
  ON ai_workflow_jobs(meeting_id, type, scope_key)
  WHERE status IN ('queued', 'running');

CREATE TABLE IF NOT EXISTS meeting_research_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  recommendation_id uuid NOT NULL REFERENCES meeting_capability_recommendations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_profile_id uuid NOT NULL REFERENCES agent_profiles(id) ON DELETE CASCADE,
  query text NOT NULL,
  task_kind varchar(64) NOT NULL DEFAULT 'answer_question',
  status meeting_research_run_status NOT NULL DEFAULT 'queued',
  progress_label text,
  progress_detail text,
  progress_updated_at timestamptz,
  run_refs jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  error jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  cancelled_at timestamptz
);

CREATE INDEX IF NOT EXISTS meeting_research_runs_meeting_created_idx
  ON meeting_research_runs(meeting_id, created_at);

CREATE INDEX IF NOT EXISTS meeting_research_runs_recommendation_idx
  ON meeting_research_runs(recommendation_id);

CREATE INDEX IF NOT EXISTS meeting_research_runs_status_updated_idx
  ON meeting_research_runs(status, updated_at);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_research_runs_active_recommendation_uidx
  ON meeting_research_runs(meeting_id, recommendation_id)
  WHERE status IN ('queued', 'running');

UPDATE capability_catalog
SET
  name = 'Deep Research',
  description = 'Run durable web-backed research, extraction, entity discovery, and synthesis for a meeting topic or requested research task.',
  required_signals = jsonb_build_array(
    jsonb_build_object(
      'key', 'web_research_task_identified',
      'description', 'This capability applies when the meeting surfaced a web-backed research, extraction, discovery, comparison, or dataset task.'
    )
  ),
  example_triggers = jsonb_build_array(
    'Find and compare 20 relevant companies for this market.',
    'Extract useful details from these pages and PDFs.',
    'Build a structured dataset from the open web.',
    'Research current competitors and return a sourced summary.'
  ),
  metadata = jsonb_set(
    coalesce(metadata, '{}'::jsonb),
    '{integrationTargets}',
    '["Parallel Search", "Parallel Extract", "Parallel FindAll", "Deep Synthesis"]'::jsonb,
    true
  ),
  updated_at = now()
WHERE key = 'research_open_question';
