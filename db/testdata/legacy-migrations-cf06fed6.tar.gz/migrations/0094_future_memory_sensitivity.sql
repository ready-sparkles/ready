-- Sensitivity is an extraction policy for future meetings, not a history filter.
CREATE TABLE memory_sensitivity_history (
 user_id uuid NOT NULL, workspace_id uuid NOT NULL,
 effective_at timestamptz NOT NULL, include_sensitive boolean NOT NULL,
 PRIMARY KEY(user_id,workspace_id,effective_at),
 FOREIGN KEY(user_id,workspace_id) REFERENCES memory_preferences(user_id,workspace_id) ON DELETE CASCADE
);

-- Preserve the policy of existing sources and existing accounts at upgrade.
INSERT INTO memory_sensitivity_history
 SELECT user_id,workspace_id,'-infinity'::timestamptz,include_sensitive FROM memory_preferences;
ALTER TABLE memory_sources ADD COLUMN include_sensitive boolean NOT NULL DEFAULT false;
UPDATE memory_sources s SET include_sensitive=p.include_sensitive OR EXISTS(SELECT 1 FROM relationship_memories r WHERE r.source_id=s.id AND r.sensitive)
 FROM memory_preferences p WHERE p.user_id=s.user_id AND p.workspace_id=s.workspace_id;

CREATE FUNCTION record_memory_sensitivity() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  INSERT INTO memory_sensitivity_history VALUES(NEW.user_id,NEW.workspace_id,'-infinity',false);
  IF NOT NEW.include_sensitive THEN RETURN NEW; END IF;
 ELSIF NEW.include_sensitive=OLD.include_sensitive THEN
  RETURN NEW;
 END IF;
 INSERT INTO memory_sensitivity_history VALUES(NEW.user_id,NEW.workspace_id,clock_timestamp(),NEW.include_sensitive);
 RETURN NEW;
END $$;
CREATE TRIGGER memory_sensitivity_policy AFTER INSERT OR UPDATE OF include_sensitive ON memory_preferences
 FOR EACH ROW EXECUTE FUNCTION record_memory_sensitivity();
