ALTER TYPE ai_workflow_job_type ADD VALUE IF NOT EXISTS 'generate_meeting_tasks';

CREATE TYPE meeting_task_list_status AS ENUM (
  'pending',
  'generating',
  'completed',
  'failed'
);

CREATE TYPE meeting_task_type AS ENUM (
  'action_item',
  'follow_up',
  'task',
  'decision_follow_up',
  'open_question'
);

CREATE TYPE meeting_task_status AS ENUM (
  'open',
  'completed',
  'dismissed'
);

CREATE TYPE meeting_task_origin AS ENUM (
  'meeting_transcript'
);

CREATE TABLE meeting_task_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE UNIQUE,
  status meeting_task_list_status NOT NULL DEFAULT 'pending',
  phase varchar(64),
  error jsonb,
  model varchar(160),
  prompt_version varchar(32),
  transcript_hash varchar(128),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

CREATE INDEX meeting_task_lists_meeting_idx ON meeting_task_lists(meeting_id);
CREATE INDEX meeting_task_lists_status_idx ON meeting_task_lists(status);

CREATE TABLE meeting_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  task_list_id uuid NOT NULL REFERENCES meeting_task_lists(id) ON DELETE CASCADE,
  position integer NOT NULL DEFAULT 0,
  title varchar(160) NOT NULL,
  description text,
  type meeting_task_type NOT NULL,
  owner_name varchar(120),
  owner_email varchar(255),
  owner_confidence extraction_confidence,
  due_date_value varchar(120),
  due_date_confidence extraction_confidence,
  confidence extraction_confidence NOT NULL,
  source_quotes jsonb NOT NULL DEFAULT '[]'::jsonb,
  source_reason text NOT NULL,
  status meeting_task_status NOT NULL DEFAULT 'open',
  created_from meeting_task_origin NOT NULL DEFAULT 'meeting_transcript',
  external_links jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX meeting_tasks_meeting_idx ON meeting_tasks(meeting_id, position);
CREATE INDEX meeting_tasks_list_idx ON meeting_tasks(task_list_id, position);
CREATE INDEX meeting_tasks_status_idx ON meeting_tasks(status);

UPDATE capability_catalog
SET
  is_active = false,
  description = 'Native Ready Tasks now capture meeting commitments before specialized workflows are matched.',
  updated_at = now()
WHERE key = 'create_task_list';
