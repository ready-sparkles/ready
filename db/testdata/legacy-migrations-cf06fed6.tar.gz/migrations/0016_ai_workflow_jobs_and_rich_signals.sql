CREATE TYPE ai_workflow_job_type AS ENUM (
  'meeting_post_end_pipeline',
  'extract_meeting_content',
  'detect_meeting_signals',
  'select_capabilities',
  'draft_capability_payloads'
);

CREATE TYPE ai_workflow_job_status AS ENUM (
  'queued',
  'running',
  'completed',
  'failed',
  'cancelled'
);

CREATE TABLE ai_workflow_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  extraction_id uuid REFERENCES meeting_extractions(id) ON DELETE SET NULL,
  type ai_workflow_job_type NOT NULL,
  status ai_workflow_job_status NOT NULL DEFAULT 'queued',
  phase varchar(64) NOT NULL DEFAULT 'queued',
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  error text,
  attempt_count integer NOT NULL DEFAULT 0,
  max_attempts integer NOT NULL DEFAULT 3,
  run_after timestamptz NOT NULL DEFAULT now(),
  locked_by varchar(160),
  locked_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX ai_workflow_jobs_meeting_idx ON ai_workflow_jobs(meeting_id, created_at);
CREATE INDEX ai_workflow_jobs_runnable_idx ON ai_workflow_jobs(status, run_after);
CREATE INDEX ai_workflow_jobs_lock_idx ON ai_workflow_jobs(locked_at);

CREATE UNIQUE INDEX ai_workflow_jobs_active_pipeline_uidx
  ON ai_workflow_jobs(meeting_id, type)
  WHERE type = 'meeting_post_end_pipeline' AND status IN ('queued', 'running');

UPDATE meeting_extractions
SET signals = (
  SELECT coalesce(jsonb_agg(
    jsonb_strip_nulls(jsonb_build_object(
      'key', signal->>'key',
      'namespace', coalesce(signal->>'namespace', 'readymeet.core'),
      'definitionId', signal->'definitionId',
      'confidence', signal->>'confidence',
      'sourceSpans', coalesce(signal->'sourceSpans', '[]'::jsonb),
      'evidence', coalesce(
        signal->'evidence',
        (
          SELECT coalesce(jsonb_agg(span.value || jsonb_build_object('sourceSpanIndex', span.ordinality - 1)), '[]'::jsonb)
          FROM jsonb_array_elements(coalesce(signal->'sourceSpans', '[]'::jsonb)) WITH ORDINALITY AS span(value, ordinality)
        )
      ),
      'entities', coalesce(signal->'entities', '{}'::jsonb),
      'sourcePhase', coalesce(signal->>'sourcePhase', 'signal_extraction'),
      'origin', coalesce(
        signal->'origin',
        jsonb_build_object(
          'kind', 'core_model',
          'model', extraction_model,
          'promptVersion', extraction_prompt_version
        )
      ),
      'reasoning', signal->'reasoning',
      'createdAt', coalesce(signal->>'createdAt', created_at::text)
    ))
  ), '[]'::jsonb)
  FROM jsonb_array_elements(coalesce(signals, '[]'::jsonb)) AS signal
)
WHERE jsonb_array_length(coalesce(signals, '[]'::jsonb)) > 0;
