ALTER TABLE mail_messages
  ADD COLUMN IF NOT EXISTS calendar_invite jsonb;
