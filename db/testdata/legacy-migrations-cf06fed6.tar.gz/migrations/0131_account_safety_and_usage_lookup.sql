-- Additive deployment: preserve billing history and existing provider identities.
ALTER TABLE users ADD COLUMN deletion_requested_at timestamptz;
CREATE INDEX ai_credit_usage_events_user_workspace_created_idx
  ON ai_credit_usage_events(user_id, workspace_id, created_at);
