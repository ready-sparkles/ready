CREATE TABLE IF NOT EXISTS calendar_sync_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_connector_id uuid NOT NULL REFERENCES agent_connectors(id) ON DELETE CASCADE,
  provider varchar(64) NOT NULL,
  calendar_id varchar(255) NOT NULL DEFAULT 'primary',
  channel_id varchar(64) NOT NULL,
  resource_id varchar(255),
  resource_uri text,
  expiration_at timestamptz,
  status varchar(32) NOT NULL DEFAULT 'active',
  last_message_number varchar(64),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS calendar_sync_subscriptions_connector_calendar_uidx
  ON calendar_sync_subscriptions(agent_connector_id, calendar_id);

CREATE INDEX IF NOT EXISTS calendar_sync_subscriptions_channel_idx
  ON calendar_sync_subscriptions(provider, channel_id);

CREATE INDEX IF NOT EXISTS calendar_sync_subscriptions_user_idx
  ON calendar_sync_subscriptions(user_id, provider, status);
