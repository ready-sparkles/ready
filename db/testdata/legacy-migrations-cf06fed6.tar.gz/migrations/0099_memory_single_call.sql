-- A complete model response survives publication retries. Do not reset jobs,
-- completed extractions, preferences, source revisions or backfill cursors.
ALTER TABLE memory_extraction_checkpoints ADD COLUMN generation jsonb;
