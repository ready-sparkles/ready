CREATE TABLE IF NOT EXISTS mail_pipeline_heartbeats (
  worker_name varchar(160) PRIMARY KEY,
  worker_kind varchar(64) NOT NULL,
  last_heartbeat_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS mail_pipeline_heartbeats_kind_idx
  ON mail_pipeline_heartbeats(worker_kind, last_heartbeat_at);

CREATE TABLE IF NOT EXISTS mail_webhook_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider mail_account_provider NOT NULL,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  account_id uuid REFERENCES mail_accounts(id) ON DELETE SET NULL,
  email text,
  provider_history_id text,
  provider_subscription_id text,
  pubsub_message_id text,
  publish_time timestamptz,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  status varchar(32) NOT NULL,
  enqueue_job_id uuid REFERENCES mail_jobs(id) ON DELETE SET NULL,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS mail_webhook_events_account_created_idx
  ON mail_webhook_events(account_id, created_at DESC);

CREATE INDEX IF NOT EXISTS mail_webhook_events_provider_created_idx
  ON mail_webhook_events(provider, created_at DESC);

CREATE INDEX IF NOT EXISTS mail_webhook_events_pubsub_message_idx
  ON mail_webhook_events(pubsub_message_id)
  WHERE pubsub_message_id IS NOT NULL;
