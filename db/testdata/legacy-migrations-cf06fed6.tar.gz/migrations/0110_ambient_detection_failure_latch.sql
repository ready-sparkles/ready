-- A durable attempt claim: failures and interrupted requests require explicit
-- operator recovery, never an automatic paid replay on a later transcript event.
ALTER TABLE meeting_ambient_context_cursors
  ADD COLUMN detection_state varchar(16) NOT NULL DEFAULT 'idle'
  CHECK (detection_state IN ('idle', 'running', 'failed')),
  ADD COLUMN detection_requested boolean NOT NULL DEFAULT false;
