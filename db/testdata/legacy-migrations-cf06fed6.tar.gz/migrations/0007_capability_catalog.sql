DO $$
BEGIN
  CREATE TYPE capability_category AS ENUM (
    'communication',
    'documentation',
    'execution',
    'state_sync',
    'coordination',
    'investigation',
    'preparation'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE side_effect_scope AS ENUM (
    'none',
    'private_draft',
    'shared_draft',
    'external_action'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS capability_catalog (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key varchar(160) NOT NULL,
  name varchar(255) NOT NULL,
  description text NOT NULL,
  category capability_category NOT NULL,
  applicable_meeting_types jsonb NOT NULL DEFAULT '[]'::jsonb,
  required_signals jsonb NOT NULL DEFAULT '[]'::jsonb,
  exclusion_signals jsonb NOT NULL DEFAULT '[]'::jsonb,
  example_triggers jsonb NOT NULL DEFAULT '[]'::jsonb,
  side_effect_scope side_effect_scope NOT NULL,
  default_priority integer NOT NULL DEFAULT 50,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS capability_catalog_key_uidx
  ON capability_catalog(key);

CREATE INDEX IF NOT EXISTS capability_catalog_active_idx
  ON capability_catalog(is_active);

CREATE INDEX IF NOT EXISTS capability_catalog_category_idx
  ON capability_catalog(category);
