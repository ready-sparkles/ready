-- Replace the two-value membership enum transactionally. PostgreSQL does not
-- allow a newly-added enum value to be used until the transaction commits, so
-- rebuilding the type lets this migration backfill owners atomically.
ALTER TYPE workspace_membership_role RENAME TO workspace_membership_role_old;

CREATE TYPE workspace_membership_role AS ENUM ('owner', 'admin', 'member');

ALTER TABLE workspace_memberships
  ALTER COLUMN role DROP DEFAULT,
  ALTER COLUMN role TYPE workspace_membership_role
    USING role::text::workspace_membership_role,
  ALTER COLUMN role SET DEFAULT 'member'::workspace_membership_role;

ALTER TABLE workspace_invitations
  ALTER COLUMN role DROP DEFAULT,
  ALTER COLUMN role TYPE workspace_membership_role
    USING role::text::workspace_membership_role,
  ALTER COLUMN role SET DEFAULT 'member'::workspace_membership_role;

DROP TYPE workspace_membership_role_old;

-- Prefer the active creator, then the oldest active admin, then the oldest
-- active member. Historical workspace tombstones left after account deletion
-- can have neither a creator nor any memberships; those remain inaccessible
-- instead of silently granting workspace access to an unrelated user.
WITH ranked_candidates AS (
  SELECT
    wm.workspace_id,
    wm.user_id,
    row_number() OVER (
      PARTITION BY wm.workspace_id
      ORDER BY
        CASE
          WHEN wm.user_id = w.created_by_user_id THEN 0
          WHEN wm.role = 'admin' THEN 1
          ELSE 2
        END,
        wm.created_at,
        wm.user_id
    ) AS owner_rank
  FROM workspace_memberships wm
  INNER JOIN workspaces w ON w.id = wm.workspace_id
  WHERE wm.status = 'active'
)
UPDATE workspace_memberships wm
SET role = 'owner', updated_at = now()
FROM ranked_candidates candidate
WHERE candidate.workspace_id = wm.workspace_id
  AND candidate.user_id = wm.user_id
  AND candidate.owner_rank = 1;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM workspaces w
    WHERE (w.created_by_user_id IS NOT NULL OR EXISTS (
      SELECT 1 FROM workspace_memberships any_member WHERE any_member.workspace_id = w.id
    ))
      AND NOT EXISTS (
      SELECT 1
      FROM workspace_memberships wm
      WHERE wm.workspace_id = w.id
        AND wm.role = 'owner'
        AND wm.status = 'active'
    )
  ) THEN
    RAISE EXCEPTION 'Every workspace must have one active owner before migration can complete';
  END IF;
END $$;

CREATE UNIQUE INDEX workspace_memberships_active_owner_uidx
  ON workspace_memberships(workspace_id)
  WHERE role = 'owner' AND status = 'active';
