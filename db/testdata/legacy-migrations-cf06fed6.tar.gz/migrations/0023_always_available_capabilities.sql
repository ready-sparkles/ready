INSERT INTO capability_catalog (
  key,
  name,
  description,
  category,
  applicable_meeting_types,
  required_signals,
  exclusion_signals,
  example_triggers,
  side_effect_scope,
  default_priority,
  is_active,
  metadata
)
VALUES
  (
    'meeting_coaching',
    'Meeting Feedback',
    'Review the meeting and suggest ways to make the next one clearer, tighter, and more useful.',
    'preparation',
    '[
      "team_sync",
      "one_on_one",
      "sales_call",
      "customer_success",
      "product_review",
      "standup",
      "interview",
      "planning",
      "brainstorm",
      "retrospective",
      "postmortem",
      "manager_check_in",
      "other"
    ]'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb,
    '[
      "Give me feedback on how this meeting went.",
      "Help me improve the next version of this conversation."
    ]'::jsonb,
    'none',
    40,
    true,
    '{"alwaysAvailable": true, "integrationTargets": []}'::jsonb
  ),
  (
    'draft_participant_follow_up',
    'Participant Follow-Up',
    'Draft a follow-up message for the meeting participants without sending anything automatically.',
    'communication',
    '[
      "team_sync",
      "one_on_one",
      "sales_call",
      "customer_success",
      "product_review",
      "standup",
      "interview",
      "planning",
      "brainstorm",
      "retrospective",
      "postmortem",
      "manager_check_in",
      "other"
    ]'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb,
    '[
      "Draft a follow-up for the people in this meeting.",
      "Help me send everyone a clear recap after this conversation."
    ]'::jsonb,
    'private_draft',
    39,
    true,
    '{"alwaysAvailable": true, "integrationTargets": ["Gmail", "Outlook"]}'::jsonb
  )
ON CONFLICT (key) DO UPDATE
SET
  name = excluded.name,
  description = excluded.description,
  category = excluded.category,
  applicable_meeting_types = excluded.applicable_meeting_types,
  required_signals = excluded.required_signals,
  exclusion_signals = excluded.exclusion_signals,
  example_triggers = excluded.example_triggers,
  side_effect_scope = excluded.side_effect_scope,
  default_priority = excluded.default_priority,
  is_active = excluded.is_active,
  metadata = excluded.metadata,
  updated_at = now();
