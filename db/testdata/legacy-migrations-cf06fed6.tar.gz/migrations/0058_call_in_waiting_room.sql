ALTER TABLE meeting_link_call_ins
  ADD COLUMN IF NOT EXISTS dispatch_rule_kind varchar(16) NOT NULL DEFAULT 'direct';

ALTER TABLE meeting_join_requests
  ADD COLUMN IF NOT EXISTS sip_call_id varchar(255),
  ADD COLUMN IF NOT EXISTS sip_participant_identity varchar(255),
  ADD COLUMN IF NOT EXISTS sip_holding_room varchar(255);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_join_requests_sip_call_uidx
  ON meeting_join_requests(sip_call_id)
  WHERE sip_call_id IS NOT NULL;
