-- Ashby is configured once per workspace by an admin; members opt in one by one.
CREATE TABLE workspace_ashby_integrations (
  workspace_id uuid PRIMARY KEY REFERENCES workspaces(id) ON DELETE CASCADE,
  -- Encrypted API key; never returned to clients.
  secret_ref text NOT NULL,
  configured_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Members who turned Ashby on for themselves. Only they see Ashby data in Ready.
CREATE TABLE ashby_member_connections (
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  connected_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (workspace_id, user_id)
);

-- Cached email → Ashby candidate lookups, so person pages don't call Ashby on
-- every view. A null candidate_id records that no candidate uses the email.
CREATE TABLE ashby_candidate_email_lookups (
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  email text NOT NULL,
  candidate_id text,
  profile_url text,
  checked_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (workspace_id, email)
);
