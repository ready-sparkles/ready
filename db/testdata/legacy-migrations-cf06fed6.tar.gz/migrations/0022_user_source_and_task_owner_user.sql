CREATE TYPE user_source AS ENUM (
  'auth',
  'dev_login',
  'debug_import'
);

ALTER TABLE users
  ADD COLUMN source user_source NOT NULL DEFAULT 'auth';

ALTER TABLE meeting_tasks
  ADD COLUMN owner_user_id uuid REFERENCES users(id) ON DELETE SET NULL;

CREATE INDEX meeting_tasks_owner_user_idx ON meeting_tasks(owner_user_id);
