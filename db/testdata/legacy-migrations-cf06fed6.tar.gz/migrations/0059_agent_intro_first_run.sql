alter table users
  add column if not exists agent_intro_completed_at timestamptz;

alter table meetings
  add column if not exists kind varchar(32) not null default 'standard';

alter table meetings
  add constraint meetings_kind_check check (kind in ('standard', 'agent_intro'));

create index if not exists meetings_creator_kind_idx
  on meetings (created_by_user_id, kind, created_at desc);

create unique index if not exists meetings_agent_intro_creator_uidx
  on meetings (created_by_user_id)
  where kind = 'agent_intro'
    and hidden_from_history_reason is distinct from 'debug_onboarding_reset';
