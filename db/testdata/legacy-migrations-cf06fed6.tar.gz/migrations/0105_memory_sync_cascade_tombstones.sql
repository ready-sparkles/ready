-- An AFTER DELETE on a memory cannot resolve its source after ON DELETE CASCADE.
-- Record the tombstones while the source and its children still exist. The owner
-- checks in mark_memory_sync_change also let account/workspace deletion clean up
-- normally without recreating sync heads for a deleted owner.
CREATE FUNCTION track_memory_sync_source_delete() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE memory_id uuid;
BEGIN
  FOR memory_id IN SELECT id FROM relationship_memories WHERE source_id=OLD.id ORDER BY id LOOP
    PERFORM mark_memory_sync_change(memory_id, OLD.id);
  END LOOP;
  RETURN OLD;
END $$;
CREATE TRIGGER memory_sync_source_delete BEFORE DELETE ON memory_sources
FOR EACH ROW EXECUTE FUNCTION track_memory_sync_source_delete();
