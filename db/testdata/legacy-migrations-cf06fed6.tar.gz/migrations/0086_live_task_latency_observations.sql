CREATE TABLE IF NOT EXISTS meeting_task_latency_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  task_id uuid NOT NULL REFERENCES meeting_tasks(id) ON DELETE CASCADE,
  task_revision integer NOT NULL,
  kind varchar(24) NOT NULL CHECK (kind IN ('appearance', 'owner', 'due_date', 'completion')),
  evidence_at timestamptz NOT NULL,
  transcript_received_at timestamptz,
  queue_started_at timestamptz,
  model_completed_at timestamptz,
  validation_committed_at timestamptz NOT NULL DEFAULT now(),
  outbox_published_at timestamptz,
  realtime_received_at timestamptz,
  refetch_started_at timestamptz,
  refetch_completed_at timestamptz,
  rendered_at timestamptz,
  client_continuity varchar(16) CHECK (client_continuity IN ('continuous', 'recovered')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_task_latency_observations_revision_kind_uidx
  ON meeting_task_latency_observations (task_id, task_revision, kind);

CREATE INDEX IF NOT EXISTS meeting_task_latency_observations_meeting_kind_idx
  ON meeting_task_latency_observations (meeting_id, kind, evidence_at);
