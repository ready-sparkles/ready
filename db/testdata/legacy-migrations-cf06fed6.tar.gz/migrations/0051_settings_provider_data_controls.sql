ALTER TABLE users
  ADD COLUMN IF NOT EXISTS session_version integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

ALTER TABLE agent_connectors
  ADD COLUMN IF NOT EXISTS provider_account_id text,
  ADD COLUMN IF NOT EXISTS provider_email varchar(255),
  ADD COLUMN IF NOT EXISTS provider_tenant_id varchar(255),
  ADD COLUMN IF NOT EXISTS scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS sync_status varchar(64) NOT NULL DEFAULT 'idle',
  ADD COLUMN IF NOT EXISTS account_kind varchar(32),
  ADD COLUMN IF NOT EXISTS connected_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_synced_at timestamptz,
  ADD COLUMN IF NOT EXISTS disconnected_at timestamptz,
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

UPDATE agent_connectors
SET
  provider_email = coalesce(provider_email, external_account_email),
  provider_account_id = coalesce(provider_account_id, external_account_email),
  account_kind = coalesce(account_kind, 'work'),
  connected_at = coalesce(connected_at, case when status = 'connected' then created_at else null end),
  disconnected_at = coalesce(disconnected_at, case when status = 'disconnected' then updated_at else null end)
WHERE provider IN ('google_calendar', 'outlook_calendar');

UPDATE agent_connectors
SET
  connected_at = coalesce(connected_at, case when status = 'connected' then created_at else null end),
  disconnected_at = coalesce(disconnected_at, case when status = 'disconnected' then updated_at else null end)
WHERE provider NOT IN ('google_calendar', 'outlook_calendar');

DROP INDEX IF EXISTS agent_connectors_user_provider_uidx;
DROP INDEX IF EXISTS agent_connectors_user_provider_null_account_active_uidx;
DROP INDEX IF EXISTS agent_connectors_user_provider_account_active_uidx;

CREATE UNIQUE INDEX agent_connectors_user_provider_null_account_active_uidx
  ON agent_connectors(user_id, provider)
  WHERE provider_account_id IS NULL AND deleted_at IS NULL;

CREATE UNIQUE INDEX agent_connectors_user_provider_account_active_uidx
  ON agent_connectors(user_id, provider, provider_account_id)
  WHERE provider_account_id IS NOT NULL AND deleted_at IS NULL;

ALTER TABLE calendar_event_preps
  ADD COLUMN IF NOT EXISTS calendar_account_id uuid REFERENCES agent_connectors(id) ON DELETE CASCADE;

DROP INDEX IF EXISTS calendar_event_preps_user_event_fingerprint_uidx;
DROP INDEX IF EXISTS calendar_event_preps_user_event_fingerprint_account_uidx;
DROP INDEX IF EXISTS calendar_event_preps_user_event_fingerprint_legacy_uidx;

CREATE UNIQUE INDEX calendar_event_preps_user_event_fingerprint_account_uidx
  ON calendar_event_preps(user_id, calendar_event_id, event_fingerprint, calendar_account_id)
  WHERE calendar_account_id IS NOT NULL;

CREATE UNIQUE INDEX calendar_event_preps_user_event_fingerprint_legacy_uidx
  ON calendar_event_preps(user_id, calendar_event_id, event_fingerprint)
  WHERE calendar_account_id IS NULL;

CREATE INDEX IF NOT EXISTS calendar_event_preps_account_idx
  ON calendar_event_preps(calendar_account_id);

ALTER TABLE mail_accounts
  ADD COLUMN IF NOT EXISTS provider_email varchar(255),
  ADD COLUMN IF NOT EXISTS provider_tenant_id varchar(255),
  ADD COLUMN IF NOT EXISTS sync_status varchar(64) NOT NULL DEFAULT 'idle',
  ADD COLUMN IF NOT EXISTS account_kind varchar(32),
  ADD COLUMN IF NOT EXISTS connected_at timestamptz,
  ADD COLUMN IF NOT EXISTS disconnected_at timestamptz,
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

UPDATE mail_accounts
SET
  provider_email = coalesce(provider_email, email),
  connected_at = coalesce(connected_at, case when status = 'connected' then created_at else null end),
  disconnected_at = coalesce(disconnected_at, case when status = 'disconnected' then updated_at else null end),
  sync_status = coalesce(nullif(sync_status, ''), case when status = 'connected' then 'idle' else status::text end);

DROP INDEX IF EXISTS mail_accounts_user_provider_account_uidx;
DROP INDEX IF EXISTS mail_accounts_user_provider_email_uidx;

CREATE UNIQUE INDEX mail_accounts_user_provider_account_uidx
  ON mail_accounts(user_id, provider, provider_account_id)
  WHERE provider_account_id IS NOT NULL AND deleted_at IS NULL;

CREATE UNIQUE INDEX mail_accounts_user_provider_email_uidx
  ON mail_accounts(user_id, provider, email)
  WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS data_deletion_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  target_kind varchar(64) NOT NULL,
  target_provider varchar(64),
  target_account_id uuid,
  status varchar(32) NOT NULL DEFAULT 'pending',
  provider_revocation_status jsonb NOT NULL DEFAULT '{}'::jsonb,
  error jsonb,
  requested_at timestamptz NOT NULL DEFAULT now(),
  mail_deleted_at timestamptz,
  calendar_deleted_at timestamptz,
  attachments_deleted_at timestamptz,
  completed_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS data_deletion_requests_user_idx
  ON data_deletion_requests(user_id, requested_at);

CREATE INDEX IF NOT EXISTS data_deletion_requests_target_idx
  ON data_deletion_requests(target_kind, target_account_id);
