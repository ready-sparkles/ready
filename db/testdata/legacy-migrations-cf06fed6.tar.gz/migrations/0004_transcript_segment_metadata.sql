ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS speaker_identity text;

ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS speaker_role varchar(32);

ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS source varchar(64);

ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS source_segment_id text;

UPDATE transcript_segments
SET speaker_identity = COALESCE(speaker_identity, speaker_user_id::text, speaker_name)
WHERE speaker_identity IS NULL;

UPDATE transcript_segments
SET speaker_role = COALESCE(speaker_role, 'human')
WHERE speaker_role IS NULL;

UPDATE transcript_segments
SET source = COALESCE(source, 'legacy-transcript')
WHERE source IS NULL;

ALTER TABLE transcript_segments
  ALTER COLUMN speaker_identity SET NOT NULL;

ALTER TABLE transcript_segments
  ALTER COLUMN speaker_role SET NOT NULL;

ALTER TABLE transcript_segments
  ALTER COLUMN speaker_role SET DEFAULT 'human';

ALTER TABLE transcript_segments
  ALTER COLUMN source SET NOT NULL;

ALTER TABLE transcript_segments
  ALTER COLUMN source SET DEFAULT 'legacy-transcript';

CREATE INDEX IF NOT EXISTS transcript_segments_source_idx
  ON transcript_segments(transcript_id, source);

CREATE UNIQUE INDEX IF NOT EXISTS transcript_segments_source_segment_uidx
  ON transcript_segments(transcript_id, source, source_segment_id)
  WHERE source_segment_id IS NOT NULL;
