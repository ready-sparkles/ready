-- Backfill ai_credit_usage_events.workspace_id for rows recorded before the
-- column existed. Only use meeting relationships that prove which workspace
-- owned the work; current user preferences are not historical attribution.

-- Meeting-scoped events adopt the meeting's workspace (authoritative).
UPDATE ai_credit_usage_events e
SET workspace_id = m.workspace_id
FROM meetings m
WHERE e.meeting_id = m.id
  AND e.workspace_id IS NULL;

-- Some usage events omit meeting_id but retain the AI job that owns the
-- meeting. Follow that immutable relationship instead.
UPDATE ai_credit_usage_events e
SET workspace_id = m.workspace_id
FROM ai_workflow_jobs j
JOIN meetings m ON m.id = j.meeting_id
WHERE e.workspace_id IS NULL
  AND e.job_id = j.id;

-- Capability workflow runs are also meeting-owned even when the usage event
-- itself did not persist meeting_id.
UPDATE ai_credit_usage_events e
SET workspace_id = m.workspace_id
FROM capability_workflow_runs r
JOIN meetings m ON m.id = r.meeting_id
WHERE e.workspace_id IS NULL
  AND e.workflow_run_id = r.id;

-- Genuinely meeting-less history (for example old calendar prep) stays NULL.
-- Assigning it to users.active_workspace_id would use today's preference for
-- a historical event and could permanently skew per-workspace trial usage.
