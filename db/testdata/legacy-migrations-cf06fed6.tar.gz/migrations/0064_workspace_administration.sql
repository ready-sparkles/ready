-- Workspace administration: member statuses, invitations, workspace settings,
-- meeting confidentiality, audit events, and last-seen tracking.

ALTER TABLE workspaces
  ADD COLUMN logo_url text;

CREATE TYPE workspace_membership_status AS ENUM ('active', 'suspended');

ALTER TABLE workspace_memberships
  ADD COLUMN status workspace_membership_status NOT NULL DEFAULT 'active',
  ADD COLUMN suspended_at timestamptz;

ALTER TABLE users
  ADD COLUMN last_seen_at timestamptz;

CREATE TABLE workspace_invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  email varchar(255) NOT NULL,
  role workspace_membership_role NOT NULL DEFAULT 'member',
  token_hash text NOT NULL,
  invited_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz,
  accepted_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  revoked_at timestamptz,
  last_sent_at timestamptz NOT NULL DEFAULT now(),
  send_count integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX workspace_invitations_token_hash_uidx
  ON workspace_invitations(token_hash);

-- One live invitation per email per workspace; accepted or revoked rows stay
-- for history without blocking a re-invite.
CREATE UNIQUE INDEX workspace_invitations_active_email_uidx
  ON workspace_invitations(workspace_id, lower(email))
  WHERE accepted_at IS NULL AND revoked_at IS NULL;

CREATE INDEX workspace_invitations_workspace_idx
  ON workspace_invitations(workspace_id, created_at DESC);

-- Existing meetings stay workspace-visible: confidentiality is never inferred
-- retroactively (is_confidential defaults to false for every current row).
ALTER TABLE meetings
  ADD COLUMN is_confidential boolean NOT NULL DEFAULT false,
  ADD COLUMN confidentiality_source varchar(16),
  ADD COLUMN confidentiality_updated_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  ADD COLUMN confidentiality_updated_at timestamptz;

ALTER TABLE meetings
  ADD CONSTRAINT meetings_confidentiality_source_check
  CHECK (confidentiality_source IS NULL OR confidentiality_source IN ('auto', 'manual'));

CREATE TABLE workspace_audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  event_type varchar(64) NOT NULL,
  subject_type varchar(32),
  subject_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX workspace_audit_events_workspace_idx
  ON workspace_audit_events(workspace_id, created_at DESC);
CREATE INDEX workspace_audit_events_subject_idx
  ON workspace_audit_events(subject_type, subject_id, created_at DESC);
