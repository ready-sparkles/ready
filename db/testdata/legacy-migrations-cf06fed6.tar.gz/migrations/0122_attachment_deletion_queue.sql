CREATE TABLE IF NOT EXISTS pending_attachment_deletions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deletion_request_id uuid NOT NULL REFERENCES data_deletion_requests(id) ON DELETE CASCADE,
  storage_key text NOT NULL,
  attempts integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  lease_token uuid,
  locked_until timestamptz,
  last_error text,
  UNIQUE (deletion_request_id, storage_key)
);
CREATE INDEX IF NOT EXISTS pending_attachment_deletions_due_idx
  ON pending_attachment_deletions(next_attempt_at);
