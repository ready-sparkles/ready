-- Backfill the invariant for existing standard meetings with exactly two
-- human participants who are both active members of the meeting workspace.
WITH internal_one_to_ones AS (
  SELECT m.id
  FROM meetings m
  JOIN meeting_participants mp
    ON mp.meeting_id = m.id
   AND mp.role <> 'assistant'
  JOIN users u
    ON u.id = mp.user_id
   AND u.deleted_at IS NULL
  LEFT JOIN workspace_memberships wm
    ON wm.workspace_id = m.workspace_id
   AND wm.user_id = u.id
  WHERE m.kind = 'standard'
  GROUP BY m.id
  HAVING COUNT(DISTINCT u.id) = 2
     AND COUNT(DISTINCT u.id) FILTER (WHERE wm.status = 'active') = 2
)
UPDATE meetings m
SET is_confidential = true,
    confidentiality_source = 'auto',
    confidentiality_updated_by_user_id = NULL,
    confidentiality_updated_at = NOW()
FROM internal_one_to_ones internal
WHERE m.id = internal.id
  AND (
    m.is_confidential = false
    OR m.confidentiality_source IS DISTINCT FROM 'auto'
  );
