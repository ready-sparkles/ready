CREATE TYPE assigned_task_source_type AS ENUM (
  'meeting',
  'workspace'
);

CREATE TABLE workspace_task_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  title varchar(120) NOT NULL,
  position integer NOT NULL DEFAULT 0,
  is_default boolean NOT NULL DEFAULT false,
  created_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  updated_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);

CREATE INDEX workspace_task_sections_workspace_idx
  ON workspace_task_sections(workspace_id, position)
  WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX workspace_task_sections_default_uidx
  ON workspace_task_sections(workspace_id)
  WHERE is_default = true AND deleted_at IS NULL;

CREATE UNIQUE INDEX workspace_task_sections_title_uidx
  ON workspace_task_sections(workspace_id, title)
  WHERE deleted_at IS NULL;

CREATE TABLE workspace_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  created_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  updated_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  assignee_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  title varchar(160) NOT NULL,
  description text,
  due_date_value varchar(120),
  due_date_confidence extraction_confidence,
  status meeting_task_status NOT NULL DEFAULT 'open',
  revision integer NOT NULL DEFAULT 1,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX workspace_tasks_workspace_assignee_idx
  ON workspace_tasks(workspace_id, assignee_user_id, status, updated_at DESC);

CREATE TABLE assigned_task_placements (
  source_type assigned_task_source_type NOT NULL,
  source_task_id uuid NOT NULL,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  assignee_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  section_id uuid NOT NULL REFERENCES workspace_task_sections(id) ON DELETE CASCADE,
  position integer NOT NULL DEFAULT 0,
  revision integer NOT NULL DEFAULT 1,
  updated_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (source_type, source_task_id, workspace_id, assignee_user_id)
);

CREATE INDEX assigned_task_placements_scope_idx
  ON assigned_task_placements(workspace_id, assignee_user_id, section_id, position);
