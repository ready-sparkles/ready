-- The host owns the meeting. This is each attendee's private filing location,
-- not a workspace sharing grant. First join wins, including across rejoins.
CREATE TABLE meeting_attendee_workspaces (
 meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
 assignment text NOT NULL CHECK(assignment IN('host_workspace','joined_workspace','historical_default')),
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(meeting_id,user_id)
);
CREATE INDEX meeting_attendee_workspaces_scope ON meeting_attendee_workspaces(user_id,workspace_id,meeting_id);

-- The old system did not record joining context. Preserve host-workspace history
-- for members; external history gets the oldest active membership once. This is
-- an explicit historical fallback, never reconstructed joining context.
INSERT INTO meeting_attendee_workspaces(meeting_id,user_id,workspace_id,assignment)
 SELECT attended.meeting_id,attended.user_id,destination.workspace_id,
  CASE WHEN destination.workspace_id=m.workspace_id THEN 'host_workspace' ELSE 'historical_default' END
 FROM (SELECT meeting_id,user_id FROM meeting_attendance_intervals
  UNION SELECT p.meeting_id,p.user_id FROM meeting_participants p JOIN meetings m ON m.id=p.meeting_id WHERE m.status='ended') attended
 JOIN meetings m ON m.id=attended.meeting_id
 JOIN users u ON u.id=attended.user_id AND u.deleted_at IS NULL AND u.source IN('auth','dev_login')
 CROSS JOIN LATERAL (
  SELECT wm.workspace_id FROM workspace_memberships wm
  WHERE wm.user_id=u.id AND wm.status='active'
  ORDER BY (wm.workspace_id=m.workspace_id) DESC,wm.created_at,wm.workspace_id LIMIT 1
 ) destination
 WHERE NOT EXISTS(SELECT 1 FROM workspace_memberships wm WHERE wm.user_id=u.id AND wm.workspace_id=m.workspace_id AND wm.status='suspended');

CREATE FUNCTION record_meeting_attendee_workspace(meeting uuid,attendee uuid,selected_workspace uuid DEFAULT NULL,allow_ended boolean DEFAULT false)
 RETURNS void LANGUAGE plpgsql AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM meeting_attendee_workspaces a WHERE a.meeting_id=meeting AND a.user_id=attendee) THEN RETURN; END IF;
 -- The selected workspace comes from authenticated server context, not a body
 -- field. Recheck membership here so stale sessions cannot assign other scopes.
 IF selected_workspace IS NOT NULL AND NOT EXISTS(
  SELECT 1 FROM workspace_memberships wm WHERE wm.user_id=attendee AND wm.workspace_id=selected_workspace AND wm.status='active'
 ) THEN RAISE EXCEPTION 'Inactive attendee workspace' USING ERRCODE='23503'; END IF;
 INSERT INTO meeting_attendee_workspaces(meeting_id,user_id,workspace_id,assignment)
 SELECT m.id,u.id,destination.workspace_id,
  CASE WHEN destination.workspace_id=m.workspace_id THEN 'host_workspace' ELSE 'joined_workspace' END
 FROM meetings m JOIN users u ON u.id=attendee
 CROSS JOIN LATERAL (
  SELECT wm.workspace_id FROM workspace_memberships wm
  WHERE wm.user_id=u.id AND wm.status='active'
  ORDER BY (wm.workspace_id=m.workspace_id) DESC,
   (wm.workspace_id=coalesce(selected_workspace,u.active_workspace_id)) DESC NULLS LAST,
   wm.created_at,wm.workspace_id LIMIT 1
 ) destination
 WHERE m.id=meeting AND (m.status<>'ended' OR (allow_ended AND EXISTS(
   SELECT 1 FROM meeting_attendance_intervals a WHERE a.meeting_id=m.id AND a.user_id=attendee AND a.joined_at<m.ended_at
  ))) AND u.deleted_at IS NULL AND u.source IN('auth','dev_login')
  AND NOT EXISTS(SELECT 1 FROM workspace_memberships wm WHERE wm.user_id=u.id AND wm.workspace_id=m.workspace_id AND wm.status='suspended')
 ON CONFLICT(meeting_id,user_id) DO NOTHING;
END $$;

-- Fallback for webhook-first joins and older app instances. New API token/join
-- routes record authenticated workspace context before issuing access tokens.
CREATE FUNCTION capture_attendee_workspace() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM record_meeting_attendee_workspace(NEW.meeting_id,NEW.user_id);
 RETURN NEW;
END $$;
CREATE TRIGGER capture_attendee_workspace AFTER INSERT ON meeting_attendance_intervals
 FOR EACH ROW EXECUTE FUNCTION capture_attendee_workspace();

CREATE FUNCTION meeting_in_attendee_workspace(meeting uuid,attendee uuid,workspace uuid)
 RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT EXISTS(SELECT 1 FROM meetings m WHERE m.id=meeting AND
  coalesce((SELECT a.workspace_id FROM meeting_attendee_workspaces a WHERE a.meeting_id=m.id AND a.user_id=attendee),m.workspace_id)=workspace)
$$;

-- Permit the attendee destination while enforcing isolation for old/new writers.
-- The existing meeting_id FK still cascades deletion of meeting evidence.
ALTER TABLE memory_sources DROP CONSTRAINT memory_source_meeting_workspace_fk;
CREATE FUNCTION enforce_memory_attendee_workspace() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.meeting_id IS NOT NULL AND NOT meeting_in_attendee_workspace(NEW.meeting_id,NEW.user_id,NEW.workspace_id) THEN
  RAISE EXCEPTION 'Memory source belongs to another attendee workspace' USING ERRCODE='23503';
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER memory_attendee_workspace_boundary BEFORE INSERT OR UPDATE OF meeting_id,user_id,workspace_id ON memory_sources
 FOR EACH ROW EXECUTE FUNCTION enforce_memory_attendee_workspace();

CREATE FUNCTION remove_attendee_workspace_memory() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 DELETE FROM memory_sources WHERE meeting_id=OLD.meeting_id AND user_id=OLD.user_id AND workspace_id=OLD.workspace_id;
 RETURN OLD;
END $$;
CREATE TRIGGER remove_attendee_workspace_memory AFTER DELETE ON meeting_attendee_workspaces
 FOR EACH ROW EXECUTE FUNCTION remove_attendee_workspace_memory();

-- Bounded discovery adds missing external history. No completed extraction,
-- suppression, prompt version or valid historical source is reset.
INSERT INTO memory_backfills(user_id,workspace_id)
 SELECT DISTINCT user_id,workspace_id FROM meeting_attendee_workspaces WHERE assignment='historical_default'
 ON CONFLICT(user_id,workspace_id) DO UPDATE SET cursor_meeting_id=NULL,cycle_started_at=now(),
 revision=memory_backfills.revision+1,run_after=now();
