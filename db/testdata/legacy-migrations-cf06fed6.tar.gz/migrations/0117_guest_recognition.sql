-- Recognition never changes users, admission, or meeting access.
CREATE TABLE guest_browser_identities (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 token_hash text NOT NULL UNIQUE,
 notice_version text NOT NULL,
 purpose text NOT NULL,
 consented_at timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz NOT NULL,
 revoked_at timestamptz
);
CREATE TABLE guest_browser_users (
 guest_user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 browser_id uuid NOT NULL REFERENCES guest_browser_identities(id) ON DELETE CASCADE,
 associated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX guest_browser_users_browser ON guest_browser_users(browser_id);
ALTER TABLE memory_person_identities DROP CONSTRAINT memory_person_identities_kind_check;
ALTER TABLE memory_person_identities ADD CONSTRAINT memory_person_identities_kind_check
 CHECK(kind IN ('user_id','verified_email','guest_browser'));
-- One observation per participant per meeting, so worker retries do not inflate counts.
CREATE TABLE memory_person_names (
 person_id uuid NOT NULL REFERENCES memory_people(id) ON DELETE CASCADE,
 source_id uuid NOT NULL REFERENCES memory_sources(id) ON DELETE CASCADE,
 participant_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 name text NOT NULL,
 normalized_name text NOT NULL,
 word_count integer NOT NULL,
 observed_at timestamptz NOT NULL,
 PRIMARY KEY(person_id,source_id,participant_user_id)
);
