-- Replace Postgres enums with text and replace active-row partial uniques with
-- generated keys. A finished row stores NULL in the key. Postgres unique indexes
-- treat those NULL values as distinct.
-- The previous API stays up until this deploy is healthy. These statements need
-- exclusive locks, so wait out live queries and close other sessions that hold them.
SET LOCAL lock_timeout = '3min';
SET LOCAL statement_timeout = 0;
DO $$
DECLARE backend record;
BEGIN
  FOR backend IN
    SELECT pid
    FROM pg_stat_activity
    WHERE pid <> pg_backend_pid()
      AND datname = current_database()
      AND backend_type = 'client backend'
  LOOP
    BEGIN
      PERFORM pg_terminate_backend(backend.pid);
    EXCEPTION
      WHEN insufficient_privilege THEN
        NULL;
    END;
  END LOOP;
END $$;

-- Remove predicates before their enum columns become text. Replacement unique
-- keys below preserve the same active-row constraints in this transaction.
DROP INDEX workspace_memberships_active_owner_uidx;
DROP INDEX meetings_one_current_per_link_uidx;
DROP INDEX meeting_join_requests_active_user_uidx;
DROP INDEX mail_jobs_active_classifier_thread_version_uidx;
DROP INDEX mail_jobs_active_summary_thread_version_uidx;
DROP INDEX ai_workflow_jobs_active_pipeline_uidx;
DROP INDEX meeting_research_runs_active_recommendation_uidx;
DROP INDEX realtime_outbox_pending_idx;
DROP INDEX memory_membership_discovery;
DROP TRIGGER memory_ended_meeting ON meetings;
ALTER TABLE workspace_invitations DROP CONSTRAINT workspace_invitations_no_owner_role_chk;
ALTER TABLE workspace_memberships DROP CONSTRAINT workspace_memberships_owner_must_be_active_chk;

-- Defaults depend on enum types even after the column conversion. Keep their
-- literal values while removing that dependency before dropping the types.
CREATE TEMP TABLE enum_defaults ON COMMIT DROP AS
SELECT c.relname, a.attname, pg_get_expr(d.adbin, d.adrelid) AS expression
FROM pg_attrdef d
JOIN pg_attribute a ON a.attrelid = d.adrelid AND a.attnum = d.adnum
JOIN pg_class c ON c.oid = a.attrelid
JOIN pg_type t ON t.oid = a.atttypid
WHERE t.typtype = 'e' AND c.relnamespace = 'public'::regnamespace;
DO $$
DECLARE column_default record;
BEGIN
  FOR column_default IN SELECT * FROM enum_defaults LOOP
    EXECUTE format('ALTER TABLE %I ALTER COLUMN %I DROP DEFAULT',
      column_default.relname, column_default.attname);
  END LOOP;
END $$;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE users ALTER COLUMN source TYPE text USING source::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE users ALTER COLUMN plan TYPE text USING plan::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE workspaces ALTER COLUMN plan TYPE text USING plan::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE workspace_memberships ALTER COLUMN role TYPE text USING role::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE workspace_memberships ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE workspace_invitations ALTER COLUMN role TYPE text USING role::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meetings ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_participants ALTER COLUMN role TYPE text USING role::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_join_requests ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_accounts ALTER COLUMN provider TYPE text USING provider::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_accounts ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_sync_subscriptions ALTER COLUMN provider TYPE text USING provider::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_threads ALTER COLUMN agent_summary_status TYPE text USING agent_summary_status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_threads ALTER COLUMN surface TYPE text USING surface::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_threads ALTER COLUMN surface_source TYPE text USING surface_source::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_messages ALTER COLUMN direction TYPE text USING direction::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_message_recipients ALTER COLUMN kind TYPE text USING kind::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_jobs ALTER COLUMN job_type TYPE text USING job_type::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_jobs ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_webhook_events ALTER COLUMN provider TYPE text USING provider::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_classifier_cache ALTER COLUMN surface TYPE text USING surface::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE mail_classifier_cache ALTER COLUMN source TYPE text USING source::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE action_items ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_task_lists ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_tasks ALTER COLUMN type TYPE text USING type::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_tasks ALTER COLUMN work_kind TYPE text USING work_kind::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_tasks ALTER COLUMN owner_confidence TYPE text USING owner_confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_tasks ALTER COLUMN due_date_confidence TYPE text USING due_date_confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_tasks ALTER COLUMN confidence TYPE text USING confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_tasks ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_tasks ALTER COLUMN created_from TYPE text USING created_from::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_live_task_candidates ALTER COLUMN type TYPE text USING type::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_live_task_candidates ALTER COLUMN work_kind TYPE text USING work_kind::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_live_task_candidates ALTER COLUMN owner_confidence TYPE text USING owner_confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_live_task_candidates ALTER COLUMN due_date_confidence TYPE text USING due_date_confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_live_task_candidates ALTER COLUMN confidence TYPE text USING confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE workspace_tasks ALTER COLUMN due_date_confidence TYPE text USING due_date_confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE workspace_tasks ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE personal_task_item_clearances ALTER COLUMN source_type TYPE text USING source_type::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE assigned_task_placements ALTER COLUMN source_type TYPE text USING source_type::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE realtime_outbox ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE capability_catalog ALTER COLUMN category TYPE text USING category::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE capability_catalog ALTER COLUMN side_effect_scope TYPE text USING side_effect_scope::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_extractions ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_extractions ALTER COLUMN content_status TYPE text USING content_status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_extractions ALTER COLUMN signals_status TYPE text USING signals_status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_extractions ALTER COLUMN meeting_type TYPE text USING meeting_type::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_extractions ALTER COLUMN meeting_type_confidence TYPE text USING meeting_type_confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_capability_recommendations ALTER COLUMN confidence TYPE text USING confidence::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE meeting_research_runs ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE ai_workflow_jobs ALTER COLUMN type TYPE text USING type::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE ai_workflow_jobs ALTER COLUMN status TYPE text USING status::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE credit_grants ALTER COLUMN source TYPE text USING source::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE admin_user_plan_changes ALTER COLUMN previous_plan TYPE text USING previous_plan::text;

-- Reason: Status values are checked in application code before each save, so the database enum is removed.
-- squawk-ignore changing-column-type
ALTER TABLE admin_user_plan_changes ALTER COLUMN next_plan TYPE text USING next_plan::text;

DO $$
DECLARE column_default record;
BEGIN
  FOR column_default IN SELECT * FROM enum_defaults LOOP
    EXECUTE format('ALTER TABLE %I ALTER COLUMN %I SET DEFAULT %s',
      column_default.relname, column_default.attname,
      split_part(column_default.expression, '::', 1) || '::text');
  END LOOP;
END $$;
ALTER TABLE workspace_invitations ADD CONSTRAINT workspace_invitations_no_owner_role_chk CHECK (role <> 'owner');
ALTER TABLE workspace_memberships ADD CONSTRAINT workspace_memberships_owner_must_be_active_chk CHECK (role <> 'owner' OR status = 'active');
CREATE INDEX memory_membership_discovery ON workspace_memberships (user_id, workspace_id, status);
CREATE TRIGGER memory_ended_meeting AFTER INSERT OR UPDATE OF status, ended_at ON meetings FOR EACH ROW EXECUTE FUNCTION notify_ended_memory_meeting();

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE action_item_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE ai_workflow_job_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE ai_workflow_job_type;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE assigned_task_source_type;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE capability_category;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE credit_grant_source;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE extraction_confidence;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE extraction_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_account_provider;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_account_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_direction;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_job_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_job_type;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_recipient_kind;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_summary_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_surface_source;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE mail_thread_surface;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_join_request_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_research_run_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_task_list_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_task_origin;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_task_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_task_type;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_task_work_kind;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE meeting_type;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE participant_role;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE realtime_outbox_status;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE side_effect_scope;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE user_plan;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE user_source;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE workspace_membership_role;

-- Reason: No column still uses this enum type after the text conversion above.
-- squawk-ignore ban-drop-type
DROP TYPE workspace_membership_status;

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE user_auth_accounts ADD COLUMN null_account_key text GENERATED ALWAYS AS (CASE WHEN provider_account_id IS NULL THEN user_id::text || ':' || provider ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX user_auth_accounts_null_account_key_uidx ON user_auth_accounts (null_account_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE workspace_memberships ADD COLUMN active_owner_key text GENERATED ALWAYS AS (CASE WHEN role = 'owner' AND status = 'active' THEN workspace_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX workspace_memberships_active_owner_key_uidx ON workspace_memberships (active_owner_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE workspace_invitations ADD COLUMN active_email_key text GENERATED ALWAYS AS (CASE WHEN accepted_at IS NULL AND revoked_at IS NULL THEN workspace_id::text || ':' || lower(email) ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX workspace_invitations_active_email_key_uidx ON workspace_invitations (active_email_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE meetings ADD COLUMN agent_intro_key text GENERATED ALWAYS AS (CASE WHEN kind = 'agent_intro' AND hidden_from_history_reason IS DISTINCT FROM 'debug_onboarding_reset' THEN created_by_user_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX meetings_agent_intro_key_uidx ON meetings (agent_intro_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE meetings ADD COLUMN current_link_key text GENERATED ALWAYS AS (CASE WHEN meeting_link_id IS NOT NULL AND status IN ('scheduled', 'active') THEN meeting_link_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX meetings_current_link_key_uidx ON meetings (current_link_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE meeting_join_requests ADD COLUMN active_join_key text GENERATED ALWAYS AS (CASE WHEN status IN ('waiting', 'admitted') THEN meeting_link_id::text || ':' || user_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX meeting_join_requests_active_join_key_uidx ON meeting_join_requests (active_join_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE agent_profiles ADD COLUMN default_profile_key text GENERATED ALWAYS AS (CASE WHEN is_default THEN user_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX agent_profiles_default_profile_key_uidx ON agent_profiles (default_profile_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE meeting_turns ADD COLUMN active_turn_key text GENERATED ALWAYS AS (CASE WHEN status = 'active' THEN meeting_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX meeting_turns_active_turn_key_uidx ON meeting_turns (active_turn_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE agent_connectors ADD COLUMN null_account_key text GENERATED ALWAYS AS (CASE WHEN provider_account_id IS NULL AND deleted_at IS NULL THEN user_id::text || ':' || provider ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX agent_connectors_null_account_key_uidx ON agent_connectors (null_account_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE agent_connectors ADD COLUMN active_account_key text GENERATED ALWAYS AS (CASE WHEN provider_account_id IS NOT NULL AND deleted_at IS NULL THEN user_id::text || ':' || provider || ':' || provider_account_id ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX agent_connectors_active_account_key_uidx ON agent_connectors (active_account_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE calendar_sync_subscriptions ADD COLUMN active_calendar_key text GENERATED ALWAYS AS (CASE WHEN status = 'active' THEN agent_connector_id::text || ':' || calendar_id ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX calendar_sync_subscriptions_active_calendar_key_uidx ON calendar_sync_subscriptions (active_calendar_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE calendar_event_preps ADD COLUMN legacy_fingerprint_key text GENERATED ALWAYS AS (CASE WHEN calendar_account_id IS NULL THEN user_id::text || ':' || calendar_event_id || ':' || event_fingerprint ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX calendar_event_preps_legacy_fingerprint_key_uidx ON calendar_event_preps (legacy_fingerprint_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE mail_accounts ADD COLUMN active_provider_account_key text GENERATED ALWAYS AS (CASE WHEN provider_account_id IS NOT NULL AND deleted_at IS NULL THEN user_id::text || ':' || provider || ':' || provider_account_id ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX mail_accounts_active_provider_account_key_uidx ON mail_accounts (active_provider_account_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE mail_accounts ADD COLUMN active_email_key text GENERATED ALWAYS AS (CASE WHEN deleted_at IS NULL THEN user_id::text || ':' || provider || ':' || lower(email) ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX mail_accounts_active_email_key_uidx ON mail_accounts (active_email_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE mail_sync_subscriptions ADD COLUMN active_subscription_key text GENERATED ALWAYS AS (CASE WHEN status = 'active' THEN account_id::text || ':' || subscription_kind ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX mail_sync_subscriptions_active_subscription_key_uidx ON mail_sync_subscriptions (active_subscription_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE mail_threads ADD COLUMN fallback_thread_key text GENERATED ALWAYS AS (CASE WHEN provider_thread_id IS NULL THEN account_id::text || ':' || participant_set_hash || ':' || subject_root ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX mail_threads_fallback_thread_key_uidx ON mail_threads (fallback_thread_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE meeting_research_runs ADD COLUMN active_recommendation_key text GENERATED ALWAYS AS (CASE WHEN status IN ('queued', 'running') THEN meeting_id::text || ':' || recommendation_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX meeting_research_runs_active_recommendation_key_uidx ON meeting_research_runs (active_recommendation_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE ai_workflow_jobs ADD COLUMN active_pipeline_key text GENERATED ALWAYS AS (CASE WHEN status IN ('queued', 'running') THEN meeting_id::text || ':' || type || ':' || scope_key ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX ai_workflow_jobs_active_pipeline_key_uidx ON ai_workflow_jobs (active_pipeline_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE billing_seat_sync_outbox ADD COLUMN pending_workspace_key text GENERATED ALWAYS AS (CASE WHEN status = 'pending' THEN workspace_id::text ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX billing_seat_sync_outbox_pending_workspace_key_uidx ON billing_seat_sync_outbox (pending_workspace_key);

-- Reason: A generated key keeps one active row unique and stores NULL when the row is finished, which rewrites the table once.
-- squawk-ignore adding-field-with-default
ALTER TABLE billing_checkout_attempts ADD COLUMN pending_checkout_key text GENERATED ALWAYS AS (CASE WHEN status IN ('pending', 'processing') THEN subject_type || ':' || subject_id::text || ':' || checkout_kind ELSE NULL END) STORED;
-- Reason: The migration runner applies this file inside one transaction, so a concurrent index build cannot run.
-- squawk-ignore require-concurrent-index-creation
CREATE UNIQUE INDEX billing_checkout_attempts_pending_checkout_key_uidx ON billing_checkout_attempts (pending_checkout_key);
