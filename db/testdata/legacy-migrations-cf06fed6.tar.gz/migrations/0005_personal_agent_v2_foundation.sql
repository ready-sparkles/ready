CREATE TABLE IF NOT EXISTS agent_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name varchar(120) NOT NULL,
  display_name varchar(120) NOT NULL,
  system_prompt text,
  voice_provider varchar(64) NOT NULL DEFAULT 'openai',
  voice_id varchar(120),
  llm_model varchar(120),
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS agent_profiles_user_idx
  ON agent_profiles(user_id);

CREATE UNIQUE INDEX IF NOT EXISTS agent_profiles_default_user_uidx
  ON agent_profiles(user_id)
  WHERE is_default = true;

CREATE TABLE IF NOT EXISTS meeting_turns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  owner_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  owner_participant_identity text NOT NULL,
  agent_profile_id uuid NOT NULL REFERENCES agent_profiles(id) ON DELETE RESTRICT,
  assistant_display_name varchar(120) NOT NULL,
  voice_id varchar(120),
  status varchar(32) NOT NULL DEFAULT 'active',
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS meeting_turns_meeting_idx
  ON meeting_turns(meeting_id, started_at);

CREATE INDEX IF NOT EXISTS meeting_turns_owner_idx
  ON meeting_turns(owner_user_id, started_at);

CREATE UNIQUE INDEX IF NOT EXISTS meeting_turns_active_meeting_uidx
  ON meeting_turns(meeting_id)
  WHERE status = 'active';

ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS meeting_turn_id uuid REFERENCES meeting_turns(id) ON DELETE SET NULL;

ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS agent_profile_id uuid REFERENCES agent_profiles(id) ON DELETE SET NULL;

ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS agent_owner_user_id uuid REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE transcript_segments
  ADD COLUMN IF NOT EXISTS voice_id varchar(120);

CREATE INDEX IF NOT EXISTS transcript_segments_turn_idx
  ON transcript_segments(meeting_turn_id);

CREATE INDEX IF NOT EXISTS transcript_segments_agent_owner_idx
  ON transcript_segments(agent_owner_user_id);
