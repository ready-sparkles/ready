-- Preserve existing job IDs, dedupe keys, status, leases and backfill cursors.
-- Historical jobs retain priority 0. New-meeting notifications promote only
-- their own jobs; user-triggered projection work has priority 1.
ALTER TABLE memory_jobs ADD COLUMN priority smallint NOT NULL DEFAULT 0;
CREATE INDEX memory_job_priority ON memory_jobs(priority DESC,created_at,id)
 WHERE status IN ('queued','running');
CREATE INDEX memory_job_running_scope ON memory_jobs(user_id,workspace_id,locked_at) WHERE status='running';
CREATE TABLE memory_extraction_checkpoints (
 job_id uuid PRIMARY KEY REFERENCES memory_jobs(id) ON DELETE CASCADE,
 input_hash text NOT NULL,
 next_pass integer NOT NULL CHECK(next_pass>=0),
 candidates jsonb NOT NULL,
 model text NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
-- Give previously exhausted, still-current jobs another bounded retry after the
-- worker fix. Completed jobs (including zero-memory results) are never reset.
UPDATE memory_jobs j SET status='queued',attempts=0,error=NULL,run_after=now(),lease_token=NULL
 FROM memory_sources s,memory_preferences p
 WHERE j.status='failed' AND j.kind='extract' AND s.id=j.source_id
   AND j.source_revision=s.revision AND j.prompt_version='1.3.0'
   AND p.user_id=j.user_id AND p.workspace_id=j.workspace_id AND p.revision=j.preferences_revision
   AND NOT EXISTS(SELECT 1 FROM memory_legacy_suppressions old WHERE old.source_id=s.id);
