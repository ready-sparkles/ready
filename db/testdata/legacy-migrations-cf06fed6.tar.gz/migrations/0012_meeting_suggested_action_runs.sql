CREATE TABLE IF NOT EXISTS meeting_suggested_action_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL UNIQUE REFERENCES meetings(id) ON DELETE CASCADE,
  status varchar(32) NOT NULL DEFAULT 'pending',
  phase varchar(64) NOT NULL DEFAULT 'reading_notes',
  steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  message text,
  error text,
  selected_recommendation_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS meeting_suggested_action_runs_meeting_idx
  ON meeting_suggested_action_runs(meeting_id);

